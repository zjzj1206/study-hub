#!/usr/bin/env python3
"""Build independently; refuse to replace a valid PDF unless it is eight A4 pages."""
from pathlib import Path
import io
import sys
import zipfile
import typst
from pypdf import PdfReader
ROOT = Path(__file__).resolve().parent
out = ROOT.parent / 'output/pdf'
out.mkdir(parents=True, exist_ok=True)
target = out / 'discrete-final-cheatsheet.pdf'
try:
    data = typst.compile(str(ROOT / 'main.typ'), root=str(ROOT))
    pdf = PdfReader(io.BytesIO(data))
    if len(pdf.pages) != 8:
        raise ValueError(f'应为 8 页，实际 {len(pdf.pages)} 页；请调整内容或 main.typ 的字号、间距。')
    for i, page in enumerate(pdf.pages, 1):
        w, h = float(page.mediabox.width), float(page.mediabox.height)
        if abs(w - 595.276) > 1 or abs(h - 841.89) > 1:
            raise ValueError(f'第 {i} 页不是纵向 A4：{w} × {h} pt')
        if len(page.extract_text().strip()) < 100:
            raise ValueError(f'第 {i} 页疑似空白。')
    tmp = target.with_suffix('.tmp.pdf')
    tmp.write_bytes(data)
    tmp.replace(target)
    archive = out / 'discrete-final-cheatsheet-editable.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file() and not any(part.startswith('.') or part == '__pycache__' for part in p.relative_to(ROOT).parts):
                z.write(p, Path(ROOT.name) / p.relative_to(ROOT))
    print(f'构建成功：8 页纵向 A4\n{target}\n{archive}')
except Exception as e:
    sys.exit('构建失败（保留原 PDF）：\n' + getattr(e, 'diagnostic', str(e)))
