= 01 概率：先建模，再计算

- *概率空间* $(Omega,cal(F),P)$：事件属于 $cal(F)$，$P(Omega)=1$，可列不交并的概率相加。离散随机变量是 $X:Omega arrow.r S$，分布 $p_X (x)=P(X=x)$；$P(A|B)=P(A inter B)/P(B)$ 要求 $P(B)>0$。全概率：对事件划分 $(B_i)$，$P(A)=sum_i P(B_i)P(A|B_i)$；Bayes：$P(B_i|A)=P(B_i)P(A|B_i)/P(A)$。

- *独立*：事件族相互独立要求任意有限子族交概率等于乘积；两两独立不够。变量独立等价于联合分布分解。条件独立须在每个给定条件下分别分解，不能去掉条件。独立变量的函数仍独立；同一变量的两个函数通常不独立。

- *期望与方差*：$EE X=sum_x x p_X (x)$，$EE g(X)=sum_x g(x)p_X (x)$；线性性不需要独立。$"Var" X=EE X^2-(EE X)^2$，$"Cov"(X,Y)=EE(X Y)-EE X EE Y$。
  $ "Var"(sum_i X_i)=sum_i "Var" X_i+2 sum_(i<j) "Cov"(X_i,X_j). $
  独立蕴含协方差零，逆命题不成立。指示变量 $I_A$ 满足 $EE I_A=P(A)$；计数题先写 $X=sum I_A$。非负整数 $X$：$EE X=sum_(k>=1)P(X>=k)$，因为逐点 $X=sum_(k>=1)1_(X>=k)$。

- *条件期望*：$EE(X|Y=y)=sum_x x P(X=x|Y=y)$；$EE(EE(X|Y))=EE X$。全方差：
  $ "Var" X=EE("Var"(X|Y))+"Var"(EE(X|Y)). $
  证明：将 $X-EE X$ 拆为 $X-EE(X|Y)$ 与 $EE(X|Y)-EE X$，交叉项条件期望为零。

- *常用分布与 PGF*：$G_X (z)=EE z^X$（$X>=0$ 整数），$G'_X (1)=EE X$，$G''_X (1)=EE[X(X-1)]$，故 $"Var"X=G''_X (1)+G'_X (1)-G'_X (1)^2$（所需矩有限）。独立和满足 $G_(X+Y)=G_X G_Y$。
  - Bernoulli$(p)$：$G=1-p+p z$，均值 $p$、方差 $p(1-p)$。
  - Binomial$(n,p)$：$G=(1-p+p z)^n$，均值 $n p$、方差 $n p(1-p)$。
  - Poisson$(lambda)$：$P(X=k)=e^(-lambda)lambda^k/k!$，$G=e^(lambda(z-1))$，均值、方差均为 $lambda$。
  - Geometric$(p)$ 取值 $1,2,dots$：$G=p z/(1-(1-p)z)$，均值 $1/p$、方差 $(1-p)/p^2$。若数“成功前失败次数”，取值从 $0$ 起，均值改为 $(1-p)/p$。
  - Hypergeometric：$N$ 个中有 $M$ 个成功，不放回抽 $n$ 个；$P(X=k)=binom(M,k)binom(N-M,n-k)/binom(N,n)$。均值 $n M/N$，方差 $n(M/N)(1-M/N)(N-n)/(N-1)$（$N>1$）。

- *随机和／等待*：若 $N$ 独立于 iid $X_i$，$S=sum_(i=1)^N X_i$，则 $G_S=G_N compose G_X$；$EE S=EE N EE X$，$"Var"S=EE N "Var"X+"Var"N(EE X)^2$。集齐 $n$ 类等概率优惠券：已集齐 $k$ 类后等新类的成功率 $(n-k)/n$，故总期望 $n sum_(j=1)^n 1/j$。

= 例题方法与易错判断

- *方差不保序*（2025 期末第 2 题）：即使 $0<=X<=Y$，也不能推出 $"Var"X<="Var"Y$。取 $X~"Bern"(1/2),Y=1$，方差分别为 $1/4,0$。但期望保序，因为 $EE(Y-X)>=0$。

- *协方差等号*（2024 期末第 3 题）：若 $"Var"X="Var"Y="Cov"(X,Y)<infinity$，则 $"Var"(X-Y)=0$，所以 $X-Y=EE(X-Y)$ 几乎必然。一般地，方差零等价于几乎处处为常数，由非负变量 $(X-EE X)^2$ 期望为零得到。

- *随机配对中的原情侣*（2025 期末第 10 题）：$2n$ 人均匀配成 $n$ 对，总配法 $(2n-1)!! =(2n)!/(2^n n!)$。指定 $j$ 对原情侣保留的概率为 $a_(n,j)=(2n-2j-1)!!/(2n-1)!!$。令 $X$ 为保留对数，则
  $ EE binom(X,j)=binom(n,j)a_(n,j) arrow.r (1/2)^j/j!. $
  容斥给 $P(X=0)=sum_(j=0)^(n) (-1)^j binom(n,j)a_(n,j)$。用 Bonferroni 的有限奇偶截断先令 $n arrow.r infinity$，再令截断阶数趋于无穷，得到 $e^(-1/2)$，避免未经证明交换极限与求和。固定 $k$ 的精确式为
  $ P(X=k)=binom(n,k)sum_(j=0)^(n-k)(-1)^j binom(n-k,j)a_(n,k+j). $
  同样用截断得到 $P(X=k) arrow.r e^(-1/2)(1/2)^k/k!$，即 Poisson$(1/2)$ 极限。

- *求二阶矩的顺序*：先写 $X=sum I_i$，再用 $X(X-1)=sum_(i!=j) I_i I_j$。对随机配对，每对原情侣被保留概率 $1/(2n-1)$，两指定对同时保留概率 $1/((2n-1)(2n-3))$。因此 $EE X=n/(2n-1)$，$EE[X(X-1)]=n(n-1)/((2n-1)(2n-3))$（$n>=2$），再还原方差。
