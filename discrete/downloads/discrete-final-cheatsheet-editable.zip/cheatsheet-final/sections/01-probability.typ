= 10 · 概率基础

- *概率空间* $(Omega,cal(F),P)$：$cal(F)$ 对补与可列并封闭；$P(Omega)=1$；互斥 $A_i$ 满足 $P(union.big_i A_i)=sum_i P(A_i)$。任意事件有 $1_(union.big_i A_i)<=sum_i 1_(A_i)$，取期望得并集界。

- *条件概率与 Bayes*：$P(A|B)=P(A inter B)/P(B)$，$P(B)>0$。对正概率划分 $(B_i)$，
  $ P(A)=sum_i P(A inter B_i)=sum_i P(A|B_i)P(B_i), $
  $ P(B_j|A)=P(B_j inter A)/P(A)=(P(A|B_j)P(B_j))/(sum_i P(A|B_i)P(B_i)). $

- *独立*：相互独立 $⇔ P(inter.big_(i in J) A_i)=product_(i in J)P(A_i)$ 对每个非空子集 $J$ 成立。离散随机变量独立 $⇔ p_(X,Y) (x,y)=p_(X) (x)p_(Y) (y)$ 对所有 $x,y$ 成立。

- *分布与期望*：$p_(X) (x)=P(X=x), quad EE[g(X)]=sum_x g(x)p_(X) (x)$。
  $ EE[a X+b Y]=sum_(x,y) (a x+b y)p_(X,Y) (x,y)=a EE X+b EE Y. $
  独立时 $EE[X Y]=sum_(x,y)x y p_(X) (x)p_(Y) (y)=EE X EE Y$。指示变量 $EE 1_A=P(A)$；非负整数 $X=sum_(k>=1)1_(X>=k)$，故 $EE X=sum_(k>=1)P(X>=k)$。

- *方差与协方差*：$"Var"(X)=EE[(X-EE X)^2]=EE[X^2]-(EE X)^2$，
  $ "Cov"(X,Y)=EE[X Y]-EE X EE Y, quad "Var"(a X+b Y)=a^2 "Var"X+b^2 "Var"Y+2a b "Cov"(X,Y). $
  展开中心化变量的平方即得；独立 $arrow.r.double "Cov"(X,Y)=0$。

- *重期望*：$EE[X|Y=y]=sum_x x p_(X|Y) (x|y)$。求和消去条件：
  $ EE[EE[X|Y]]=sum_y p_(Y) (y)sum_x x p_(X|Y) (x|y)=sum_x x sum_y p_(X,Y) (x,y)=EE X. $

- *概率生成函数*：$X in NN_0$，$G_(X) (z)=sum_(k>=0)p_(X) (k)z^k=EE[z^X]$。逐项求导（从左趋近 $1$）：
  $ G'_(X) (1)=EE X, quad G''_(X) (1)=EE[X(X-1)], quad "Var"X=G''_(X) (1)+G'_(X) (1)-G'_(X) (1)^2. $
  $ X,Y "独立" arrow.r.double G_(X+Y) (z)=EE[z^X z^Y]=G_(X) (z)G_(Y) (z). $
  $N$ 独立于 iid $X_i$，$S=sum_(i=1)^N X_i$：$G_(S) (z)=EE[G_(X) (z)^N]=G_(N) (G_(X) (z))$。

- *Bernoulli 与二项*：$G_(B) (z)=1-p+p z$，$EE B=p$，$"Var"B=p(1-p)$。$X=sum_(i=1)^n B_i$（iid），$G_(X) (z)=(1-p+p z)^n$，
  $ [z^k]G_X=binom(n,k)p^(k) (1-p)^(n-k), quad EE X=n p, quad "Var"X=n p(1-p). $

- *几何分布*（含成功次）：$P(X=k)=(1-p)^(k-1)p$，$k>=1$。几何级数给 $G_(X) (z)=p z/(1-(1-p)z)$，求导得 $EE X=1/p$、$"Var"X=(1-p)/p^2$。

- *Poisson*：$p_(X) (k)=e^(-lambda)lambda^k/k!$，$G_(X) (z)=e^(lambda(z-1))$，$EE X="Var"X=lambda$。独立 Poisson 和的参数相加（PGF 相乘）；$"Bin"(n,lambda/n)$ 的 PGF 趋于 $e^(lambda(z-1))$，固定 $k$ 的二项概率亦趋于 $p_(X) (k)$。
