= 17 · 概率方法

- *第一矩*：$X=sum_i 1_(A_i)$，$EE X=sum_i P(A_i)$。$EE X<1 arrow.r.double P(X=0)>0$；$EE Y>=a arrow.r.double exists omega:Y(omega)>=a$（有限样本空间）。Ramsey：
  $ binom(n,k)2^(1-binom(k,2))<1 arrow.r.double R(k,k)>n $
  （每个 $k$ 点集成为单色团的概率为 $2^(1-binom(k,2))$）。

- *随机排列*：Bollobás 集合对 $abs(A_i)=k,abs(B_i)=l$，$A_i inter B_i=emptyset$，$i!=j arrow.r.double A_i inter B_j!=emptyset$。事件 $E_i$ 为所有 $A_i$ 元素排在 $B_i$ 前，$P(E_i)=1/binom(k+l,k)$。若 $x in A_i inter B_j,y in A_j inter B_i$，则 $E_i inter E_j arrow.r.double x<y<x$。故 $sum_i P(E_i)<=1$。

- *EKR*：$n>=2k$，两两相交的 $k$ 元集族 $cal(F)$ 满足 $abs(cal(F))<=binom(n-1,k-1)$。随机循环排列中至多 $k$ 个长度 $k$ 的区间属于 $cal(F)$：固定一个入选区间 $[0,k-1]$，其他候选起点为 $plus.minus 1,dots,plus.minus(k-1)$；起点 $-j$ 与 $k-j$ 的区间不交，每对至多选一。每个成员成为区间的概率为 $n/binom(n,k)$，取期望即得。所有包含某个固定元素的集合取等。

- *修补*：$X$ 为候选体量，$Y$ 为坏结构数，每次删除一项打破一个坏结构，若删除不产生新坏结构，则某次结果保留至少 $EE(X-Y)$。高围长高色数：固定 $g>=3,k>=1$，取 $p=n^(-1+1/(2g))$、$r=ceil(n/(2k))$，记 $C$ 为长度 $<=g$ 的圈数，
  $ EE C<=sum_(ell=3)^g n^ell p^ell/(2ell)=O(sqrt(n)), quad P(C>n/4)=o(1), $
  $ P(alpha(G)>=r)<=binom(n,r)(1-p)^(binom(r,2))<=2^n e^(-p r(r-1)/2)=o(1). $
  同时满足 $C<=n/4,alpha(G)<r$ 的图删掉每个短圈的一点，得 $abs(V')>=3n/4$、围长 $>g$、$chi(G')>=abs(V')/alpha(G')>k$。

- *修补与期望的其他结论*：二元 $n times n$ 矩阵，各项以概率 $p=c n^(-2/(k+1))$ 取 $1$。令 $X$ 为 $1$ 的数目，$Y$ 为全 $1$ 的 $k times k$ 子矩阵数，
  $ EE(X-Y)=n^2p-binom(n,k)^2p^(k^2)>= (c-c^(k^2)) n^(2-2/(k+1)) quad (0<c<1). $
  每个坏子矩阵改一个 $1$ 得所需下界。随机竞赛图中固定次序的 $n-1$ 条边方向全对的概率为 $2^(-(n-1))$；故存在至少 $n! 2^(-(n-1))$ 条 Hamilton 路的竞赛图。

- *无和集合*：有限 $B subset.eq ZZ backslash {0}$。取 $p=3k+2$ 素数且 $p>max_(b in B)abs(b)$，$I=[k+1,2k+1]$ 在模 $p$ 下无和（$I+I$ 落在补集）。对均匀 $x in FF_p^times$，$A_x={b in B:x b in I "模" p}$ 无和，$EE abs(A_x)=abs(B)(k+1)/(3k+1)>=abs(B)/3$。

- *第二矩*：$X>=0$，$0<EE X^2<infinity$。
  $ (EE X)^2=(EE[X 1_(X>0)])^2<=EE X^2 dot P(X>0). $
  $ "Var"X=o((EE X)^2) arrow.r.double P(X>0) arrow.r 1. $
  对计数变量，$EE X^2=sum_(i,j)P(A_i inter A_j)$，按重叠类型拆分。

- *随机图与阈值*：$G(n,p)$ 各边独立，$G(n,m)$ 均匀取 $m$ 边。单调递增性质的阈值 $p_*$ 满足 $p/p_* arrow.r 0, infinity$ 时概率分别趋于 $0,1$；尖锐阈值在固定 $0<epsilon<1$ 的 $(1±epsilon)p_*$ 两侧即达 $0,1$。取 $p_*$ 为性质概率达到 $1/2$ 的点（性质非空且非恒真）。$k$ 份独立 $G(n,p)$ 的并服从 $G(n,1-(1-p)^k)$，全不满足性质的概率为 $(1-P_p)^k$。若 $p/p_* arrow.r infinity$，可选 $k arrow.r infinity$ 使 $1-(1-p_*)^k<=p$，故 $1-P_p<=2^(-k)$；若 $p/p_* arrow.r 0$，选 $k arrow.r infinity$ 使 $1-(1-p)^k<=p_*$，则 $1-(1-P_p)^k<=1/2$，故 $P_p<=1-2^(-1/k) arrow.r 0$。
  
- *连通性下界*：连通性临界尺度 $p_*=ln n/n$。低于窗口取 $p=(ln n-a)/n$、$a arrow.r infinity$ 且 $a=o(ln n)$。孤立点数 $X$：
  $ EE X=n(1-p)^(n-1)∼e^a, quad "Var"X/(EE X)^2<=1/(EE X)+p/(1-p) arrow.r 0. $
  协方差来自 $P(i,j "均孤立")=(1-p)^(2n-3)$。

- *连通性上界*：$p=(ln n+a)/n$，由单调性可设 $a arrow.r infinity,a=o(ln n)$。不连通必有 $1<=s<=n/2$ 的无边割；并界每项 $binom(n,s)(1-p)^(s(n-s))$。若 $s<=n/(ln n)^2$，每项 $<= (e^(1-a+o(1))/s)^s$；若 $s>n/(ln n)^2$，每项 $<= (e(ln n)^2 n^(-1/2))^s$。两段求和均为 $o(1)$。

- *Lovász 局部引理*：$A_i$ 与非邻居事件生成的整体信息独立。若 $P(A_i)<=x_i product_(j in N(i))(1-x_j)$ 且 $0<=x_i<1$，则 $P(inter.big_i A_i^c)>=product_(i) (1-x_i)>0$。归纳证 $P(A_i|inter.big_(j in S)A_j^c)<=x_i$：把 $S$ 分为邻居 $T$ 与非邻居 $U$；分子至多 $P(A_i|inter.big_(j in U)A_j^c)=P(A_i)$，分母按链式法则及归纳至少 $product_(j in T) (1-x_j)$（$T=emptyset$ 时直接独立）。再按链式法则乘各条件补概率。对称版 $e p(d+1)<=1$，$d>=1$ 时取 $x_i=1/(d+1)$。
