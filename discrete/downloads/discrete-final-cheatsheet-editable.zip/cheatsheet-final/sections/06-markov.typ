= 15 · 马尔可夫链

- *定义*：$P(X_(t+1)=y|X_0,dots,X_t)=P(X_(t+1)=y|X_t)$；时间齐次时右式为 $P_(X_t,y)$。$P bold(1)=bold(1)$，行分布 $mu_t=mu_0 P^t$；由全概率 $P^(s+t) (x,y)=sum_z P^(s) (x,z)P^(t) (z,y)$。

- *稳态存在*：$pi P=pi$。有限时，$nu_T=T^(-1)sum_(t=0)^(T-1)mu_0 P^t$ 有收敛子列；由
  $ nu_T P-nu_T=(mu_0 P^T-mu_0)/T arrow.r 0 $
  得极限为稳态。*不可约*：$forall x,y exists t: P^(t) (x,y)>0$。稳态全正：$pi_x>0$ 且 $P^(t) (x,y)>0 arrow.r.double pi_y>=pi_x P^(t) (x,y)>0$。

- *唯一性*：设 $delta=pi-pi'$ 非零，则有 $delta_x>0>delta_y$。取 $P^(t) (x,y)>0$，$Q=(I+P^t)/2$。在 $y$ 坐标正负项严格相消，故
  $ norm(delta)_1=norm(delta Q)_1<sum_(i,j)abs(delta_i)Q_(i,j)=norm(delta)_1, $
  矛盾。

- *到达与返回*：$tau_A=min{t>=0:X_t in A}$，$tau_x^+=min{t>=1:X_t=x}$。$h(x)=EE_x tau_A$ 满足
  $ h|_A=0, quad h(x)=1+sum_y P(x,y)h(y) quad (x in.not A). $
  命中边界的概率在内部满足 $u=P u$（首步分解）。有限不可约链 $EE_x tau_x^+=1/pi_x$：令 $v_y=EE_x sum_(0<=t<tau_x^+)1_(X_t=y)$。首尾同为 $x$，故 $v P=v$；$v_x=1$，$sum_y v_y=EE_x tau_x^+$。归一化即得。

- *周期与收敛*：$d(x)=gcd{t>=1:P^(t) (x,x)>0}$。不可约时周期相同；若再非周期，则某个 $m$ 使 $P^m$ 全正（有限个回返长度的 gcd 为 $1$，生成所有充分大的长度，再接通往各目标的路径）。设 $alpha=sum_y min_x P^(m) (x,y)>0$，各行共享质量 $alpha$，余量至多 $1-alpha$，故
  $ norm(mu P^(k m)-pi)_1<=(1-alpha)^k norm(mu-pi)_1 arrow.r 0. $
  懒化 $(I+P)/2$ 保持稳态，并使不可约链非周期。

- *细致平衡 / MCMC*：$pi_x P(x,y)=pi_y P(y,x) arrow.r.double sum_x pi_x P(x,y)=pi_y$。无向连通图游走 $pi_x=deg(x)/(2abs(E))$。给定目标 $pi>0$、提议 $Q$，接受率
  $ a(x,y)=min(1,(pi_y Q(y,x))/(pi_x Q(x,y))) quad (Q(x,y)>0). $
  拒绝则留原地；两向流量均为 $min(pi_x Q(x,y),pi_y Q(y,x))$。

- *总变差与耦合*：$d_("TV") (mu,nu)=1/2 sum_x abs(mu_x-nu_x)=max_A abs(mu(A)-nu(A))$（取 $A={x:mu_x>=nu_x}$）。
  $ abs(P(X in A)-P(Y in A))<=P(X!=Y). $
  耦合先共享 $min(mu_x,nu_x)$ 的质量，剩余支持不交，故 $min P(X!=Y)=d_("TV") (mu,nu)$。
  $ d(t)=max_x d_("TV") (P^(t) (x,dot),pi), quad t_("mix") (epsilon)=min{t:d(t)<=epsilon}. $
  一条链从 $x$ 出发，另一条从 $pi$ 出发，相遇后同步，$d(t)<=max_x P_(x) (T>t)$。
