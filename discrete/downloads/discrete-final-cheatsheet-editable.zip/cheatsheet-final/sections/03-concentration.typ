= 03 集中：从矩到指数，再到类型

- *Markov／Chebyshev*：$X>=0,a>0$ 时 $P(X>=a)<=EE X/a$，因 $X>=a 1_(X>=a)$。对 $(X-EE X)^2$ 应用它得到 $P(abs(X-EE X)>=t)<="Var"X/t^2$（$t>0$）。iid 有限方差样本均值 $macron(X)_n$ 的方差为 $sigma^2/n$，故依概率收敛到均值；这一步是弱大数定律，不是几乎必然收敛。

- *指数 Markov／Chernoff*：令 $M_X (s)=EE e^(s X)$。上尾取 $s>0$，$P(X>=a)<=e^(-s a)M_X (s)$；下尾取 $s<0$。对独立和 $S=sum X_i$，$M_S=product M_(X_i)$；然后在允许的 $s$ 中最小化。独立性只用于拆乘积；矩母函数须有限。$
  P(S>=a)<=inf_(s>0) exp(-s a+sum_i ln M_(X_i) (s)).
  $

- *Hoeffding 引理与尾界*：$a<=X<=b$、$EE X=0$ 时 $ln EE e^(s X)<=s^(2) (b-a)^2/8$。证明：$psi(s)=ln EE e^(s X)$，$psi''$ 是倾斜分布下的方差，至多 $(b-a)^2/4$；由 $psi(0)=psi'(0)=0$ 积分两次。独立 $X_i in [a_i,b_i]$，令 $V=sum_i (b_i-a_i)^2$，于是
  $ P(S-EE S>=t)<=e^(-2t^2/V), quad P(abs(S-EE S)>=t)<=2e^(-2t^2/V). $
  在 $-s t+s^2V/8$ 中取 $s=4t/V$。变量无界或不独立时不能直接用此式。

- *Bernoulli 的 KL 界*：$S~"Bin"(n,p)$，$p<q<1$。自然对数散度 $d_e (q parallel p)=q ln(q/p)+(1-q)ln((1-q)/(1-p))$。由 $M_S (s)=(1-p+p e^s)^n$，最小化 $ln(1-p+p e^s)-s q$，导数零给
  $ e^(s_*)=(q(1-p))/(p(1-q)), quad P(S>=n q)<=e^(-n d_e (q parallel p)). $
  $q<p$ 时同样推导但 $s_*<0$，对应下尾。散度第一参数是偏离值，第二参数是真实参数。

- *乘法 Chernoff*：独立 Bernoulli（成功率可不同），$mu=EE S$。利用 $1+u<=e^u$ 得 $M_S (s)<=exp(mu(e^s-1))$；令 $e^s=1+delta$，有
  $ P(S>=(1+delta)mu)<=(e^delta/(1+delta)^(1+delta))^mu<=exp(-mu delta^2/(2+delta)) $
  对 $delta>0$ 成立；$0<delta<1$ 时 $P(S<=(1-delta)mu)<=exp(-mu delta^2/2)$。若 $mu=0$，变量几乎必然为零，直接处理。

- *类型（经验分布）*：字母表大小 $r$，样本 $x^n$ 的类型 $Q(a)=N_a/n$。类型数至多 $(n+1)^r$；类型类大小 $abs(T_Q)=n!/(product_a (n Q(a))!)$，满足
  $ (n+1)^(-r)2^(n H(Q))<=abs(T_Q)<=2^(n H(Q)). $
  上界：在分布 $Q$ 下每个该类型序列概率为 $2^(-n H(Q))$，总概率不超过 $1$。下界可由多项式系数界得到。若真实分布为 $P$，每个序列概率为 $2^(-n(H(Q)+D(Q parallel P)))$，故
  $ (n+1)^(-r)2^(-n D(Q parallel P))<=P^(n) (T_Q)<=2^(-n D(Q parallel P)). $
  类型熵在“数量×单个概率”中消掉，只留下散度。

- *Sanov 的有限样本形式*：对类型集合 $cal(A)_n$，若非空，令 $d_n=min_(Q in cal(A)_n)D(Q parallel P)$，则概率夹在 $(n+1)^(-r)2^(-n d_n)$ 与 $(n+1)^(r) 2^(-n d_n)$ 之间。上界并集，下界取一个最小散度类型。取对数除以 $n$，多项式因子消失；要写极限 $-inf_(Q in cal(A))D(Q parallel P)$，须验证可达类型逼近及开闭集的边界条件，不能对任意集合直接宣称等式。

- *选工具*：只知非负均值→Markov；知方差→Chebyshev；独立有界→Hoeffding；独立 Bernoulli→乘法／KL Chernoff；有限字母表的经验分布事件→类型计数与 Sanov。先检查前提，再写事件，最后代参数。

= 指数精度的估计与优化

- *Stirling*：$n!~sqrt(2 pi n)(n/e)^n$，故 $ln n!=n ln n-n+O(ln n)$。只要求多项式因子误差时，$binom(n,alpha n)=2^(n h_(2) (alpha)+O(log n))$（$alpha n$ 整数）。多项式因子在 $1/n log$ 下消失，指数底数不会。

- *三元序列的均值约束*（2025 期末第 5 题）：$x_i in {0,1,2}$ 且 $sum x_i=n$。类型必须满足 $q_0=q_2$；均匀类型符合约束且熵最大为 $log 3$，所以数量为 $3^n$ 的多项式因子范围。上界 $3^n$；下界取三个计数尽量相等且 $n_0=n_2$ 的一个类型，用 Stirling 得 $3^n/n^{O(1)}$。不必计算全部类型之和。

- *两个独立二项和比较*（2024 期末第 10 题）：$X_i~"Bern"(4/5),Y_i~"Bern"(1/2)$ 全独立，$Z_i=Y_i-X_i$。对 $s>0$，
  $ EE e^(s Z_i)=(1/5+4/5 e^(-s))(1/2+1/2 e^s)=1/2+e^s/10+2e^(-s)/5. $
  最小点 $e^s=2$，最小值 $9/10$，因此 $P(sum X_i<=sum Y_i)<=(9/10)^n$。要证明指数底数最优，取两组经验成功率同时约为 $2/3$，该事件概率为 $(9/10)^n/n^{O(1)}$（用类型下界）；所以任何更小常数底数均不成立。

- *倾斜分布解释最优参数*：$P_s (x)=P(x)e^(s x)/M_X (s)$，$Lambda(s)=ln M_X (s)$，则 $Lambda'(s)=EE_(P_s)X$、$Lambda''(s)="Var"_(P_s)X>=0$。优化 $Lambda(s)-s a$ 等价于让新分布均值为 $a$；此时 $D_e (P_s parallel P)=s a-Lambda(s)$。边界值可能只在 $s arrow.r ±infinity$ 达到，需单独处理。
