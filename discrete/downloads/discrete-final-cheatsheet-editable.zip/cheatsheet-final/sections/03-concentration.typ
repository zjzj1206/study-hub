= 12 · 集中不等式与 Sanov

- *Markov 与 Chebyshev*：$X>=0,a>0$，
  $ a 1_(X>=a)<=X arrow.r.double P(X>=a)<=EE X/a. $
  $ P(abs(X-EE X)>=t)=P((X-EE X)^2>=t^2)<="Var"X/t^2 quad(t>0). $
  iid 有限方差时 $P(abs(macron(X)_n-mu)>=t)<=sigma^2/(n t^2) arrow.r 0$。

- *Chernoff*：$M_(X) (t)=EE e^(t X)$。指数 Markov 与独立性给
  $ P(X>=a)<=inf_(t>0) e^(-t a)M_(X) (t), quad M_(sum_i X_i) (t)=product_i M_(X_i) (t). $
  上尾 $t>0$；下尾 $P(X<=a)$ 取 $t<0$。

- *Bernoulli 的指数界*：$S~"Bin"(n,p)$，$0<p<q<1$，令 $g(t)=ln(1-p+p e^t)-t q$。
  $ P(S>=n q)<=inf_(t>0)e^(n g(t)), quad g'(t)=p e^t/(1-p+p e^t)-q. $
  $ g'(t_*)=0 arrow.r.double e^(t_*)=(q(1-p))/(p(1-q)), quad g(t_*)=-D_(e) ("Bern"(q) parallel "Bern"(p)). $
  因此 $P(S>=n q)<=e^(-n D_e)$；$q<p$ 时 $t_*<0$，得下尾。$D_e=(ln 2)D$，以自然对数计算。

- *Stirling*：$n! ∼ sqrt(2 pi n)(n/e)^n$。从阶乘比得
  $ ln binom(n,k)=n h_(e) (k/n)+O(ln(n+1)), quad h_(e) (u)=-u ln u-(1-u)ln(1-u). $

- *类型*：$Omega=[L]$，$s_i=abs({j:x_j=i})$，$q_i=s_i/n$，$T_q={x^n:"type"(x^n)=q}$。
  $ abs(T_q)=n!/(product_i s_i!), quad "类型数"<=K=(n+1)^(L-1). $
  对 $x^n in T_q$，
  $ Q^(n) (x^n)=e^(-n H_(e) (Q)), quad P^(n) (x^n)=e^(-n(H_(e) (Q)+D_(e) (Q parallel P))). $
  $ Q^(n) (T_q)<=1 arrow.r.double abs(T_q)<=e^(n H_(e) (Q)). $
  *下界*：在 $Q$ 下，$q$ 是概率最大的类型之一。若计数向量 $r!=s$ 且 $Q^(n) (T_(r/n))>0$，选 $r_i>s_i,r_j<s_j$，从 $i$ 移一项至 $j$，类型概率乘以
  $ (r_i q_j)/((r_j+1)q_i)=r_i/s_i dot s_j/(r_j+1)>=1. $
  迭代至 $s$，故 $Q^(n) (T_q)>=1/K$，即 $abs(T_q)>=e^(n H_(e) (Q))/K$。

- *Sanov（定理 12.4）*：对非空可达类型集 $cal(A)$，$d=min_(q in cal(A))D_(e) (Q parallel P)$，
  $ K^(-1)e^(-n d)<=P^(n) ("type" in cal(A))<=K e^(-n d). $
  证明：$P^(n) (T_q)=Q^(n) (T_q)e^(-n D_(e) (Q parallel P))$，支持不相容时该概率为零。下界选最小散度类型，上界至多 $K$ 项相加。直观：偏离真实分布的指数代价由 KL 散度决定。
