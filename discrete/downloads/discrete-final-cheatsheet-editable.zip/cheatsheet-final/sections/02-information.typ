= 02 信息论：熵、散度、互信息

- *约定*：本页信息量的 $log$ 默认以 $2$ 为底（bit），$ln$ 为自然对数；$0 log 0=0$。$p>0,q=0$ 时 $p log(p/q)=infinity$。有限字母表上的分布 $P=(p_x)$：
  $ H(X)=-sum_x p_x log p_x, quad D(P parallel Q)=sum_x p_x log(p_x/q_x). $
  条件熵 $H(X|Y)=sum_y p_y H(P_(X|Y=y))$；联合熵 $H(X,Y)$ 对联合分布计算。*熵链式法则* $H(X,Y)=H(Y)+H(X|Y)$：代入 $p_(x y)=p_y p_(x|y)$ 并拆开对数。

- *Gibbs 不等式*：$D(P parallel Q)>=0$，等号当且仅当 $P=Q$。证明：若支持条件满足，用 $ln u<=u-1$ 得 $-sum_(p_x>0)p_x ln(q_x/p_x)>=sum_(p_x>0) (p_x-q_x)>=0$；等号要求支持一致且各比值为 $1$。因此 $0<=H(X)<=log abs(S)$，上界由 $D(P parallel U_S)=log abs(S)-H(P)$ 得到，等号仅在均匀分布；下界等号为常变量。

- *互信息*衡量依赖：
  $ I(X;Y)=D(P_(X Y) parallel P_X P_Y)=H(X)+H(Y)-H(X,Y)=H(X)-H(X|Y)>=0. $
  等号等价于独立。$I(X;Y|Z)=sum_z p_z D(P_(X Y|z) parallel P_(X|z)P_(Y|z))>=0$，等号等价于给定 $Z$ 后条件独立。所以 $H(X|Y,Z)<=H(X|Y)<=H(X)$，以及 $H(X_1,dots,X_n)<=sum_i H(X_i)$，后者等号当且仅当相互独立。

- *链式法则*：$H(X_1,dots,X_n)=sum_i H(X_i|X_1,dots,X_(i-1))$；$I(X;Y,Z)=I(X;Y)+I(X;Z|Y)$。散度也满足
  $ D(P_(X Y) parallel Q_(X Y))=D(P_X parallel Q_X)+sum_x p_x D(P_(Y|x) parallel Q_(Y|x)). $
  证明均为联合概率分解后拆对数，再求和；不满足绝对连续时注意无穷值，不做 $infinity-infinity$。

- *数据处理不等式*：$X arrow.r Y arrow.r Z$ 表示给定 $Y$ 后 $X,Z$ 条件独立，则 $I(X;Z)<=I(X;Y)$。证明：$I(X;Y,Z)=I(X;Y)$，另一方面它等于 $I(X;Z)+I(X;Y|Z)>=I(X;Z)$。确定性函数不增加熵：$H(f(X))<=H(X)$，因为 $H(f(X)|X)=0$。

- *凹性与最大熵*：熵关于分布凹；给定混合标签 $J$，$H(X)>=H(X|J)=sum_j p_j H(P_j)$ 即证。有限字母表，约束 $EE f(X)=a$ 时，候选最大熵分布 $q_x=e^(lambda f(x))/Z$；若它满足约束，则 $D(P parallel Q)>=0$ 给 $H(P)<=log Z-lambda a/ln 2$，且等号仅为 $P=Q$。参数符号由约束决定，不能预设。非负整数、固定均值时最大熵为从 $0$ 起的几何分布。

- *总变差与 Pinsker*：$d_("TV") (P,Q)=1/2 sum_x abs(p_x-q_x)=max_A abs(P(A)-Q(A))$。$D(P parallel Q)>=(2/ln 2)d_("TV") (P,Q)^2$（本页 bit）；若散度用 $ln$，常数为 $2$。不要把两种底数的常数混用。


= 证明工具与反例

- *Log-sum 不等式*：非负 $a_i,b_i$，记 $A=sum a_i,B=sum b_i$，则 $sum_i a_i log(a_i/b_i)>=A log(A/B)$。当 $A,B>0$，除以 $A$ 后左减右就是分布 $a_i/A$ 相对 $b_i/B$ 的散度；零项按约定取极限。合并样本空间中的若干点会降低散度；对信道输出逐项应用即得 $D(P W parallel Q W)<=D(P parallel Q)$。

- *小总变差不保证小 KL*（2025 期末第 4 题）：取 $P=(1-epsilon,epsilon)$，$Q=(1,0)$，则 $d_("TV") (P,Q)=epsilon$，但 $D(P parallel Q)=infinity$。即便要求全支持，也可令 $Q$ 的第二分量远小于 $epsilon$，使 $epsilon log(epsilon/q_2)$ 很大。Pinsker 只能推出“小 KL ⇒ 小总变差”。

- *常用熵的层次*：$H_(min) (X)=-log max_x p_x$；碰撞熵 $H_(2) (X)=-log sum_x p_x^2$；$H_(max) (X)=log abs("supp"P)$。有 $H_(min)<=H_2<=H<=H_(max)$。第一步用 $sum p_x^2<=max p_x$；第二步由 $-log$ 凸，$EE[-log p_X]>=-log EE p_X$；末步由均匀分布的散度。iid 副本 $X,Y$ 碰撞概率为 $sum p_x^2=2^(-H_2)$。

- *互信息计算表*：先列联合概率表，求边缘，再选最短表达式。若 $Y=f(X)$，$I(X;Y)=H(Y)$；若 $Y=X ⊕ Z$、$X$ 公平且 $Z~"Bern"(p)$ 独立，则 $Y$ 公平、$H(Y|X)=h_(2) (p)$，所以 $I(X;Y)=1-h_(2) (p)$。独立不等于条件独立：公平独立比特 $X,Y$ 在给定 $X ⊕ Y$ 后相关。
