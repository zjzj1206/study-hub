= 11 · 熵、散度与互信息

- *记号*：本页 $log=log_2$；$0 log 0=0$；$P(x)>0=Q(x)$ 时 $D(P parallel Q)=infinity$。条件量只对正概率条件加权。

- *熵与条件熵*：
  $ H(X)=-sum_x p_(X) (x)log p_(X) (x), quad H(X|Y)=sum_y p_(Y) (y)H(P_(X|Y=y)). $
  $ p_(X,Y)=p_Y p_(X|Y) arrow.r.double H(X,Y)=H(Y)+H(X|Y). $
  迭代得 $H(X_1,dots,X_n)=sum_i H(X_i|X_1,dots,X_(i-1))$。若 $Y=f(X)$，则 $H(Y|X)=0$，故 $H(Y)<=H(X)$。

- *KL 散度*：$D(P parallel Q)=sum_(x:p_x>0)p_x log(p_x/q_x)$。由 $ln u<=u-1$，
  $ (ln 2)D(P parallel Q)>=sum_(x:p_x>0) (p_x-q_x)>=0. $
  等号 $⇔ P=Q$。设 $U$ 是有限字母表 $cal(X)$ 上的均匀分布，
  $ D(P parallel U)=log abs(cal(X))-H(P) arrow.r.double 0<=H(P)<=log abs(cal(X)). $
  下界等号为点质量，上界等号为均匀分布。

- *互信息*：
  $ I(X;Y)=sum_(x,y)p_(x,y)log(p_(x,y)/(p_x p_y))=D(P_(X,Y) parallel P_X P_Y). $
  $ I(X;Y)=H(X)+H(Y)-H(X,Y)=H(X)-H(X|Y)=H(Y)-H(Y|X). $
  展开对数并按边缘求和即得。$I(X;Y)>=0$，等号 $⇔ X,Y$ 独立。因此 $H(X|Y)<=H(X)$，且 $H(X_1,dots,X_n)<=sum_i H(X_i)$。

- *条件互信息与链式法则*：
  $ I(X;Y|Z)=sum_z p_z D(P_(X,Y|z) parallel P_(X|z)P_(Y|z))=H(X|Z)-H(X|Y,Z)>=0. $
  $ I(X;Y,Z)=underbrace(H(X)-H(X|Y),I(X;Y))+underbrace(H(X|Y)-H(X|Y,Z),I(X;Z|Y)). $

- *数据处理*：$X arrow.r Y arrow.r Z$ 表示 $P_(X,Z|Y)=P_(X|Y)P_(Z|Y)$。因此
  $ I(X;Z)<=I(X;Z)+I(X;Y|Z)=I(X;Y,Z)=I(X;Y)+0. $
  直观：后续处理只能保留或损失关于输入的信息。

- *条件散度*：$D(P_(Y|X) parallel Q_(Y|X) | P_X)=sum_x p_x D(P_(Y|X=x) parallel Q_(Y|X=x))$。
  $ log(p_(x,y)/q_(x,y))=log(p_x/q_x)+log(p_(y|x)/q_(y|x)) $
  $ arrow.r.double D(P_(X,Y) parallel Q_(X,Y))=D(P_X parallel Q_X)+D(P_(Y|X) parallel Q_(Y|X)|P_X). $
  对同一随机处理 $W$，$p_(x,y)=p_x W(y|x),q_(x,y)=q_x W(y|x)$，条件散度为零。改按 $Y$ 先展开，得输出散度 $D(P_Y parallel Q_Y)<=D(P parallel Q)$。

- *熵的凹性*：$P=sum_j w_j P_j$，令 $P_(X|J=j)=P_j$、$P(J=j)=w_j$，则 $H(P)-sum_j w_j H(P_j)=I(X;J)>=0$。
