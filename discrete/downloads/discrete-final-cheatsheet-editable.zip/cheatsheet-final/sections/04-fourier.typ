= 13 · 离散 Fourier 变换

- *特征标*：$G=product_j ZZ_(n_j)$（加法），$N=abs(G)$。$chi:G arrow.r S^1$ 为群同态，
  $ chi_(a) (x)=product_j exp(2 pi i a_j x_j/n_j), quad chi_a chi_b=chi_(a+b), quad macron(chi_a)=chi_(-a), quad chi_(a) (x)=chi_(x) (a). $
  $S=sum_x chi(x)$，$chi(y)S=sum_x chi(x+y)=S$。非平凡 $chi$ 取 $chi(y)!=1$，得 $S=0$。因此
  $ 1/N sum_x chi_(a) (x)macron(chi_(b) (x))=1_(a=b). $
  上式给出 $N$ 个正交向量，达到 $CC^G$ 的维数；任何额外特征标也须与这组基正交，故不存在。

- *变换与逆变换*（讲义归一化）：
  $ hat(f)(a)=1/N sum_(x in G) f(x)macron(chi_(a) (x)), quad f(x)=sum_(a in G)hat(f)(a)chi_(a) (x). $
  $ sum_a hat(f)(a)chi_(a) (x)=sum_y f(y) underbrace((1/N sum_a chi_(a) (x-y)),1_(x=y))=f(x). $

- *Plancherel / Parseval*：按平均内积，
  $ 1/N sum_x f(x)macron(g(x))=sum_a hat(f)(a)macron(hat(g)(a)). $
  展开 $f,g$ 后正交性消去 $a!=b$；取 $g=f$ 得 $EE abs(f)^2=sum_a abs(hat(f)(a))^2$。

- *卷积*：$(f*g)(x)=sum_y f(y)g(x-y)$。
  $ hat(f*g)(a)=1/N sum_(y,z) f(y)g(z)macron(chi_(a) (y+z))=N hat(f)(a)hat(g)(a). $
  逐点乘积满足 $hat(f g)(c)=sum_(a+b=c)hat(f)(a)hat(g)(b)$，因为 $chi_a chi_b=chi_(a+b)$。直观：平移对特征标只乘一个相位，故卷积变为逐频率相乘。

- *布尔立方体*：$x in {0,1}^n$ 均匀，$S subset.eq [n]$，
  $ chi_(S) (x)=(-1)^(sum_(i in S)x_i), quad chi_S chi_T=chi_(S △ T), quad EE chi_S chi_T=1_(S=T). $
  $ f=sum_S hat(f)(S)chi_S, quad hat(f)(S)=EE[f chi_S], quad EE f=hat(f)(emptyset), quad "Var"f=sum_(S!=emptyset)hat(f)(S)^2. $
  最后一式对实值 $f$，由 Parseval 减去均值平方。

- *随机限制*（命题 13.4）：$A subset.eq [n]$，$f_(A arrow.l alpha)$ 将 $A$ 中坐标固定为 $alpha$。由逐项代入，
  $ chi_T(x_(A arrow.l alpha))=chi_(T inter A)(alpha)chi_(T backslash A)(x). $
  对均匀 $alpha$ 取期望，$T inter A!=emptyset$ 的项消失。故
  $ EE_alpha [hat(f_(A arrow.l alpha))(S)]=1_(S inter A=emptyset)hat(f)(S). $
  各坐标独立地以概率 $1-p$ 固定，$P(S inter A=emptyset)=p^abs(S)$，因此
  $ EE_(A,alpha) [hat(f_(A arrow.l alpha))(S)]=p^abs(S)hat(f)(S). $
  直观：阶数越高，所依赖的坐标越容易有一个被固定。
