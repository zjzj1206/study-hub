= 13 · 离散 Fourier 变换

== 特征标与正交性

我们想将群上的函数拆成一些对平移行为很简单的函数。特征标就是从加法群到单位圆乘法群的同态，满足 $chi(x+y)=chi(x)chi(y)$。因此把输入平移 $y$，只会把整个函数乘上固定的复数 $chi(y)$。

$G=product_j ZZ_(n_j)$（加法），$N=abs(G)$。$chi:G arrow.r S^1$ 为群同态，
$ chi_(a) (x)=product_j exp(2 pi i a_j x_j/n_j), quad chi_a chi_b=chi_(a+b), quad macron(chi_a)=chi_(-a), quad chi_(a) (x)=chi_(x) (a). $
$S=sum_x chi(x)$，$chi(y)S=sum_x chi(x+y)=S$。非平凡 $chi$ 取 $chi(y)!=1$，得 $S=0$。因此
$ 1/N sum_x chi_(a) (x)macron(chi_(b) (x))=1_(a=b). $
上式给出 $N$ 个正交向量，达到 $CC^G$ 的维数；任何额外特征标也须与这组基正交，故不存在。

不同特征标的内积化为它们的商在全群上的求和。对非平凡特征标，平移不改求和结果，却将它乘以某个不等于一的数，所以这项和只能是零。

== 系数与反演

既然特征标是一组正交基，就可以通过内积取出函数在每个方向上的系数。本文按讲义在正变换中除以群的大小 $N$。反演时直接把各系数乘回相应基函数再相加。

$ hat(f)(a)=1/N sum_(x in G) f(x)macron(chi_(a) (x)), quad f(x)=sum_(a in G)hat(f)(a)chi_(a) (x). $
$ sum_a hat(f)(a)chi_(a) (x)=sum_y f(y) underbrace((1/N sum_a chi_(a) (x-y)),1_(x=y))=f(x). $

证明反演公式时，将系数的定义代回，把两个有限和交换。正交性使 $x!=y$ 的项全部消失，只留下 $f(x)$。

== 内积和平方和

在原空间，用所有位置上的乘积平均定义内积，其中第二个因子取复共轭。转换到 Fourier 系数之后，内积变成同频率系数乘积之和。

按平均内积，
$ 1/N sum_x f(x)macron(g(x))=sum_a hat(f)(a)macron(hat(g)(a)). $
展开 $f,g$ 后正交性消去 $a!=b$；取 $g=f$ 得 $EE abs(f)^2=sum_a abs(hat(f)(a))^2$。

把两边的函数都展开为特征标的线性组合。相乘会产生同频和异频项，正交性恰好消去异频项。对同一函数取内积得到 Parseval 等式。

== 卷积与乘积

卷积先固定总和 $x$，再对所有分解 $x=y+z$ 的乘积 $f(y)g(z)$ 求和。对群上的独立随机变量，和的分布也由这种运算给出。

$(f*g)(x)=sum_y f(y)g(x-y)$。
$ hat(f*g)(a)=1/N sum_(y,z) f(y)g(z)macron(chi_(a) (y+z))=N hat(f)(a)hat(g)(a). $
逐点乘积满足 $hat(f g)(c)=sum_(a+b=c)hat(f)(a)hat(g)(b)$，因为 $chi_a chi_b=chi_(a+b)$。直观：平移对特征标只乘一个相位，故卷积变为逐频率相乘。

求卷积的 Fourier 系数时，用 $z=x-y$ 把求和指标改成相互独立的 $y,z$。由于特征标在加法下分解成乘积，双重和随之分成两个单和。

== 布尔立方体的 Fourier 展开

输入是长度为 $n$ 的比特串，按逐坐标模二相加构成一个群。频率可以用坐标子集表示，特征标的值由这组坐标中一的个数是奇数还是偶数决定。

$x in {0,1}^n$ 均匀，$S subset.eq [n]$，
$ chi_(S) (x)=(-1)^(sum_(i in S)x_i), quad chi_S chi_T=chi_(S △ T), quad EE chi_S chi_T=1_(S=T). $
$ f=sum_S hat(f)(S)chi_S, quad hat(f)(S)=EE[f chi_S], quad EE f=hat(f)(emptyset), quad "Var"f=sum_(S!=emptyset)hat(f)(S)^2. $
最后一式对实值 $f$，由 Parseval 减去均值平方。

均匀取输入时，非空子集的奇偶性取两个值的概率相同，因此相应特征标的均值为零。两个特征标相乘时，出现两次的坐标抵消，留下对称差。

== 固定部分坐标与随机限制

选定一组坐标 $A$，再将这些坐标固定为一组比特值 $alpha$，其余坐标仍可自由变化。固定后，原来依赖于 $A$ 中坐标的特征标会把这些坐标的作用变成一个符号因子。

$A subset.eq [n]$，$f_(A arrow.l alpha)$ 将 $A$ 中坐标固定为 $alpha$。由逐项代入，
$ chi_T(x_(A arrow.l alpha))=chi_(T inter A)(alpha)chi_(T backslash A)(x). $
对均匀 $alpha$ 取期望，$T inter A!=emptyset$ 的项消失。故
$ EE_alpha [hat(f_(A arrow.l alpha))(S)]=1_(S inter A=emptyset)hat(f)(S). $
各坐标独立地以概率 $1-p$ 固定，$P(S inter A=emptyset)=p^abs(S)$，因此
$ EE_(A,alpha) [hat(f_(A arrow.l alpha))(S)]=p^abs(S)hat(f)(S). $
直观：阶数越高，所依赖的坐标越容易有一个被固定。

若固定值是独立均匀的，凡是涉及至少一个被固定坐标的原 Fourier 项，其符号因子平均为零。接着对坐标集合本身平均，一个频率项被保留的概率正是它涉及的全部坐标都未被固定的概率。
