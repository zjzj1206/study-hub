= 04 离散 Fourier：固定归一化再计算

- *循环 DFT*：下标在 $ZZ"/"n ZZ$，$omega=e^(2 pi i/n)$，采用正向不归一化约定：
  $ hat(f)(k)=sum_(x=0)^(n-1) f(x)omega^(-k x), quad f(x)=1/n sum_(k=0)^(n-1)hat(f)(k)omega^(k x). $
  *正交性*：$sum_(x=0)^(n-1)omega^(k x)$ 在 $n ∣ k$ 时为 $n$，否则为 $0$；后者是公比非 $1$ 的几何级数。逆式代入正变换后，内和 $1/n sum_k omega^(k(x-y))$ 只保留 $y=x$。

- *Parseval 与卷积*：复共轭记 $macron(z)$，内积 $lr(⟨ f,g ⟩)=sum_x f(x)macron(g(x))$，于是
  $ sum_x abs(f(x))^2=1/n sum_k abs(hat(f)(k))^2. $
  定义循环卷积 $(f*g)(x)=sum_y f(y)g(x-y)$，则 $hat(f*g)(k)=hat(f)(k)hat(g)(k)$。证明：换元 $z=x-y$，$omega^(-k(y+z))$ 分解成两因子，双重和变成两和乘积。乘积公式 $hat(f g)(k)=1/n sum_j hat(f)(j)hat(g)(k-j)$。实值 $f$ 满足 $hat(f)(-k)=macron(hat(f)(k))$。

- *例／FFT*：$f=(1,2,0,0)$ 的四点变换为 $(3,1-2i,-1,1+2i)$；频域平方和 $20$，除以 $4$ 为原平方和 $5$。$n=2^m$ 时拆奇偶下标，$T(n)=2T(n/2)+O(n)$，得 $O(n log n)$。多项式长度为 $a,b$，零填充到至少 $a+b-1$，再变换相乘；否则得到的是模 $x^n-1$ 的乘法，系数会绕回。

- *有限 Abel 群*：特征标是同态 $chi:G arrow.r {z in CC:abs(z)=1}$。非平凡特征标和为零：取 $a$ 使 $chi(a)!=1$，平移求和得 $sum chi=chi(a)sum chi$。不同特征标正交，共 $abs(G)$ 个，构成函数空间基。此处改用平均内积与归一化系数：
  $ hat(f)(chi)=1/abs(G) sum_x f(x)macron(chi(x)), quad f(x)=sum_chi hat(f)(chi)chi(x). $
  则 $EE abs(f)^2=sum_chi abs(hat(f)(chi))^2$；若卷积也取平均 $EE_y f(y)g(x-y)$，其变换仍为系数相乘。*正反变换和卷积的归一化必须成套使用*。

- *布尔立方体*：$x in {-1,1}^n$ 均匀，$chi_S (x)=product_(i in S)x_i$，$chi_emptyset=1$。$EE chi_S chi_T=1_(S=T)$，因为非空对称差中至少有一个均值零的独立坐标。共有 $2^n$ 个正交函数，故成基：
  $ f=sum_(S subset.eq [n])hat(f)(S)chi_S, quad hat(f)(S)=EE(f chi_S), quad "Var"f=sum_(S!=emptyset)hat(f)(S)^2. $
  对实值 $f$，$EE f=hat(f)(emptyset)$，$EE f^2=sum_S hat(f)(S)^2$。

- *影响与噪声*：布尔值 $f in {-1,1}$，翻转第 $i$ 位为 $x^(⊕ i)$；$D_i f=(f(x)-f(x^(⊕ i)))/2$ 只保留含 $i$ 的 Fourier 项，故
  $ "Inf"_i (f)=P(f(x)!=f(x^(⊕ i)))=sum_(S: i in S)hat(f)(S)^2. $
  总影响为 $sum_S abs(S)hat(f)(S)^2$。各坐标以 $(1-rho)/2$ 独立翻转，$T_(rho) f(x)=EE(f(Y)|X=x)$；由每个坐标条件均值为 $rho x_i$，得 $T_(rho) chi_S=rho^(abs) (S)chi_S$，噪声稳定性 $EE[f(X)f(Y)]=sum_S rho^(abs) (S)hat(f)(S)^2$。


= 两种布尔记号与题型

- *从 $0/1$ 到 $±1$*：若 $x in {0,1}^n$，用 $chi_S (x)=(-1)^(sum_(i in S)x_i)$；取 $z_i=(-1)^(x_i)$ 后就是前面的坐标乘积。向量索引 $y in {0,1}^n$ 与子集 $S={i:y_i=1}$ 对应，$chi_y (x)=(-1)^(x dot y)$，点积按模 $2$。

- *翻转概率与相关系数不同*（2024 期末第 11 题）：若题中噪声为 $Z_i~"Bern"(eta)$，算子 $T f(x)=EE f(x ⊕ Z)$，则
  $ hat(T f)(S)=(1-2eta)^(abs) (S)hat(f)(S). $
  证明：$chi_S (x ⊕ Z)=chi_S (x)chi_S (Z)$，独立性给 $EE chi_S (Z)=product_(i in S)EE(-1)^(Z_i)=(1-2eta)^(abs) (S)$。因此本页的相关参数 $rho=1-2eta$；不能把翻转概率直接代入 $rho^(abs) (S)$。

- *一个完整例子*：$f:{-1,1}^2 arrow.r {-1,1}$ 仅在 $(1,1)$ 取 $1$，其余取 $-1$。逐点计算或展开得 $f=(-1+x_1+x_2+x_1 x_2)/2$。均值 $-1/2$，方差 $3/4$；两个坐标影响均为 $1/2$；$T_rho f=(-1+rho x_1+rho x_2+rho^2 x_1 x_2)/2$。平方系数和为 $1$，可用来检查漏项。

- *平移／差分*：循环群上 $g(x)=f(x+a)$，则 $hat(g)(k)=omega^(k a)hat(f)(k)$。差分 $Delta f(x)=f(x+1)-f(x)$ 的乘子为 $omega^k-1$。均值是零频项，平移不改变零频；做卷积递推或随机游走时，把平移的和变成频率上的乘法与幂。

- *Fourier 解随机游走*：有限 Abel 群上每步加一个独立增量，分布为 $mu$。角色 $chi$ 的转移特征值为 $EE_(Z~mu)chi(Z)$。经过 $t$ 步，对应系数乘该特征值的 $t$ 次幂；所有非平凡特征值模小于 $1$ 才收敛到均匀分布。若出现模为 $1$ 的非平凡特征值，要检查周期或不可约性。
