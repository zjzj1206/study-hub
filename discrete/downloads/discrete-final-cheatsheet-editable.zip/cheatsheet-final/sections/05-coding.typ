= 14 · 压缩与信道编码

- *熵的层次*：$H_min=-log max_x p_x<=H_2=-log sum_x p_x^2<=H=EE[-log p_X]<=H_max=log abs("supp" P)$。依次用 $sum p_x^2<=max p_x$、Jensen、$D(P parallel U)>=0$。

- *无损码*：前缀码 $arrow.r.double$ 唯一可译 $arrow.r.double$ 单射。二元前缀码长 $ell_x$ 满足 Kraft：$K=sum_x 2^(-ell_x)<=1$。深度 $L=max ell_x$，码字占用互斥的 $2^(L-ell_x)$ 片叶；反向按长度递增选空闲结点，选择深度 $ell$ 时可用数为 $2^(ell) (1-sum_("已选")2^(-ell_x))>=1$。
  $ q_x=2^(-ell_x)/K arrow.r.double EE ell_X=H(P)+D(P parallel Q)-log K>=H(P). $
  取 $ell_x=ceil(-log p_x)$，则 $K<=1$ 且 $H<=EE ell_X<H+1$。Huffman：交换使最小两权落在最深兄弟叶；收缩该对后，总代价减少其权重之和，归纳得最优。

- *几乎无损块压缩*：iid 下 $-1/n log P(X^n) arrow.r H$（依概率）。典型集 $T$ 上 $2^(-n(H+epsilon))<=P(x^n)<=2^(-n(H-epsilon))$，且 $P(T) arrow.r 1$。故 $abs(T)<=2^(n(H+epsilon))$，编码其索引即可。反向：至多 $2^(n R)$ 个序列可正确恢复，$P_("成功")<=P(T^c)+2^(n(R-H+epsilon))$。最优渐近速率为 $H$。

- *通用与旁信息*：先编码类型，再编码类型类内序号，长度 $<=O(log n)+n H(Q)$，$Q arrow.r P$。解码端已知 $Y^n$：随机分箱，对给定 $y^n$，候选数 $<=2^(n(H(X|Y)+epsilon))$，同箱概率 $2^(-n R)$，并界得 $R>H(X|Y)$。分别编码 $X,Y$ 时，按竞争序列只错 $X$、只错 $Y$、两者都错三类，依次得到
  $ R_X>H(X|Y), quad R_Y>H(Y|X), quad R_X+R_Y>H(X,Y). $

- *容量*：无记忆信道 $W^(n) (y^n|x^n)=product_i W(y_i|x_i)$，$C=max_(P_X) I(X;Y)$。BSC 翻转率 $p$：$I(X;Y)=H(Y)-h_(2) (p)<=1-h_(2) (p)$，均匀输入取等。BEC 擦除率 $epsilon$：$H(X|Y)=epsilon H(X)$，故 $C=1-epsilon$。重复码奇数次多数判决，错误率 $P("Bin"(L,p)>L/2)$，$p<1/2$ 时随 $L$ 指数衰减，速率 $1/L$。

- *随机线性码*：选均匀二元 $k times n$ 矩阵 $G$。任意 $u!=0$，$u G$ 均匀。BSC 最近典型噪声解码，给定真实噪声 $z in T$，错误需 $u G in z+T$ 对某个 $u!=0$：
  $ P_e<=P(Z in.not T)+2^k abs(T)/2^n arrow.r 0 quad "若" quad k/n<1-h_(2) (p). $
  BEC 给定 $r$ 个未擦除坐标，错误需某个 $u!=0$ 的投影为零，并界为 $2^(k-r)$，故 $k/n<1-epsilon$ 可达。

- *容量上界*：均匀消息 $U$，$M$ 个值，经 $n$ 次信道使用得到估计 $hat(U)$，$E=1_(hat(U)!=U)$，$P_e=P(E=1)$。
  $ H(U|hat(U))=H(E|hat(U))+H(U|E,hat(U))<=h_2(P_e)+P_e log(M-1). $
  $ I(U;hat(U))<=I(X^n;Y^n)<=sum_i I(X_i;Y_i)<=n C. $
  第二步用 $H(Y^n)<=sum_i H(Y_i)$ 与 $H(Y^n|X^n)=sum_i H(Y_i|X_i)$。故 $(1-P_e)log M<=n C+h_2(P_e)$。

- *距离与 RS*：$d_min=min_(c!=c')d_(H) (c,c')$。检 $d_min-1$ 错，纠 $t=floor((d_min-1)/2)$ 错（半径 $t$ 球不交）。随机二元码 $M$ 词、长 $L$，每对距离 $~"Bin"(L,1/2)$，故 $P(d_min<=delta L)<=binom(M,2)2^(-L(1-h_(2) (delta)))$（$delta<1/2$）。
  RS 在 $L$ 个不同点评价 $deg f<k$，$d_min=L-k+1$（非零差多项式至多 $k-1$ 根，且可恰取 $k-1$ 根）。收词 $y_i$，求 $Q(a_i)=y_i E(a_i)$，$deg E<=t,deg Q<k+t,E!=0$。错误定位多项式给出解；$Q-f E$ 在至少 $L-t>=k+t$ 点为零，故 $Q=f E$，由 $Q/E$ 恢复。
