// 复习稿按章节组织，正文自然分页。
#let body-size = 12pt
#let ink = rgb("243447")
#let accent = rgb("275D73")
#set document(title: "离散数学与结构 (I) · 期末复习稿", author: "课程复习资料")
#set page(paper: "a4", flipped: false, margin: (x: 8mm, top: 7mm, bottom: 8mm), footer: context align(right, text(size: 6pt, fill: ink)[离散数学与结构 (I) · 期中后 · 不含 Galois　/　#counter(page).display()]))
#set text(font: "Noto Serif CJK SC", size: body-size, fill: rgb("202830"), lang: "zh")
#set par(justify: false, leading: 4pt, spacing: 6pt)
#set math.equation(numbering: none)
#show math.equation: set text(size: body-size)
// 高公式保留真实高度，并加上下缓冲；过宽公式仍允许原生换行。
#show math.equation.where(block: false): it => context {
  let full = {
    set text(top-edge: "bounds", bottom-edge: "bounds")
    it
  }
  let sz = measure(full)
  if sz.height > 1.6 * body-size and sz.width < 190mm {
    box(inset: (y: 1pt), full)
  } else { it }
}
#set heading(numbering: none)
#show heading.where(level: 2): set text(font: "Noto Sans CJK SC", size: 12pt, fill: ink)
#show heading.where(level: 1): it => block(above: 5pt, below: 4pt, width: 100%, sticky: true, stack(spacing: 2pt,
  text(font: "Noto Sans CJK SC", size: 14pt, weight: "bold", fill: accent, it.body),
  line(length: 100%, stroke: .55pt + accent)))
#show strong: set text(font: "Noto Sans CJK SC", weight: "bold", fill: ink)

#set page(margin: (x: 9mm, top: 16mm, bottom: 10mm),
  header: grid(columns: (1fr, auto),
    text(font: "Noto Sans CJK SC", size: 11pt, weight: "bold", fill: ink)[离散数学与结构 (I)],
    text(size: 7pt, fill: accent)[期末 · 期中后内容]))
#include "sections/01-probability.typ"

#include "sections/02-information.typ"

#include "sections/03-concentration.typ"

#include "sections/04-fourier.typ"

#include "sections/05-coding.typ"

#include "sections/06-markov.typ"

#include "sections/07-graphs.typ"

#include "sections/08-method.typ"
