// 八个期末主题，每主题一页；单栏便于阅读长公式。
#let body-size = 11pt
#let column-gap = 6mm
#let ink = rgb("243447")
#let accent = rgb("275D73")
#set document(title: "离散数学与结构 (I) · 期末速查", author: "课程复习资料")
#set page(paper: "a4", flipped: false, margin: (x: 8mm, top: 7mm, bottom: 8mm), footer: context align(right, text(size: 6pt, fill: ink)[离散数学与结构 (I) · 期中后 · 不含 Galois　/　#counter(page).display() / 8]))
#set text(font: "Noto Serif CJK SC", size: body-size, fill: rgb("202830"), lang: "zh")
#set par(justify: false, leading: 3.5pt, spacing: 3pt)
#set math.equation(numbering: none)
#show math.equation: set text(size: body-size)
// 高公式保留真实高度，并加上下缓冲；过宽公式仍允许原生换行。
#show math.equation.where(block: false): it => context {
  let full = {
    set text(top-edge: "bounds", bottom-edge: "bounds")
    it
  }
  let sz = measure(full)
  if sz.height > 1.6 * body-size and sz.width < 190mm {
    box(inset: (y: 1pt), full)
  } else { it }
}
#set heading(numbering: none)
#show heading.where(level: 1): it => block(above: 5pt, below: 4pt, width: 100%, sticky: true, stack(spacing: 2pt,
  text(font: "Noto Sans CJK SC", size: 14pt, weight: "bold", fill: accent, it.body),
  line(length: 100%, stroke: .55pt + accent)))
// 圆点直径 2.2pt，与正文间隔 3pt。
#set list(indent: 0pt, body-indent: 3pt, spacing: 5pt, marker: box(baseline: -2pt, circle(radius: 1.1pt, fill: accent, stroke: none)))
#show strong: set text(font: "Noto Sans CJK SC", weight: "bold", fill: ink)

#set page(margin: (x: 9mm, top: 16mm, bottom: 10mm),
  header: grid(columns: (1fr, auto),
    text(font: "Noto Sans CJK SC", size: 11pt, weight: "bold", fill: ink)[离散数学与结构 (I)],
    text(size: 7pt, fill: accent)[期末 · 期中后内容]))
#block[#include "sections/01-probability.typ"]

#pagebreak()
#block[#include "sections/02-information.typ"]

#pagebreak()
#block[#include "sections/03-concentration.typ"]

#pagebreak()
#block[#include "sections/04-fourier.typ"]

#pagebreak()
#block[#include "sections/05-coding.typ"]

#pagebreak()
#block[#include "sections/06-markov.typ"]

#pagebreak()
#block[#include "sections/07-graphs.typ"]

#pagebreak()
#block[#include "sections/08-method.typ"]
