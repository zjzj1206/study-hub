# 离散数学与结构 (I) · 期末 cheatsheet

8 页纵向 A4（4 张纸双面），每页单栏。独立 Typst 源码，不修改期中 cheatsheet。

## 范围依据

按用户 2026-11-10 的确认：**期末与期中范围不交；Galois 不考。** 本版不收录集合、逻辑、基础、数论、群环域、计数、生成函数、Burnside/Pólya 的复习章节，也不收录 Galois。后续主题中的概率生成函数、概率方法所需的简单计数工具仍就地使用。

课程主页 https://liutianren.com/discrete/ 于 2026-11-10 核对：2026 年的基本计数列在期中前；生成函数与 Burnside/Pólya 也列于期中条目之前，但日期原文为 Nov 27 / Nov 29，与 Nov 3 期中的顺序冲突，不能擅自视为已核实日期。Galois 原列 Nov 5（预计），按用户明确说明排除。主页尚未给出本学期完整后续进度，因此下面八个主题是参考 2025 完整笔记与后半学期安排的**可修改工作稿，不是已确认的本学期期末考纲**。待新进度发布后，按实际课堂取舍。

## 八面内容

1. 概率：条件概率、独立、矩、条件期望、常见分布、PGF、配对问题。
2. 信息论：熵、KL、互信息、链式法则、数据处理、熵层次与反例。
3. 集中：Markov、Chebyshev、Chernoff、Hoeffding、类型与 Sanov、指数优化。
4. Fourier：DFT、卷积、Parseval、特征标、布尔分析、噪声算子。
5. 编码：Kraft、Huffman、典型集、容量、Fano、线性码、旁信息与随机编码。
6. Markov：稳态、可逆、到达返回、耦合、谱、混合时间与常见模型。
7. 图论：树、匹配、平面、矩阵、谱、染色、对偶、加权树计数。
8. 概率方法：第一／二阶矩、修补、随机排列、局部引理、阈值。

定义与推导放在相邻条目；往年题只选方法，不复制整份试卷。2024/2025 题号指本地对应正式期末卷。往年题出现不表示本学期必考。

## 一条命令构建

在项目根目录执行：

```bash
bash cheatsheet-final/build.sh
```

优先复用本目录或原期中 cheatsheet 的已安装环境；均不可用时创建本目录的 `.venv` 并按 requirements.txt 安装依赖（需要可用网络或本地缓存）。已安装 Typst Python 包时也可以直接执行 `python cheatsheet-final/build.py`。项目现有环境可使用：

```bash
cheatsheet/.venv/bin/python cheatsheet-final/build.py
```

产物：
- `output/pdf/discrete-final-cheatsheet.pdf`
- `output/pdf/discrete-final-cheatsheet-editable.zip`

脚本要求恰好 8 页且每页为纵向 A4；失败保留原 PDF。构建不会上传网站。

## 如何修改

正文在 `sections/01-probability.typ` 至 `08-method.typ`，一文件一页。每个主题在本页内自动排版。`main.typ` 控制字号、行间距、栏距、页边距；默认正文 11pt、行间附加距离 3.5pt、列表间距 5pt。不要在不同条目之间随意插入硬换行来修正高公式；先检查公式真实高度和列表间距。超页时构建报错，建议先删非考点或精简重复推导。

打印选 A4、实际大小、双面长边翻转；先试印一张确认打印机方向。

## 资料与约定

参考本地 `sources/course/lecture_notes.txt`（2025 完整笔记）、期中后资料、`blog/content/10` 至 `17` 的整理，以及 `EX__24final.txt`、`EX__25final.txt`。期中表仅参考其字体、列表和公式处理，不复制其内容。原始教材／笔记不随源码包分发。

信息论 log 默认底 2，Chernoff 自然指数中的散度明确用自然对数。循环 DFT 与布尔 Fourier 的归一化分别注明。噪声翻转概率 eta 与相关系数 rho=1-2eta 分开。
