# 离散数学与结构 (I) · 期末 Cheatsheet

纵向 A4，单栏，正文自动分页。唯一参考讲义为项目内的 `sources/lecture_notes_25.pdf`，使用其中第 10–17 章（讲义印刷页 81–133）。范围按已确认的期末约束，期中章节及 Galois 均排除。目录按讲义顺序排列：

| 讲义章节 | 主干 |
|---|---|
| 10 | 概率、期望方差、条件期望、概率生成函数 |
| 11 | 熵、KL、互信息、链式法则、数据处理 |
| 12 | Markov、Chebyshev、Chernoff、类型与 Sanov |
| 13 | 特征标、Fourier 变换与卷积、布尔随机限制 |
| 14 | 压缩、Kraft、典型集、信道容量与纠错码 |
| 15 | 稳态、到达与返回、周期、MCMC、耦合与混合时间 |
| 16 | 图、树、平面图、矩阵树定理与谱 |
| 17 | 第一／第二矩、随机排列、修补、连通阈值与局部引理 |

定义、定理条件与证明相邻。保留讲义的主干结论，略去课堂例题与历年题。熵以 bit 为单位，集中不等式中的自然散度记作 `D_e`。Fourier 系数带 `1/N`，群卷积按求和定义，与讲义一致。源码包仅含速查表的源文件与构建脚本。

## 构建与修改

在项目根目录或解压目录运行：

```bash
bash cheatsheet-final/build.sh
```

正文位于 `cheatsheet-final/sections/`，每个 Typst 文件对应一章。版式集中在 `cheatsheet-final/main.typ`。脚本优先复用已安装的 Python 环境，缺依赖时创建本地 venv 并安装固定依赖。构建检查页面为纵向 A4，页数随正文自动调整，失败保留原 PDF。

- PDF：`output/pdf/discrete-final-cheatsheet.pdf`
- 可编辑源码包：`output/pdf/discrete-final-cheatsheet-editable.zip`

打印选择 A4、实际大小、双面长边翻转。
