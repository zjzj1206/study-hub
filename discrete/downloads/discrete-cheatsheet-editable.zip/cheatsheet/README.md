# 离散数学与结构 (I)：期中四面速查表（两张 A4）

范围：网站第 01–09 章，到计数（含）。四页横向 A4（两张纸双面），每页三栏，正文和公式均为 7.5pt。内容是考试速查用的定义、定理条件、公式、短证明套路与反例，不是完整讲义。纸面没有折叠；网站原有折叠格式不受影响。

## 一条命令构建

在项目根目录运行：

```bash
bash cheatsheet/build.sh
```

第一次自动在 `cheatsheet/.venv` 创建独立 Python 环境，安装固定版本的 Typst 和 pypdf，需要联网；之后可离线构建。依赖 Python 3.10+、venv，以及中文字体。本机已安装 Noto Sans CJK SC。若系统缺 venv，在 Debian/Ubuntu 安装 `python3-venv` 后重试。

输出：`output/pdf/discrete-midterm-cheatsheet.pdf`。

构建会检查每栏高度、总页数为 4、纸张为 A4；失败时保留旧 PDF，请留意终端提示。脚本不会自动缩小字号，不会裁去超出的内容。PDF 是生成物，修改它不会反馈到源码。

其他系统也可创建自己的环境：

```bash
python -m venv .venv
# Linux/macOS
.venv/bin/python -m pip install -r cheatsheet/requirements.txt
.venv/bin/python cheatsheet/build.py
# Windows（使用上面创建的环境）
.venv\Scripts\python -m pip install -r cheatsheet\requirements.txt
.venv\Scripts\python cheatsheet\build.py
```

若已有 Typst 0.15 编译器，也可在 `cheatsheet/` 内执行 `typst compile main.typ`；会保留栏高断言，但不经过 Python 的 PDF 页数检查。这里使用 Typst 原生数学语法，不是 LaTeX。

## 改哪里

| 页 / 栏 | 内容文件 |
|---|---|
| 第 1 面 / 左栏 | `sections/01-sets.typ`：集合、关系、基数与序数 |
| 第 1 面 / 中栏 | `sections/02-logic.typ`：命题与一阶逻辑、自然演绎 |
| 第 1 面 / 右栏 | `sections/03-foundations.typ`：PA、ZFC、模型与元定理 |
| 第 2 面 / 左栏 | `sections/04-number.typ`：数论、CRT、模幂与 RSA |
| 第 2 面 / 中栏 | `sections/05-groups.typ`：群、商群、同构与结构 |
| 第 2 面 / 右栏 | `sections/06-actions.typ`：群作用、类方程与 Sylow |
| 第 3 面 / 左栏 | `sections/07-rings.typ`：环、理想与不可约判定 |
| 第 3 面 / 中栏 | `sections/08-fields.typ`：域扩张、有限域与 Galois |
| 第 3 面 / 右栏 | `sections/09-algebra-practice.typ`：代数证明与旧期中题型 |
| 第 4 面 / 左栏 | `sections/10-counting.typ`：计数模型、容斥与特殊数列 |
| 第 4 面 / 中栏 | `sections/11-generating.typ`：生成函数、反演与递推 |
| 第 4 面 / 右栏 | `sections/12-burnside.typ`：Burnside、Pólya 与着色例题 |

每个 `- ` 开始一个条目，条目之间保留空行。行尾 `\` 强制换行；下一行缩进两个空格继续同一条目。删除条目时整段删除；换栏时将整段剪切到另一文件，不用手改页码。十二栏固定，内容不会自动从一栏流到下一栏。

排版在 `main.typ`：

- `body-size = 7.5pt`：正文字号。
- `show math.equation: set text(size: body-size)`：公式随正文同步调整。
- `leading: 3.2pt`：额外行距；`spacing: 3pt`：段间距。
- 高公式：自动检测高度超过字号的 1.6 倍且宽度小于 84mm 的公式，用真实字形边界排版，并在上下各加 `1pt` 留白；相关规则位于 `main.typ` 的 `show math.equation.where(block: false)`。过宽公式保留自动换行。
- `column-gap = 6mm`：栏间距。
- `margin: (x: 8mm, top: 7mm, bottom: 8mm)`：页边距；改大后需要同步降低栏高上限 `190mm`。
- 正文用 Noto Serif CJK SC，标题和加粗标签用 Noto Sans CJK SC。其他设备可在 main.typ 中统一换成已安装的中文字体；更换字体会影响换行，应重新检查 PDF。

建议先删掉你已经熟悉的条目，再填自己最容易忘的证明步骤。不要为了硬塞内容过度缩小文字。

## 常用编辑语法

```typst
= 一级灰底标题

- *加粗标签*：普通中文内容。这是一个独立条目。

- *公式*：$a^n$、$x_i$、$a/b$、$binom(n,k)$。

$sum_(i=0)^n i = n(n+1)/2$

// 注释不会出现在 PDF 中。
```

箭头后接括号时保留空格，例如 `P arrow.r (Q arrow.r P)`。

`$...$` 是行内公式；`$ ... $`（两侧有空格）是独立公式，比较占空间。`a/b` 自动排成分数；商群和商环用 `G "/" N`、`F[x] "/" (f)`，保留斜线及理想括号。蕴含可用 `arrow.r`，同构可直接写 `≅`；不要直接粘贴 LaTeX 的 `\frac`、`\begin`。

内容报错会显示文件和行号。若提示某栏超长，先删减或搬移该栏内容；如果字体变化导致超长，也可小幅调字号/行距。

## 打印与检查

打印选全部4页、A4、实际大小/100%、横向、双面短边翻转（共两张纸）；关闭“每张多页”。本 PDF 已经一面三栏，不必再次启用三栏打印。建议先试印一页检查阅读舒适度。

可选本地预览图检查（需要 Poppler）：

```bash
pdftoppm -scale-to 1800 -png output/pdf/discrete-midterm-cheatsheet.pdf /tmp/discrete-preview
```

## 编写依据与取舍

以本项目 `blog/content/01-sets.md` 到 `09-counting.md` 的章节范围为骨架，参考 `sources/course/lecture_notes.txt` 的课程体系，以及 `EX__23midterm.txt`、`EX__24midterm.txt`、`EX__25midterm.txt` 中的题型。2025 栏目所链接卷头写的是 2024，本表不据此认定其真实考试年份。原试卷/教材不包含在可分享源码包中。

重点保留自然演绎的变量条件、紧致性、Sylow 约束、商环为域的判定、有限域不可约计数、容斥和对称计数。较长的完整证明、公理的全部形式化展开以及进阶例题未全文收入。使用本表的 `D_n` 表示 2n 阶二面体群，做题时应核对试卷的记号约定。

## 公式编辑防错（2026-10-21 核查后）

构建现在会扫描全部公式，拦截已知的下标、竖线、箭头解析歧义；这不是数学正确性的自动证明。

- 基数和绝对值：写 `abs(G)`；整除：写 `p ∣ n`。
- 带基数的分式：写 `frac(1, abs(G))`，不要写 `1/|G|`。
- 带参数的下标对象：写 `C_(G) (x)`、`N_(q) (d)`、`"Aut"_(F) (E)`。
- 多项式环：写 `FF_(q) [x]`；有理函数域：写 `FF_(q) (x)`。
- 含阶乘的分母：写 `frac(m!, (m-n)!)`，明确其作用范围。

本次核对修正了 Burnside/Pólya 的归一化分母、子群乘积的阶、下标对象的参数范围、Euler 二次剩余判据的同余符号；补充了部分求和范围和有限扩张条件。四面版中，两种反演归回第4面中栏。

## 四面版扩充（2026-10-29）

范围仍为集合到计数，没有加入概率及后续章节。保留 7.5pt 字号、分点结构、高公式留白与语法风险检查；构建严格要求4页。新增关系闭包、CSB 构造、量词规则、Henkin/PA/ZFC 细节、RSA、自由群/可解群、Sylow 证明、环的链条件、有限域计算、球盒模型和生成函数推导，并补充对称着色及旧期中题型。

公式片段数量由两面版的521增至1110（其中包含单个符号与短记号，不等同于定理数量）。四面仍是速查与短证明提纲，完整长证明和全部原题请参阅课程讲义。

旧版 PDF 另存为 `output/pdf/discrete-midterm-cheatsheet-2pages.pdf`，旧版源码包为 `output/pdf/discrete-cheatsheet-editable-2pages.zip`。默认 PDF 和源码包文件名继续指向最新四面版。
