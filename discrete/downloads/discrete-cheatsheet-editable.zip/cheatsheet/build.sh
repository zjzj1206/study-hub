#!/usr/bin/env bash
set -euo pipefail
sheet_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -x "$sheet_dir/.venv/bin/python" ]]; then
  python3 -m venv "$sheet_dir/.venv"
fi
if ! "$sheet_dir/.venv/bin/python" -c 'import typst, pypdf' >/dev/null 2>&1; then
  "$sheet_dir/.venv/bin/python" -m pip install -r "$sheet_dir/requirements.txt"
fi
exec "$sheet_dir/.venv/bin/python" "$sheet_dir/build.py"
