// 内容：sections/ 下的十二个分栏文件；此处只控制版面。
#let body-size = 7.5pt
#let column-gap = 6mm
#let ink = rgb("243447")
#let accent = rgb("275D73")
#set document(title: "离散数学与结构 (I) · 期中速查", author: "课程复习资料")
#set page(paper: "a4", flipped: true, margin: (x: 8mm, top: 7mm, bottom: 8mm), footer: context align(right, text(size: 6pt, fill: ink)[离散数学与结构 (I) · 集合至计数　/　#counter(page).display() / 4]))
#set text(font: "Noto Serif CJK SC", size: body-size, fill: rgb("202830"), lang: "zh")
#set par(justify: false, leading: 3.2pt, spacing: 3pt)
#set math.equation(numbering: none)
#show math.equation: set text(size: body-size)
// 高公式保留真实高度，并加上下缓冲；过宽公式仍允许原生换行。
#show math.equation.where(block: false): it => context {
  let full = {
    set text(top-edge: "bounds", bottom-edge: "bounds")
    it
  }
  let sz = measure(full)
  if sz.height > 1.6 * body-size and sz.width < 84mm {
    box(inset: (y: 1pt), full)
  } else { it }
}
#set heading(numbering: none)
#show heading.where(level: 1): it => block(above: 5pt, below: 4pt, width: 100%, stack(spacing: 2pt,
  text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: accent, it.body),
  line(length: 100%, stroke: .55pt + accent)))
#set list(indent: 0pt, body-indent: 7pt, spacing: 2.8pt, marker: text(fill: accent, size: 8pt)[•])
#show strong: set text(font: "Noto Sans CJK SC", weight: "bold", fill: ink)
#let sheet(cols, subtitle, page-no) = {
  grid(columns: (1fr, auto), align: bottom,
    text(font: "Noto Sans CJK SC", size: 13pt, weight: "bold", fill: ink)[离散数学与结构 (I)],
    text(font: "Noto Sans CJK SC", size: 7.5pt, fill: accent)[期中速查　·　#subtitle])
  v(2pt)
  layout(size => {
    let w = (size.width - 2 * column-gap) / 3
    for (i, c) in cols.enumerate() {
      let used = measure(block(width: w, c)).height
      metadata((page: page-no, column: i + 1, height: used / 1mm))
      assert(used <= 190mm, message: "第 " + str(page-no) + " 页第 " + str(i + 1) + " 栏超长：" + repr(used) + "；请删减、移栏或调整字号。")
    }
    grid(columns: (1fr, 1fr, 1fr), gutter: column-gap, ..cols.map(c => block(width: 100%, c)))
  })
}
#sheet((include "sections/01-sets.typ", include "sections/02-logic.typ", include "sections/03-foundations.typ"), [1 / 集合、逻辑与公理], 1)
#pagebreak()
#sheet((include "sections/04-number.typ", include "sections/05-groups.typ", include "sections/06-actions.typ"), [2 / 数论、群与作用], 2)
#pagebreak()
#sheet((include "sections/07-rings.typ", include "sections/08-fields.typ", include "sections/09-algebra-practice.typ"), [3 / 环、域与代数题型], 3)
#pagebreak()
#sheet((include "sections/10-counting.typ", include "sections/11-generating.typ", include "sections/12-burnside.typ"), [4 / 计数、生成函数与对称], 4)
