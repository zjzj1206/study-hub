// 内容：sections/ 下的十二个主题文件；每面按三栏自动续排；此处只控制版面。
#let body-size = 7.5pt
#let column-gap = 6mm
#let ink = rgb("243447")
#let accent = rgb("275D73")
#set document(title: "离散数学与结构 (I) · 期中速查", author: "课程复习资料")
#set page(paper: "a4", flipped: true, margin: (x: 8mm, top: 7mm, bottom: 8mm), footer: context align(right, text(size: 6pt, fill: ink)[离散数学与结构 (I) · 集合至计数　/　#counter(page).display() / 4]))
#set text(font: "Noto Serif CJK SC", size: body-size, fill: rgb("202830"), lang: "zh")
#set par(justify: false, leading: 3.2pt, spacing: 3pt)
#set math.equation(numbering: none)
#show math.equation: set text(size: body-size)
// 高公式保留真实高度，并加上下缓冲；过宽公式仍允许原生换行。
#show math.equation.where(block: false): it => context {
  let full = {
    set text(top-edge: "bounds", bottom-edge: "bounds")
    it
  }
  let sz = measure(full)
  if sz.height > 1.6 * body-size and sz.width < 84mm {
    box(inset: (y: 1pt), full)
  } else { it }
}
#set heading(numbering: none)
#show heading.where(level: 1): it => block(above: 5pt, below: 4pt, width: 100%, sticky: true, stack(spacing: 2pt,
  text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: accent, it.body),
  line(length: 100%, stroke: .55pt + accent)))
// 圆点直径 2.2pt，与正文间隔 3pt。
#set list(indent: 0pt, body-indent: 3pt, spacing: 2.8pt, marker: box(baseline: -2pt, circle(radius: 1.1pt, fill: accent, stroke: none)))
#show strong: set text(font: "Noto Sans CJK SC", weight: "bold", fill: ink)
// 全文自动续栏、续面；避免一个主题的页尾溢出另起空页。
#set page(margin: (x: 8mm, top: 14mm, bottom: 8mm), header: context grid(columns: (1fr, auto),
  text(font: "Noto Sans CJK SC", size: 11pt, weight: "bold", fill: ink)[离散数学与结构 (I)],
  text(size: 7pt, fill: accent)[期中速查 · 集合至计数]))
#columns(3, gutter: column-gap)[
  #include "sections/01-sets.typ"
  #parbreak()
  #include "sections/02-logic.typ"
  #parbreak()
  #include "sections/03-foundations.typ"
  #parbreak()
  #include "sections/04-number.typ"
  #parbreak()
  #include "sections/05-groups.typ"
  #parbreak()
  #include "sections/06-actions.typ"
  #parbreak()
  #include "sections/07-rings.typ"
  #parbreak()
  #include "sections/08-fields.typ"
  #parbreak()
  #include "sections/09-algebra-practice.typ"
  #parbreak()
  #include "sections/10-counting.typ"
  #parbreak()
  #include "sections/11-generating.typ"
  #parbreak()
  #include "sections/12-burnside.typ"
  #parbreak()
]
