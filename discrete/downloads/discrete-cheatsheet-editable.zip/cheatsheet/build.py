#!/usr/bin/env python3
"""Compile editable Typst source and require exactly four A4 pages."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent
try:
    import typst
    from pypdf import PdfReader
except ImportError:
    sys.exit('缺少依赖。请先运行：python -m pip install -r cheatsheet/requirements.txt')
out = ROOT.parent / 'output' / 'pdf'
out.mkdir(parents=True, exist_ok=True)
target = out / 'discrete-midterm-cheatsheet.pdf'
try:
    from check_math import check_sources
    formula_count = check_sources(ROOT)
    data = typst.compile(str(ROOT / 'main.typ'), root=str(ROOT))
    import io
    pdf = PdfReader(io.BytesIO(data))
    if len(pdf.pages) != 4:
        raise ValueError(f'必须恰好 4 页，实际 {len(pdf.pages)} 页。请删减内容或调整 main.typ。')
    for page in pdf.pages:
        w, h = float(page.mediabox.width), float(page.mediabox.height)
        if abs(w - 841.89) > 1 or abs(h - 595.276) > 1:
            raise ValueError(f'页面不是横向 A4：{w} × {h} pt')
    target.write_bytes(data)
    print(f'构建成功：{formula_count} 个公式片段通过语法风险检查；4 页 A4\n{target}')
except Exception as e:
    sys.exit('构建失败（保留原 PDF）：\n' + getattr(e, 'diagnostic', str(e)))
