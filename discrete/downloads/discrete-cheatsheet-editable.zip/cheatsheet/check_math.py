"""Reject known ambiguous Typst shorthand in the editable formula sources.

This checks source syntax risks, not mathematical truth.
"""
from pathlib import Path
import re


def check_math(source: str, name: str = '<text>') -> int:
    formulas = list(re.finditer(r'\$([^$]+)\$', source))
    for match in formulas:
        expr = match.group(1)
        line = source.count('\n', 0, match.start()) + 1
        error = None
        if '|' in expr:
            error = '基数/绝对值用 abs(...)；整除用 ∣，避免原始竖线与分式冲突'
        elif re.search(r'_[A-Za-z0-9]+[([]', expr):
            error = '带下标对象后接参数时显式闭合下标，如 C_(G) (x)、FF_(q) [x]'
        elif re.search(r'arrow\.[A-Za-z.]+\(', expr):
            error = '箭头后接括号须加空格，避免误解析为重音函数'
        if error:
            raise ValueError(f'{name}:{line}: {error}\n  ${expr}$')
    return len(formulas)


def check_sources(root: Path) -> int:
    return sum(check_math(p.read_text(), str(p.relative_to(root)))
               for p in sorted((root / 'sections').glob('*.typ')))


if __name__ == '__main__':
    print(f'已扫描 {check_sources(Path(__file__).resolve().parent)} 个公式片段。')
