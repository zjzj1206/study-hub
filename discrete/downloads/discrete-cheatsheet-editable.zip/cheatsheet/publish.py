#!/usr/bin/env python3
"""Build the sheet and publish its downloads using the existing full-site deployer."""
from pathlib import Path
import argparse
import importlib.util
import shutil
import subprocess
import sys
import tempfile
import zipfile

SHEET = Path(__file__).resolve().parent
ROOT = SHEET.parent
DEPLOYER = Path('/home/administrator/ICS/tools/sync_site.py')
BASE = Path('/home/administrator/高党资料/gaodang-site/private/cloudflare-site/discrete')
NAMES = ('discrete-midterm-cheatsheet.pdf', 'discrete-cheatsheet-editable.zip')


def main():
    parser = argparse.ArgumentParser(description='构建四面 PDF，更新 PDF/源码包并发布到现有网站。')
    parser.add_argument('--check', action='store_true', help='完整构建与部署前检查，不上传网站')
    args = parser.parse_args()
    subprocess.run(['bash', str(SHEET / 'build.sh')], check=True)
    pdf = ROOT / 'output/pdf' / NAMES[0]
    bundle = ROOT / 'output/pdf' / NAMES[1]
    if not BASE.is_dir() or not DEPLOYER.is_file():
        raise RuntimeError('找不到本机现有完整部署包或统一部署脚本；请在当前学习资料电脑运行。')
    # Allowlist the editable source files; never package virtual environments or reference books.
    with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as z:
        for name in ('main.typ', 'build.py', 'build.sh', 'check_math.py', 'requirements.txt', 'README.md', 'publish.py', 'publish.sh'):
            p = SHEET / name
            if p.is_file():
                z.write(p, 'cheatsheet/' + name)
        for p in sorted((SHEET / 'sections').glob('*.typ')):
            z.write(p, 'cheatsheet/sections/' + p.name)
        z.write(pdf, 'output/pdf/' + pdf.name)
    with tempfile.TemporaryDirectory(prefix='sheet-publish-', dir=ROOT / 'research') as tmp:
        stage = Path(tmp)
        (stage / 'blog').mkdir()
        (stage / 'research').mkdir()
        incoming = stage / 'downloads'
        incoming.mkdir()
        for name in NAMES:
            shutil.copy2(ROOT / 'output/pdf' / name, incoming / name)
        # Called by the deployer after it acquires the shared deployment lock.
        # Start with the currently deployed course, then replace only the two downloads.
        script = 'from pathlib import Path\nimport shutil\n'
        script += f'base=Path({str(BASE)!r})\nout=Path({str(stage / "blog/dist")!r})\n'
        script += 'shutil.copytree(base,out)\n(out/"downloads").mkdir(exist_ok=True)\n'
        for name in NAMES:
            script += f'shutil.copy2({str(incoming / name)!r},out/"downloads"/{name!r})\n'
        (stage / 'blog/build.py').write_text(script)
        shutil.copy2(ROOT / 'research/verify.py', stage / 'research/verify.py')
        spec = importlib.util.spec_from_file_location('sheet_site_deployer', DEPLOYER)
        deployer = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(deployer)
        deployer.DM = stage
        sys.argv = [str(DEPLOYER), '--project', 'discrete'] + (['--check'] if args.check else [])
        deployer.main()
    # Keep source-repository assets ready for any subsequent git sync.
    if not args.check:
        local = ROOT / 'blog/assets/downloads'
        local.mkdir(parents=True, exist_ok=True)
        for name in NAMES:
            shutil.copy2(ROOT / 'output/pdf' / name, local / name)
    print('检查完成，未上传。' if args.check else 'PDF 与源码包已更新：https://blog.zjzj.work/discrete/25-cheatsheet')
    print('逐条解读保持其原版本；此命令不重新生成解读，也不执行 Git 提交。')


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        sys.exit(f'停止：{error}')
