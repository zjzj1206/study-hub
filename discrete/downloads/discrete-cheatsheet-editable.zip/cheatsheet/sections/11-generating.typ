= 生成函数

- *常用级数*：$sum_(n>=0)n x^n=x/(1-x)^2$。 \
  *常用展开*：$frac(1,1-c x)=sum_(n>=0)c^n x^n$；$frac(1,(1-c x)^k)=sum_(n>=0)binom(n+k-1,k-1)c^n x^n$。

- *递推转生成函数*：递推→乘 $x^n$ 求和→补初值→解有理函数→部分分式取系数。 \
  *一般二阶递推*：$a_n=u a_(n-1)+v a_(n-2)$（$n>=2$），则
  $ A(x)=frac(a_0+(a_1-u a_0)x,1-u x-v x^2) $

- *整数分拆恒等式*：互异部件与奇数部件的分拆数相等
  $ product_(j>=1)(1+x^j)=product_(j>=1)frac(1-x^(2j),1-x^j)=product_(j>=1)frac(1,1-x^(2j-1)) $
  *分拆递推*：恰分成 $k$ 个正整数部分的数记 $p_(k) (n)$。按是否有 $1$ 分类得 $p_(k) (n)=p_(k-1) (n-1)+p_(k) (n-k)$。\
  $
  n "分拆成至多" k "个部分的方案数" = n "分拆每部分至多" k "的方案数"
  $

- *EGF*：$A(x)=sum_(n>=0) a_n frac(x^n, n!)$；乘积对应带二项式系数的卷积（先选标签）。集合分块：$sum_(n>=0) S(n,k)frac(x^n, n!) =frac((e^x-1)^k, k!)$；Bell 为 $exp(e^x-1)$；错排为 $e^(-x)/(1-x)$。 \
  *乘积规则*：若 $A=sum_(n>=0)a_n frac(x^n,n!)$、$B=sum_(n>=0)b_n frac(x^n,n!)$，则乘积的 $frac(x^n,n!)$ 系数是 $sum_(k=0)^n binom(n,k)a_k b_(n-k)$；二项式系数来自挑选第一部分的标签。 \
  *集合构造*：非空标号块 EGF 为 $e^x-1$；恰 $k$ 个无序块除以 $k!$；任意多个块求和得 $exp(e^x-1)$。块内带其他结构时，用对应块 EGF 替换。

- *二项式反演*：$ b_n=sum_(k=0)^n binom(n,k)a_k$ ⇔ $a_n=sum_(k=0)^n (-1)^(n-k)binom(n,k)b_k $

- *Möbius 反演*：$ g(n)=sum_(d ∣ n)f(d)$ ⇔ $f(n)=sum_(d ∣ n)mu(d)g(n/d) $
