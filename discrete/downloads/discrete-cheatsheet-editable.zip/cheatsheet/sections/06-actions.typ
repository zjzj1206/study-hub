= 06 群作用与共轭

- *群作用*：$e star x=x$，$(g h)star x=g star$$(h star x)$，等价于同态 $G arrow.r S_X$。轨道 $G x = "Orbit"(x)  ={g x}$，稳定子 $G_x="Stab"_(G)(x)={g:g x=x}$。映射 $g G_x mapsto g x$ 为双射，故 $abs(G x)=[G:G_x]$。

- *共轭作用*：$g star x=g x g^(-1)$。共轭类大小 $[G:C_(G) (x)]$。

- *类方程*：$abs(G)=abs(C(G))+sum_(i=1)^(t) [G:C_(G) (x_i)]$，$x_(1),dots,x_(t)$ 为非中心共轭类代表。

- *正规化子*：$N_(G) (H)={g:g H g^(-1)=H}$；$H ⊴ N_(G) (H)$。$H$ 的共轭子群数 $[G:N_(G) (H)]$。

- *$p$ 群*：阶为素数 $p$ 的幂的群。

- *$p$ 群*作用于有限集 $X$：轨道大小为 $p$ 幂，故 $abs(X) ≡ abs(X^G) (mod p)$。非平凡有限 $p$ 群有非平凡中心；$p^2$ 阶群必交换：中心若为 $p$ 阶，则 $G"/"C(G)$ 循环，从而 $G$ 交换。

= Sylow 定理

- *$"Syl"_(p)(G)$* 表示 $G$ 中所有 Sylow $p$ 子群的集合。

- *Sylow*：$abs(G)=p^a m$，$p ∤ m$，$n_p = abs("Syl"_(p)(G))$。 \
  ① 存在 $p^a$ 阶子群（Sylow $p$ 子群）。 \
  ② 每个 $p$ 子群包含于某个 Sylow 子群；所有 Sylow $p$ 子群互相共轭。 \
  ③ 个数 $n_p ∣ m$，且 $n_p ≡ 1 (mod p)$，$n_p = [G:N_(G)(P)]$。 \
  - *存在性*：$abs(G)=p^a m$，让 $G$ 左乘作用于所有 $p^a$ 元子集。子集数 $binom(p^a m,p^a) ≡ m (mod p)$，故有轨道 $"Orbit(A)"$ 大小不被 $p$ 整除。设 $H="Stab"_(G)(A)$，令 $H$ 作用在 $A$ 上，考虑每个轨道，大小为 |H|，所以 $abs(H)∣p^a$；轨道指数不含 $p$ 又迫使 $p^a∣abs(H)$，故相等。 \
  - *Sylow 包含性证明*：令 $p$ 子群 $H$ 作用于 $G"/"P$，其中 $P$ 为 Sylow。因 $p∤[G:P]$，存在轨道 $"Orbit"(g P)$ 大小不被 $p$ 整除，故 $"Stab"_(H)(g P)=H$；于是 $forall h, g^(-1)h g in P$ 即 $g^(-1)H g <= P$。取 $H$ 也为 Sylow 即得共轭性。 \
  - *$n_p≡1 (mod p)$ 证明*：固定 Sylow $P$，让它共轭作用于 $"Syl"_(p)(G)$，$g star Q mapsto g^(-1) Q g$。唯一固定点是 $P$：若 $forall g in P, g^(-1) Q g = Q$，则 $P Q$ 为 $p$ 子群，故 $abs(P Q) = p^a arrow.r abs(P inter Q) =abs(P) arrow.r P = Q$。其余轨道大小被 $p$ 整除。

- *命题*：$P$ 是 $G$ 的 Sylow $p$ 子群，则 $P$ 是 $N_(G)(P)$ 的唯一 Sylow $p$ 子群，证明：显然 $P ⊴ N_(G)(p)$，$P$ 是 $N_(G)(P)$ 的 Sylow $p$ 子群，最大性可由 Sylow $p$ 子群的共轭性保证。

- *推论*：Sylow $p$ 子群唯一 ⇔ 该 Sylow 子群正规于 $G$，都等价于 $forall g in G, g^(-1)P g=P$。

- *$p q$ 阶群分类*（素数 $p>q$）：
  $n_p ∣ q$ 且 $n_p ≡ 1 (mod p)$，故 $n_p=1$。
  取 $P=〈a〉 ⊴ G$、$Q=〈b〉$，
  $abs(P)=p$、$abs(Q)=q$。
  因 $P inter Q={e}$、$abs(P Q)=p q$，
  故 $G=P ⋊ Q$，元素唯一写成 $a^i b^j$。

- *共轭关系*：设 $b a b^(-1)=a^r$，
  由 $a=b^q a b^(-q)=a^(r^q)$，
  得 $r^q ≡ 1 (mod p)$。
  $r=1$ 时 $G ≅ C_(p q)$；
  $r≠1$ 时 $"ord"(r)=q$，故 $q ∣ (p-1)$。

- *存在与唯一*：若 $q ∣ (p-1)$，
  取 $FF_p^×=〈g〉$、$r=g^((p-1)/q)$，
  构造 $G_r=C_p ⋊ C_q$，
  满足 $a^p=b^q=e$、$b a b^(-1)=a^r$。
  任意两个非平凡参数满足 $r'=r^u$，
  $1≤u<q$；更换生成元 $b ↦ b^u$ 即得同构。
  故 $q ∤ (p-1)$ 时只有循环群；
  $q ∣ (p-1)$ 时恰有循环群与唯一的非交换半直积两类。
