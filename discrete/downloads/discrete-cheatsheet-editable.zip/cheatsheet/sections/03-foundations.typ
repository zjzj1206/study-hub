#set list(spacing: 3.2pt)

= 03 谓词逻辑：语言、代入与规则

- *语言 $cal(L)$*：指定常量、函数符号、谓词符号及其元数。变量、常量是项 (TERM)；$t_1,dots,t_n$ 为项、$f$ 为 $n$ 元函数符号，则 $f(t_1,dots,t_n)$ 为项。原子公式为谓词 $P(t_1,dots,t_n)$ 或 $t=u$；由连接词和量词递归生成公式 (FOR)。

- *自由变量*：$"FV"(forall x phi)="FV"(phi) backslash {x}$；
  *变量*：$"Var"(phi)$ 表示 $phi$ 中所有出现的变量集合。

- *可自由代入 $phi[t"/"x]$*：只替换 $x$ 的自由出现。
  1. 原子公式：满足条件，任意替换；\
  2. $not, and, or, arrow.r$ 递归满足条件；\
  3. $forall x phi$：满足条件但不做替换；\
  *4. $forall y phi$：$x in.not "FV"(phi)$ 或 $y in.not "FV"(t)$ 且 $phi$ 满足条件。*

- *量词规则*：$forall E$：$forall x phi tack.r phi[t"/"x]$，须可自由代入。$forall I$：$phi tack.r forall x phi$，$x$ 不得自由出现于任何未撤销假设。*等号规则*：$t=t$；由 $t=u$ 可在项或公式中替换。

- *闭项 (Closed TERM)*：不含变量的公式，记为 $"TERM"_(c)(cal(L))$；\
  *闭公式 / 句子 (Sentence)*：$"FV"(phi)=emptyset$ 的公式 $phi$，记为 $"Sent"(cal(L))$。

= 模型与一阶完备性

- *模型 $cal(M)$*：语言 $cal(L)$ 的模型 $cal(M)$ 包括：非空论域 $Omega$、常元 $c^(cal(M)) in Omega$、$k$ 元函数 $f^(cal(M)):Omega^k arrow.r Omega$ 及谓词关系 $P^(cal(M)) subset.eq Omega^k$。$f$ 是符号，$f^(cal(M))$ 才是函数，运算规律须由公理约束。

- *闭项的解释*：$ ⟦macron(a)⟧=a in Omega $ $ ⟦c⟧=c^(cal(M)) $ $ ⟦f(t_1,dots,t_k)⟧=f^(cal(M)) (⟦t_1⟧,dots,⟦t_k⟧) $

- *公式的解释*：设 $"FV"(phi)={x_(1),dots,x_(n)}$，则定义 $ cal(M) ⊨ phi ⇔ cal(M) ⊨ forall x_(1) dots forall x_(n) phi ⇔ lr(⟦ phi ⟧)_(cal(M)) = 1 $ 
  $ lr(⟦ ⊥ ⟧)_(cal(M)) = 0 $ $ lr(⟦ P(t_1, dots.c, t_k) ⟧)_(cal(M)) = 1 ⇔ (lr(⟦ t_1 ⟧)_(cal(M)), dots.c,lr(⟦ t_k ⟧)_(cal(M))) in P^(cal(M)) $ 
  $ lr(⟦ forall x phi ⟧)_(cal(M))= min_(a in Omega) lr(⟦ phi[macron(a)"/"x] ⟧)_(cal(M)) $ $ lr(⟦ exists x phi ⟧)_(cal(M)) = max_(a in Omega) lr(⟦ phi[macron(a)"/"x] ⟧)_(cal(M)) $

- *模型与大小*：$cal(M) ⊨ Gamma$ 表示 $forall gamma in Gamma "s.t." cal(M) ⊨ Gamma$。模型的大小：$abs(cal(M))=abs(Omega)$。

- *$Gamma ⊨ phi$ 的含义*：对于所有模型 $cal(M)$，若 $cal(M) ⊨ Gamma$ 则 $cal(M) ⊨ phi$。

- *一阶逻辑的可靠性*：对推导树归纳，$and,or,arrow.r$ 和原子公式同之前一样。\
  *$forall I$*：设由前提集 $Delta$ 推出 $psi$，固定其他自由变量的替换，由于 $Delta$ 不受 $x$ 的替换影响，故 $psi[macron(a)"/"x]$ 始终成立。
  *$forall E$*：先替换 $phi[t"/"x]$ 中 $t$ 的自由变量得到一个闭项，解释为某个 $a in Omega$。

- *理论*：句子集 $T$ 对推导封闭，即 $T tack.r sigma arrow.r.double sigma in T$，称 $T$ 为理论。$"Cn"(A)={sigma:A tack.r sigma}$ 是公理集 $A$ 的理论。

- *一阶逻辑的完备性*：若 $Gamma tack.r.not bot$，则存在模型 $cal(M)$ 使得 $cal(M) ⊨ Gamma$。

- *Henkin 理论的定义*：对于理论 $T$，若 $exists x phi(x) in T arrow.r.double$ 存在常量 $c$ 使得 $phi(c) in T$，称 $T$ 为 Henkin 理论。

- *Henkin 扩张*：对于语言 $cal(L)$ 的理论 $T$，对于每个公式 $exists x phi in cal(L)$，添加新常量 $c$ 和公式 $H=exists x phi arrow.r phi[c"/"x]$，得到语言 $cal(L^*)$ 的理论 $T^*$。\
  - *保守性*：若 $T,H tack.r sigma$，则 $T,not sigma tack.r not H$ 即 $T,not sigma tack.r exists x phi$ 且 $T,not sigma tack.r not phi[c"/"x]$，将后者的新常元替换为未在推导中出现的变量 $y$ 得到 $not phi[y"/"x]$ 再使用 $forall I$ 得到 $forall x not phi$，矛盾，即 $T,not sigma tack.r bot$，RAA 得 $T tack.r sigma$。\
  - *新常量的替换：*$Delta tack.r phi[c"/"x] arrow.r.double Delta tack.r forall x phi$。\
    *证明*：引入新变量 $y$，由于 $Delta$ 和 $c$ 无关，故有 $Delta tack.r phi[y"/"x]$，再用 $forall I$ 得到 $Delta tack.r forall y phi[y"/"x]$，再改变量名得到 $Delta tack.r forall x phi$。

- *完备性·闭项模型构造*：令 $T_(n+1)=T_(n)^*$，$T_(infinity)=union.big T_(n)$，再逐个枚举句子，若加入当前理论仍一致，得到语言 $cal(L)'$ 下的理论 $T'$。由此定义模型 $cal(M)$：定义 $Omega = C"/"∼$，$c^(cal(M))=[c]$，$f^(cal(M))([t_(1)],dots,[t_(k)])=[f(t_(1),dots,t_(k))]$，$P^(cal(M))([t_(1)],dots,[t_(k)]) ⇔ P(t_(1),dots,t_(k)) in T'$。其中 $C$ 为 $cal(L)'$ 中所有的闭项，$t∼u ⇔ T' tack.r t=u$，$[c]$ 表示 $c$ 的等价类。

- *闭项模型真值引理*：闭项 $t$ 满足 $⟦t⟧_(cal(M))=[t]$，且任意句子 $sigma$ 有 $M ⊨ sigma ⇔ sigma in T'$。对公式结构归纳，闭项代入后 $cal(M) ⊨ phi(t_1,dots,t_k) ⇔ phi(t_1,dots,t_k) in T^*$。原子由定义，连接词由极大一致性；存在句在 $T^*$ 中时 Henkin 常量给模型见证；模型有见证 $[t]$ 时归纳假设给 $phi(t) in T^*$，再用 $exists I$ 得存在句。全称用否定存在处理。

= PA：递归公理与归纳证明

- *PA 公理*：$S(x)!=0$；$S(x)=S(y) arrow.r x=y$；$x+0=x$，$x+S(y)=S(x+y)$；$x dot 0=0$，$x dot S(y)=x dot y+x$。归纳模式（参数 $z$ 全称绑定）：$phi(0,z) and forall x(phi(x,z) arrow.r phi(S(x),z)) arrow.r forall x phi(x,z)$。数码 $macron(n)=S^n(0)$ 不穷尽非标准模型。

- *结合律证明*：对 $z$ 归纳：$(x+y)+S(z)=S((x+y)+z)=S(x+(y+z))=x+S(y+z)=x+(y+S(z))$。交换律先证 $0+x=x$ 和 $S(x)+y=S(x+y)$。

= 编码与集合公理

- *编码与可计算*：把有限项、公式、推导编码为自然数；检查“$d$ 是编码 $y$ 的结论的证明”可算法执行，并由算术公式 $"Proof"(d,y)$ 表示。$"Thm"(y)=exists d " Proof"(d,y)$。

- *不完备性*：$"diag"(n)$ 表示将编码为 $n$ 的单变量公式代入 $overline(n)$ 后得到句子的编码，$b=⌜B(x)⌝$，$G=B(overline(b))$，则 $T tack.r (G ⇔ not "Thm"(overline(G)))$。*前提*：可有效公理化 (公理可以递归枚举)。

- *ZFC*：外延 (定义集合相等)、分离 (符合 $phi$ 的元素)、配对 ($z = {x} union {y}$)、并集 (所有元素的并集)、幂集、无穷 (存在自然数集)、替代、正则 ($forall x != emptyset, exists y in x and y inter x = emptyset$)、选择 (若 $a$ 每个元素非空，存在 $a$ 上的函数 $f$ 满足 $f(x) in x, forall x in a$)。
