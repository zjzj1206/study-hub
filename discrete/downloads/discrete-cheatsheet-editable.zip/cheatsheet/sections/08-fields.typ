= 08 域扩张、分裂域

- *扩域是向量空间*：$E$ 是 $F$ 的扩域，记作 $E"/"F$，视为向量空间：元素为 $sum a_i v_i$，其中 $a_i in F, v_i in K$。\
  *扩张次数*：$[E:F]=dim_F E$。*塔公式* $[E:F]=[E:K][K:F]$（有限扩张）。 \
  *基与塔公式*：若 $(u_i)$ 是 $K/F$ 的基，$(v_j)$ 是 $E/K$ 的基，则 $(u_i v_j)$ 是 $E/F$ 的基：先按 $v_j$ 再按 $u_i$ 展开证明生成，逆序比较系数证明独立。

- *例*：尺规作图中，可以作出的数都位于二次扩张塔，故其代数次数为 $2$ 的幂是必要条件（一般不充分）；三次不可约实根不可作。

- *代数元*：$alpha$ 满足非零 $F[x]$ 多项式；其首一最小多项式 $m_alpha$ 不可约，且任意使 $alpha$ 为根的多项式均被它整除。 \
  *最小多项式存在性证明*：有限扩张中 $1,alpha,alpha^2,dots$ 必线性相关。取最低次数首一关系式；若它可约，代入 $alpha$ 后域中乘积为0，某个更低次因子也以 $alpha$ 为根，矛盾。

- *超越元*：$alpha$ 不满足任何非零 $F[x]$ 多项式。

- $alpha$ 为代数元：$F(alpha) ≅ F[x]"/"(m_alpha)$；$alpha$ 为超越元：$F(alpha) ≅ "Frac"(F[x])$。

- *代数扩张*：$E"/"F$ 是域扩张，如果 $E$ 中所有元素在都在 $F$ 上代数。

- *有限扩张一定是代数扩张*：$forall alpha in E$，设 $[E:F]=d$，则 $1,alpha, alpha^1, dots, alpha^(d)$ 线性相关，故 $alpha$ 代数。

- *Frobenius*：$"char"F = p$ 时，$(a+b)^p=a^p+b^p$，Frobenius 映射为 $x mapsto x^p$ 为单同态；有限域上是自同构。迭代 $d$ 次就是 $x mapsto x^(p^d)$ 仍然是单同态。

- *分裂*：$f in F[x]$ 且首一，若 $f=product (x-alpha_i)$ 其中 $alpha_i in K$，称 $f$ 在 $K$ 上分裂。

- *分裂域*：$f in F[x]$，若 $f$ 在 $K$ 上分裂且 $K=F(alpha_1, dots, alpha_d)$，称 $K$ 为 $f$ 的分裂域。

- *分裂域存在且唯一*：任意非零 $f in F[x]$，存在唯一分裂域 $K$ 且 $[K:F] <= deg f !$。
  - *存在性*：对 $deg f$ 归纳，取 $f$ 的不可约因子 $p$，令 $F_1=F[x]/(p)$，则 $F_1$ 为 $F$ 的扩域，令 $alpha_1 = macron(x) in F_1$，则有 $p(alpha_1)=0 arrow.r.double f(alpha_1)=0$，故 $f=(x-alpha_1)f_1$，以此类推得到存在性，且 $[K:F] <= deg f !$。
  - *唯一性 (同构意义下)*：设 $K,L$ 均为 $f$ 的分裂域，设 $alpha_1,dots, alpha_d$ 为 $K$ 中 $f$ 的 $d$ 个不同的根，归纳证明存在单同态 $sigma : E arrow.r L$，其中 $E = F(alpha_1,dots, alpha_t)$。考虑下一个根 $alpha$，在 $E$ 上的最小多项式为 $m_(alpha)$，令
  $ tau : E[x] & arrow.r sigma(E)[x] \ sum c_i x^i & mapsto sum sigma(c_i) x^i, $
  由于 $m_(alpha) ∣ f$，故 $f=m_(alpha)h$，$tau(m_(alpha))tau(h)=tau(f)=f arrow.r.double tau(m_(alpha)) ∣ f$，易知 $tau(m_(alpha))$ 在 $sigma(E)[x]$ 中不可约，取 $L$ 中 $tau(m_(alpha))$ 的根 $beta$，构造映射
  $ sigma^* : E(alpha)  & arrow.r sigma(E)(beta) \ sum c_i alpha^i & mapsto sum sigma (c_i) beta ^i, $
  由于 $E(alpha) ≅ E[x]"/"m_(alpha) ≅ sigma(E)[x]"/"tau(m_alpha) ≅ sigma(E)(beta)$，知 $sigma^*$ 为单同态。由于 $sigma(alpha_1),dots, sigma(alpha_d)$ 对应了 $L$ 中的 $d$ 个不同的根，故 $sigma$ 为满射。

- *可分*：多项式在分裂域无重根 ⇔ $gcd(f,f')=1$。$f$ 不可约时，可分$⇔ f'!=0$ 。\
  *特征 $0$ 及有限域上不可约多项式均可分*：特征 $0$ 确保 $deg f >=1 arrow.r.double f'!=0$。$F$ 为有限域，$"char" F = p$，则 $f'=0 arrow.r.double f = sum a_i x^(pi)$，由于 Frobenius 是自同构，故 $forall i, exists b_i in F "s.t." b_i ^p = a_i$，因此 $f=(sum b_i x^i)^p$ 与 $f$ 不可约矛盾。

= 有限域的构造、结构与计数

- *有限域大小为质数的幂*：$"char" F=p$ 为质数，则存在子域 $K$ 同构于 $ZZ_(p)$，设 $[F:K]=d$，则 $abs(F)=p^(d)$。

- *循环性*：$abs(F)=p^d$，则 $F^times ≅ C_(p^d-1)$。更一般，任意域乘法群的有限子群循环。\
  *证明*：设 $G <= F^times$，令 $m=lcm{ "ord"(g) : g in G} <= abs(G)$，$G$ 中存在 $m$ 阶元，且 $G$ 中所有元素均为 $F$ 中 $x^m-1$ 的根，因此 $abs(G) <= m$，故 $abs(G)=m arrow.r.double G ≅ C_m$。

- *费马小定理*：$abs(F)=p^d$，则 $forall x in F backslash {0}, x^(p^d - 1) = 1$。

- *有限域定理*：对于任意质数 $p$ 和正整数 $d$，存在大小为 $p^d$ 的有限域，且在同构意义下唯一，记为 $FF_(p^d)$。
  - *存在性*：设 $f(x)=x^(p^d) - x in FF_(p)[x]$，取 $f$ 的分裂域 $K$，令 $S={x in K : a^ lr(p^d) = a}$，由 $0,1 in S$，$a-b = a^ lr(p^d) - b^ lr(p^d) = (a-b)^ lr(p^d) in S$，$a b = (a b)^ lr(p^d) in S$，$a in S backslash {0} arrow.r a^(-1)in S$，故 $S$ 为域。且 $f'=-1$，故无重根，因此 $abs(S)= lr(p^d)$。
  - *唯一性*：任意大小为 $p^d$ 的域 $EE$，都是同一个多项式的分裂域：$EE$ 的特征一定为 $p$，且 $forall a in EE, a^(p^d)=a$，因此 $x^(p^d)-x=product_(a in EE) (x-a)$，故 $EE$ 为 $x^(p^d)-x$ 在 $FF_p$ 上的分裂域，由分裂域的唯一性知有限域的唯一性。

- *引理*：$gcd(x^(q^a)-x,x^(q^b)-x)=x^(q^(gcd(a,b)))-x$。证明：设 $a >= b$，则 $x^(q^a)≡(x^(q^b))^(q^(a-b))≡x^(q^(a-b)) mod (x^(q^b))$，再由 Euclid 即证。

- *命题*：若 $f in FF_(q)[x]$ 不可约，$deg f = d$，则 $f ∣ x^(q^d)-x$。\
  证明：考虑 $F_1=FF_(q)[x]/(f)$，令 $alpha=macron(x) in F_1$，有 $f$ 是 $alpha$ 在 $FF_(q)$ 上的最小多项式，即 $FF_(q)(alpha) ≅ FF_(q)[x]/(f)$，即 $abs(FF_(q)(alpha))=q^d$，由费马小定理，$alpha = alpha^(q^d)$，因此 $f ∣ x^(q^d)-x$。

- *定理*：$FF_(q)[x]$ 上不可约多项式 $f$ 的分裂域为 $EE$，设 $deg f = d$，则 $[EE:FF_(q)] = d$。\
  证明：取 $f$ 在 $EE$ 中的一个根 $alpha$，由上命题，$f ∣ x^(q^d)-x$，且 $x^(q^d)-x$ 在 $FF_(q)(alpha) ≅ FF_(p^d)$ 上分裂，故 $f$ 在 $F(alpha)$ 上也分裂，故 $[EE:FF_(q)]=d$。

- *定理*：$FF_(q)$ 中 $ x^(q^d) - x = product_(f "首一且在" FF_(q)[x] "中不可约" \ deg f ∣ d) f(x) $\
  证明：设 $f$ 首一且在 $FF_(q)[x]$ 中不可约，$deg f = r$，下面先证 $ f ∣ x^(q^d) - x ⇔ r ∣ d $ 然后直接可得上式。
  - “$arrow.r.double$”：取 $f$ 在 $FF_(q^d)$ 中的根 $alpha$，则 $FF_(q) <= FF_(q)(alpha) <= FF_(q^d)$，$abs(FF_(q)(alpha)) = q^r$，由塔扩张得 $r ∣ d$。
  - “$arrow.l.double$”：取 $f$ 的一个根 $alpha$，有 $alpha^(q^r)=alpha$，取 $d/r$ 次 $q^r$ 次方得  $alpha^(q^d)=alpha$，且 $f$ 是 $alpha$ 的最小多项式，故 $f ∣ x^(q^d)-x$。

- *定理*：在 $FF_(q)$ 中，$forall d in ZZ_+$，在 $FF_(q)[x]$ 中存在 $d$ 次不可约多项式。\
  证明：考虑 $x^(q^d)-x in FF_(q)[x]$ 的分裂域 $EE$，取子域 $KK = {a in EE : a^(q^d) = a} ≅ FF_(q^d)$，若 $KK$ 中每个元素在 $FF_(q)$ 中的最小多项式次数都不为 $d$，则 $KK$ 中所有元素都是 $x^(q^1)-x,dots, x^(q^(d-1))-x$ 的根，而这一共只有 $(q^d-1)/(q-1)<q^d$，矛盾。

- *子域*：$FF_(p^n)$ 含 $p^d$ 阶子域 ⇔ $d ∣ n$，是 $x^(p^d)=x$ 的解集。在共同代数闭包中，$FF_(p^a),FF_(p^b)$ 的交为 $FF_(p^(gcd(a,b)))$，复合为 $FF_(p^("lcm"(a,b)))$。

- *Frobenius 共轭*：在域扩张 $FF_(q^n)"/"FF_q$ 中，令 $sigma: a mapsto a^q$。$alpha$ 的最小多项式根是 $alpha,alpha^q,dots,alpha^(q^(d-1))$；$d$ 为首次回到 $alpha$ 的步数，$d ∣ n$。\
  证明 $d=deg m_alpha$：$FF_(q^n)[x]$ 中多项式 $q$ 次方相当于每个系数取 $q$ 次方同时 $x mapsto x^q$
  $ (a_0 + a_1 x + dots + a_r x^r)^q = a_(0)^q + a_(1)^q x^q + dots + a_(r)^q x^(r q) $
  1. $m_(alpha)(alpha)^q = m_(alpha)(alpha^q)$，故 $alpha, alpha^q, dots, alpha^(q^(d-1))$ 均为 $m_alpha$ 的根。\
  2. 令 $g(x)=product_(i = 0)^(d-1) (x - alpha^(q^i))$，则将 $g$ 的每个系数 $c$ 取 $q$ 次方等价于将每个根取 $q$ 次方，仍然为 $g(x)$ 本身，故 $c^q=c arrow.r.double r in FF_q arrow.r.double g in FF_(q)[x]$。
  *Frobenius 的固定域*：在 $FF_(q^n)"/"FF_q$ 中，$sigma(x)=x^q$，$sigma^k$ 的固定域为 $FF_(q^(gcd(n,k)))$；自同构群有且仅有 $n$ 个元素 $1,sigma,dots,sigma^(n-1)$。

- *不可约计数*：设 $N_(q) (d)$ 表示 $FF_(q)[x]$ 中 $d$ 次首一不可约数，则
  $ q^n =sum_(d ∣ n) d N_(q) (d) arrow.r.double  N_(q) (n) =1/n sum_(d ∣ n) mu(d)q^(n/d) $
