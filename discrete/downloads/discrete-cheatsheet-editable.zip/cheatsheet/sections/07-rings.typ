= 07 环、理想与商

- *环*：$(R,+)$ 是交换群，$(R,dot)$ 是半群，以及左右分配律。

- *交换环*：乘法交换；*整环*：无零因子、含幺、交换。

- *单位*：有乘法逆的元素；*$R^times$*：是单位乘法群。

- *域*：交换且每个元素有乘法逆元。

- *含幺环的特征*：最小的正整数 $c$ 使得 $c dot 1 = 0$，记作 $"char" R$，不存在时 $"char"R=0$。

- *有限整环必为域*：对 $a!=0$，$x mapsto a x$ 单射，有限性使其满射，故有逆。一般群若左逆 $u a=1$、右逆 $a v=1$ 同时存在，则 $u=u(a v)=(u a)v=v$。

- *理想*：$r I = I r subset.eq I$。$(a)$ 表示 $a$ 生成的主理想。$(S)={sum_i u_i a_i v_i:u_i, v_i in R, a_i in S}$；$I+J={i+j:i in I,j in J}$，$I J$ 为有限项乘积之和；$I J subset.eq I inter J$，$I+J=R$ 时相等。

- *商环*：$(a+I)(b+I)=a b+I$。同态核是理想；$R"/""ker" f ≅ "Im" f$；$R"/"I$ 的理想对应于含 $I$ 的理想。 \
  *环的同构补充*：子环 $S$ 与理想 $I$ 满足 $S"/"(S inter I) ≅ (S+I)"/"I$。若 $I subset.eq J$ 均为理想，$(R"/"I)"/"(J"/"I) ≅ R"/"J$；含 $I$ 的理想与商环的理想一一对应。

- *素理想*：真理想 $I$ 满足 $a b in I arrow.r.double a in I$ 或 $b in I$。$I$ 是素理想 ⇔ $R"/"I$ 为无零因子环。

- *极大理想*：真理想 $I$，若理想 $J$ 满足 $I subset.eq J subset.eq R$ 则有 $J=I or J=R$。含幺交换环 $R$ 中，$I$ 是极大理想 ⇔ $R"/"I$ 为域。*证*：$forall a in.not I$ 有 $(a)+I=R$，即 $r a+i=1$，因此 $a+I$ 的逆为 $r+I$；反向由域仅零/全理想及理想对应。

- *环 CRT*：$I+J=R arrow.r.double R"/"(I inter J) ≅ R"/"I times R"/"J$；此时 $I inter J=I J$。*证*：选 $i+j=1$；交中 $x=x i+x j in I J$，故交等于积。映射 $phi : r mapsto (r+I,r+J)$ 核为交，$(a+I,b+J)=phi(a j+b i)$ 故满射。

= 分解与多项式

- *分式域*：$R$ 是整环，$"Frac"(R) := R times (R backslash {0})"/"∼$，$(a,b)∼(c,d) ⇔ a d=b c$；是含 $R$ 的最小域。

- *单位/相伴*：交换环中，$a ∣ b$ 指 $exists u in R, b=a u$。$a ∼ b$ 指 $a ∣ b and b ∣ a$。*不可约*：非零非单位 $p=a b arrow.r.double a in R^times or b in R^times$。*素元*：非零非单位 $p ∣ a b arrow.r.double p ∣ a$ 或 $p ∣ b$。整环中素 ⇒ 不可约；UFD 中二者等价。

- *升链条件 (ACC)*：理想序列 ${I_(n)}_(n >= 1)$ 若满足 $I_(n) subset.eq I_(n+1) forall n >=1$，则最终稳定。
  *ACCP*：任何主理想序列最终稳定。

- *降链条件 (DCC)*：理想序列 ${I_(n)}_(n >= 1)$ 若满足 $I_(n) supset.eq I_(n+1) forall n >=1$，则最终稳定。

- *DCC + 整环 = 域*：对 $a!=0$，链 $(a) supset.eq (a^2) supset.eq dots$ 稳定，故 $exists b, a^n=a^(n+1)b$；消去 $a^n$ 得 $1=a b$。

- *ED*：存在 $delta : R backslash {0} arrow.r ZZ_(>=0)$，使得 $forall a,b in R and b != 0$ 都存在 $q,r in R$ 使得 $a=b q+r$ 且 $r=0 or delta(r) < delta(b)$。
  
- *PID*：所有理想都是主理想的整环。

- *UFD*：分解存在且唯一 (不考虑相伴、顺序) 的整环。

- *ED ⇒ PID ⇒ UFD*。\
  *ED ⇒ PID*：ED 中的非零理想 $I$ 选最小度量元 $d$，证明 $I=(d)$，$forall a in I, a=q d+r$，可以证明 $r=0$。\
  *PID ⇒ UFD*：
    1. *证明不可约元一定是素元*：$p$ 不可约，若 $p ∤ a$，设 $(p,a)=(d)$ 则 $d ∣ p, d ∣ a$，若 $d ∼ p$，则 $p ∣ a$ 矛盾，故 $d ∼ 1$，因此 $(p,a)=(1)$，故 $forall b exists u,v "s.t." p u b+a b v=b$，故 $p ∣ a b arrow.r.double p ∣ b$。\
    2. *证明满足 ACC*：若 ${I_(n)=(a_n)}_(n >= 1)$，则 $I = union.big_(n>=1) I_(n)$ 也是理想，故 $I=(d) arrow.r.double d in I arrow.r.double exists N, d in I_(N)$，故稳定。\
    3. *证明分解存在*：若 $a$ 不存在分解，则 $a$ 可约，故 $a=b c$ 且 $b,c in.not R^times$，$b,c$ 中至少有一个不存在分解，继续这样做，就能得到 $(a_1) subset.eq.not (a_2) subset.eq.not dots$，与 ACC 矛盾。\
    4. *证明分解唯一*：$a=u p_(1) dots p_(r)= v q_(1) dots q_(s)$，则 $p_(1)$ 素，故有 $p_(1) ∣ q_(j)$，因此 $p_(1) ∼ q_(j)$，重复该过程即可。

- *多项式 Euclid*（$g!=0$）：$f=q g+r$，$deg r<deg g$；$exists u,v "s.t." gcd(f,g)=u f+v g$。

- *根与次数*：域上 $f(a)=0 ⇔ (x-a) ∣ f$；非零 $d$ 次多项式最多 $d$ 个根。2、3次不可约 ⇔ 无根。

- *重根判别*：$FF[x]$ 中，$gcd (f,f')=1 ⇔ f$ 在任何 $F$ 的任何扩域 $E$ 中都没有重根。

- *Gauss 引理*：UFD 上本原多项式乘积仍本原；本原 $f in ZZ[x]$ 在 $QQ[x]$ 可约 ⇔ 在 $ZZ[x]$ 可约。约分式域与原环分解时先取内容。\
  *证*：考虑最小的 $f_(i),g_(j)$ 使得 $p ∤ f_(i), p ∤ g_(j)$。

- *结论*：整系数多项式在 $ZZ[x]$ 中可分解等价于在 $QQ[x]$ 中可分解。

- *Eisenstein*：素数 $p$ 不整除首项系数、整除其余系数、$p^2$ 不整除常数项 ⇒ 在 $QQ[x]$ 不可约。\
  *证*：若非平凡分解，则在 $ZZ[x]$ 也可分解成两个正次数多项式的乘积，模 $p$ 后两因子次数不降且乘积仅有最高项，所以两因子常数项均被 $p$ 整除，推出 $p^2$ 整除原常数项，矛盾。

- *模素数判定*：$f in ZZ[x]$ 本原，模 $p$ 后次数不降且不可约 ⇒ $f$ 在 $QQ[x]$ 不可约。模 $p$ 可约不代表原式可约。

- *低次试除*：2、3次试遍域中根；4次无根后仍须排除二次不可约因子。$FF_2$ 上唯一二次不可约为 $x^2+x+1$；三次有 $x^3+x+1$、$x^3+x^2+1$。

= 一些环的例子

- $ZZ$ 满足 ACC 但不满足 DCC。

- *$ZZ[x]$ 非 PID*：若 $(2,x)=(f)$，则 $f∣2$ 使其为常数，且 $f∣x$ 使 $f$ 为单位；但 $1 in.not (2,x)={f in ZZ[x] : f "常数项为偶数"}$。

- *矩阵环*：$M_(n) (FF)$（$n>1$）非交换且有零因子；双边理想只有 $0$ 与全环。

- *群环*：$R[G]$ 所有元素形如 $sum_(g in G) a_g g, a_g in R$。

- *四元数*：四元数满足 $i^2=j^2=k^2=i j k=-1$，$i j=k$，$j i=-k$，是非交换除环。
