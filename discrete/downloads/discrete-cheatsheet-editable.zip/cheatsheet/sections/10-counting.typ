= 09 先定义计数对象

- *容斥*：$abs(union.big_i A_i)=sum_(emptyset != S subset.eq [n])(-1)^(abs(S)+1)abs(inter.big_(i in S)A_i)$。

- 满射 $[n] arrow.r [k]$ 的数量：$k! S(n,k)=sum_(j=0)^k (-1)^j binom(k,j)(k-j)^n$。

- *第二类 Stirling* $S(n,k)$：$n$ 个标号对象分成 $k$ 个非空无标号块。$S(n,k)=S(n-1,k-1)+k S(n-1,k)$。$S(0,0)=1$，$S(n,0)=0$（$n>0$）。\

- *Bell* $B_n$：$n$ 个标号对象分成任意个非空无标号块。$B_n=sum_(k=0)^n S(n,k)$。 

- *Bell 的另一递推*：固定一个元素，其块中再选 $k$ 个，余下任意划分，得到 $B_(n+1)=sum_(k=0)^n binom(n,k)B_(n-k)$，$B_0=1$。

- *第一类 Stirling* $c(n,k)$：恰有 $k$ 个循环的 $n$ 元置换；$c(n,k)=c(n-1,k-1)+(n-1)c(n-1,k)$。

= 球盒模型与受限整数解

- *$n$ 个标号球、$k$ 个标号盒*：允许空盒 $k^n$；不许空盒 $k!S(n,k)$；每盒至多一球 $frac(k!,(k-n)!)$（$n<=k$）。

- *无标号球、标号盒*：允许空盒 $binom(n+k-1,k-1)$；不许空盒 $binom(n-1,k-1)$；每盒至多一球 $binom(k,n)$。

- *标号球、无标号盒*：恰好 $k$ 个非空盒为 $S(n,k)$；至多 $k$ 个非空盒为 $sum_(j=0)^k S(n,j)$。无标号球、无标号盒变为整数分拆。

- *Stirling 基变换*：
$
x^(overline(n)) &= sum_(k=0)^n c(n,k) x^k \
x^n &= sum_(k=0)^n (-1)^(n-k) S(n,k) x^(overline(k)) \
x^(underline(n)) &= sum_(k=0)^n (-1)^(n-k) c(n,k) x^k \
x^n &= sum_(k=0)^n S(n,k) x^(underline(k))
$

- *Stirling* 反演：
$
f(n) &= sum_(k=0)^n S(n,k) g(k) \
g(n) &= sum_(k=0)^n (-1)^(n-k) c(n,k) f(k) 
$
$
sum_(k=m)^n (-1)^(k-m) S(n,k) c(k,m) &= delta_(n m) \
sum_(k=m)^n (-1)^(n-k) c(n,k) S(k,m) &= delta_(n m)
$