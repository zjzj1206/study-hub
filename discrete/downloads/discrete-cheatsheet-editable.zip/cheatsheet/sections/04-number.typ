= 04 整除与同余

- *Euclid/Bézout*（$a,b>0$）：$gcd(a,b)=gcd(b,a mod b)=u a+v b$。$a x+b y=c$ 有整数解 ⇔ $d=gcd(a,b)$ 整除 $c$；通解 $x=x_0+(b/d)t$，$y=y_0-(a/d)t$。$gcd(a,b) "lcm"(a,b)=abs(a b)$。

- *Euclid 引理*：$gcd(a,b)=1$ 且 $a ∣ b c$ ⇒ $a ∣ c$。证明：$u a+v b=1$ 两边乘 $c$。素数整除乘积必整除某因子，推出素分解唯一性。

- *素数指数*：$v_(p) (a b)=v_(p) (a)+v_(p) (b)$；$v_(p) (gcd(a,b))=min(v_(p) (a),v_(p) (b))$；lcm 对应 max。

- *指数差*：$gcd(a^m-1,a^n-1)=a^(gcd(m,n))-1$（$a>1,m,n>0$）；模 $a^n-1$ 有 $a^m-1 ≡ a^(m mod n)-1$，照 Euclid 递推。

- *CRT*（两两互素）：$M=product_i m_i$，$M_i=M/m_i$，求 $M_i t_i ≡ 1 (mod m_i)$，则 $x ≡ sum_i a_i M_i t_i (mod M)$。

= 模幂、剩余与应用

- $phi(n)=n product_(p ∣ n)(1-1/p)$，$sum_(d ∣ n) phi(d)=n$。$gcd(a,n)=1 arrow.r.double a^(phi(n)) ≡ 1 (mod n)$。素数 $p$：$a^p ≡ a (mod p)$；Wilson：$(p-1)! ≡ -1 (mod p)$。 \
  *Euler 证明*：乘以单位 $a$ 置换所有单位剩余类；将它们相乘得到 $a^(phi(n))P ≡ P$，因 $P$ 可逆，可消去。 \
  *Wilson 证明*：模素数 $p$，非零元按逆元配对；自逆元满足 $(x-1)(x+1)=0$，仅为 $±1$（$p=2$ 单独看），剩下乘积为 $-1$。

- *阶*：$"ord"_(n) (a)$ 是使 $a^r ≡ 1$ 的最小正 $r$；$a^k ≡ 1 ⇔ r ∣ k$，$r ∣ phi(n)$。大指数先检查互素再降幂；不互素时拆素数幂，用 CRT 合并。 \
  *求阶*：先知 $r ∣ phi(n)$；对候选阶的素因子逐一试降。若群阶为 $m$，元素 $g$ 生成群 ⇔ 对每个素数 $ell ∣ m$，$g^(m/ell)!=e$。

- *二次剩余*（奇素数 $p$）：$(a/p) in {0,1,-1}$，$(a/p) ≡ a^((p-1)/2) (mod p)$；$(-1/p)=(-1)^((p-1)/2)$。互异奇素数 $p,q$：$(p/q)(q/p)=(-1)^(((p-1)(q-1))/4)$。

- *Stern-Brocot 树*：设端点为 $a/b<c/d$，记为矩阵 $A=mat(a,b; c,d)$，则中介分数为 $(a+c)/(b+d)$。向左 $A L$，向右 $A R$，其中 $L=mat(1,1; 0,1),R=mat(1,0; 1,1)$。\
  $"det"(L) = "det"(R) = 1 arrow.r.double$ 始终有 $b d-a c=1$。\
  故 $cases(p=a m+c n, q=b m+d n)$ 的解为 $cases(m=c q-d p, n=b p-a q)$。\
  $p/q=(m(a+c)+(n-m)c)/(m(b+d)+(n-m)d)=((m-n)a+n(a+c))/((m-n)b+n(b+d))$，故一定可以找到所有正有理数。\
  $(a/b,c/d)$ 内的任意分数，分母至少是 $b+d$。