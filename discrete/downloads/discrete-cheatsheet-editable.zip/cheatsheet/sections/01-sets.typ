= 01 集合、关系、无穷

- *像与原像*：$f(A inter B) subset.eq f(A) inter f(B)$；单射时取等。原像保持并、交、补；$A subset.eq f^(-1) (f(A))$，$f(f^(-1) (B))=B inter "im" f$。

- *等价关系*＝自反＋对称＋传递，等价类构成划分。偏序＝自反＋反对称＋传递；全序要求任意两点可比。良序：每个非空子集有最小元。极小元不必为最小元；有后继不保证良序（$ZZ$）。

- *基数*：$abs(A)<=abs(B)$ 指有单射；双向单射 $arrow.r.double abs(A)=abs(B)$（CSB）。Cantor：$abs(A)<abs(cal(P)(A))$；反证满射 $f:A arrow.r cal(P)(A)$，取 $D={a:a in.not f(a)}$。

- $abs(B^A)=abs(B)^(abs(A))$；$C^(A times B) ≅ (C^B)^A$（函数柯里化）。$abs(NN)=abs(ZZ)=abs(QQ)=aleph_0$，$abs(RR)=2^(aleph_0)$；$abs(RR^NN)=(2^(aleph_0))^(aleph_0)=2^(aleph_0)$。在 AC 下无限基数 $kappa$ 满足 $kappa+kappa=kappa^2=kappa$。

- *序数*：传递集且被 $in$ 良序；$0=emptyset$，$alpha+1=alpha union {alpha}$，极限序数取并。序数加乘不交换：$1+omega=omega$，$omega+1>omega$。超限归纳：由所有 $beta<alpha$ 推出 $alpha$。

- *AC ⇔ 良序定理 ⇔ Zorn*：非空偏序集中每条链有上界，则有极大元。使用：选偏序→链的并给上界→极大元→若未达目标则扩张矛盾。

= 函数、关系与序：定义补全

- *集合代数*：$A backslash B=A inter B^c$；$A triangle B=(A backslash B) union (B backslash A)$。De Morgan：$(union_i A_i)^c=inter_i A_i^c$；$(inter_i A_i)^c=union_i A_i^c$。证明集合等式：逐元素证明双向包含。

- *单满射*：单射 $f(x)=f(y) arrow.r x=y$；满射 $forall y in Y, exists x in X, f(x)=y$。左逆 $g f="id"_X$ ⇒ $f$ 单射；右逆 $f g="id"_Y$ ⇒ $f$ 满射。非空定义域时单射有左逆；AC 下满射有右逆。

- *复合*：$g f$ 单射 ⇒ $f$ 单射；$g f$ 满射 ⇒ $g$ 满射；反方向单独不能推。双射的逆唯一，$(g f)^(-1)=f^(-1) g^(-1)$。

- *等价类*：$[x]={y:y ∼ x}$；$[x]=[y] ⇔ x ∼ y$。商集合上的定义必须检查不依赖代表元；关系图像用有序对表示，$R^(-1)={(y,x):(x,y) in R}$。

- *关系闭包*：自反闭包 $R union Delta_X$；对称闭包 $R union R^(-1)$；传递闭包 $R^+=union_(n>=1)R^n$，自反传递闭包 $R^*=Delta_X union R^+$。等价闭包可理解为无向关系图的连通分支。

- *序的量词*：最小元 $m$ 满足 $forall x in S,m<=x$；极小元满足不存在 $x<m$。上界可在子集之外；$sup A$ 是所有上界中的最小者。有限非空偏序集必有极小/极大元；未必有最小/最大元。

- *Hasse 图*：仅画覆盖关系 $x<y$ 且中间无点，省略自反边和传递边。良序蕴含全序；全序不蕴含良序，$ZZ$、通常顺序下的 $QQ$ 均为反例。

= 无穷与序数：证明路线

- *可数编码*：$NN times NN$ 按对角线枚举；$QQ$ 编成整数对；有限字母表的有限字符串按长度枚举；可数个可数集的并可数（在通常 ZFC 环境中）。无限字符串通常不可数，不能与有限字符串混用。

- *CSB 构造*：单射 $f:A arrow.r B,g:B arrow.r A$。令 $A_0=A backslash g(B)$，$A_(n+1)=g(f(A_n))$，$U=union_(n>=0)A_n$。在 $U$ 上取 $f$，其余点取 $g^(-1)$，拼成双射。

- *可数与连续统*：$abs(cal(P)(NN))=abs({0,1}^NN)=abs(RR)$。二进制展开有双表示端点，严谨构造可用三进制仅取0、2，或双向单射后用 CSB。连续统假设：不存在严格介于 $aleph_0$ 与 $2^(aleph_0)$ 的基数；ZFC（若一致）不能决定它。

- *序数递归*：$alpha+0=alpha$，$alpha+(beta+1)=(alpha+beta)+1$，极限时 $alpha+lambda=sup_(beta<lambda)(alpha+beta)$。乘法同理：$alpha(beta+1)=alpha beta+alpha$；$2 omega=omega$，$omega 2>omega$。

- *良序唯一性*：每个良序集与唯一序数序同构；两个良序集可比较，一个与另一个或其真初始段同构。基数是其等势类中最小的序数；基数加乘与序数加乘不能混淆。

- *自然数递归*：给初值 $a$ 与递推规则 $h(n,x)$，存在唯一 $f:NN arrow.r X$ 满足 $f(0)=a$，$f(n+1)=h(n,f(n))$。存在性逐步构造有限段；唯一性用归纳。归纳是证明性质，递归是定义对象。

- *选择的等价表述*：非空集合族的笛卡尔积非空；每个满射有右逆；每个集合可良序；Zorn 引理。使用 Zorn 时必须给每条链的上界，不能只检查每个有限子集。

- *Dedekind 无限*：集合与某个真子集等势。在 ZFC 中无限集必含可数无限子集，因此无限 ⇔ Dedekind 无限；没有选择公理时不能随意使用这个等价。
