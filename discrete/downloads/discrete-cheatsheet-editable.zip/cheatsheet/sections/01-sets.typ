= 01 映射、关系与序

- *定义·单满射与等势*：$f:S arrow.r T$ 单射指 $f(x)=f(y) arrow.r.double x=y$，满射指 $forall t in T,exists s in S:f(s)=t$；两者兼具为双射。$abs(S)<=abs(T)$ 表示有单射，$abs(S)=abs(T)$ 表示有双射，并不表示 $S=T$。

- *左右逆*：$g f="id"_S$ ⇒ $f$ 单射；$f g="id"_T$ ⇒ $f$ 满射。*证*：同像后施 $g$ 得同元；$t=f(g(t))$ 给满射见证。非空定义域上单射有左逆：像上取逆、像外送到固定点；满射选右逆需在每个纤维选一点（AC）。

- *等价关系*：自反 $x∼x$、对称 $x∼y arrow.r.double y∼x$、传递 $x∼y∼z arrow.r.double x∼z$。$[x]={y:x∼y}$。*性质与证*：等价类覆盖全集；若两类共有 $z$，由对称、传递得 $x∼y$，再得两类相同，故等价类构成划分。

- *偏序*：关系 $prec.eq$ 自反、传递、反对称（$x prec.eq y,y prec.eq x arrow.r.double x=y$）。

- *全序*：再要求任意二元可比。

- *良序*：全序且每个非空子集有最小元。

= 基数与无穷：结论紧接证明

- *关系闭包*：$Delta_X={(x,x):x in X}$；自反闭包 $R union Delta_X$，对称闭包 $R union R^(-1)$，传递闭包 $R^+=union.big_(n>=1)R^n$，自反传递闭包 $R^*=Delta_X union R^+$。每条有限关系链都在 $R^+$ 中，拼接保持传递；任何传递超关系必须含所有 $R^n$，所以它最小。

- *基数*：ZFC 中把集合的大小表示为与之等势的最小序数。$NN,ZZ,QQ$ 可数：整数交错枚举，有理数编码为整数对，$NN^2$ 按对角线枚举。有限字母表的有限串按长度可数；无限二进制串不可数。

- *Cantor*：$abs(A)<abs(cal(P)(A))$。\
  *证*：$a mapsto {a}$ 给单射；若 $f:A arrow.r cal(P)(A)$ 满射，取 $D={a in A:a in.not f(a)}$。设 $D=f(d)$，则 $d in D ⇔ d in.not D$，矛盾。

- *CSB*：单射 $f:A arrow.r B,g:B arrow.r A$ ⇒ 等势。\
  *构造与证*：$A_0=A backslash g(B)$，$A_(n+1)=g(f(A_n))$，$U=union.big_(n>=0)A_n$；$pi$ 在 $U$ 上取 $f$，其余取 $g^(-1)$。其余点属 $g(B)$，故良定义。两片各单射；若跨片同像，则外片点 $y=g(f(x)) in U$，矛盾。若 $b in.not f(U)$，$g(b)$ 既不属 $A_0$，也不属任何 $g(f(A_n))$（用 $g$ 单射），故 $pi(g(b))=b$，满射。

- *连续统假设 (CH)*：$exists.not kappa "s.t." aleph_0 < kappa < 2^(aleph_0)=aleph_1$；连续统假设在一致 ZFC 中不可决定。

= 序数与选择

- *传递集/序数*：$A$ 传递指 $forall y in A,y subset.eq A$；序数是传递集且被 $in$ 严格良序。$0=emptyset$，$alpha+1=alpha union {alpha}$。每个良序型对应唯一序数；极限序数由此前序数取并。超限归纳由“取最小反例”证明。

- *序数递归*：$(S,<=)$ 是良序集，设 $F(a)={F(b) : b < a}$，证明 $F$ 良定义：\
  - 设 $S_(<=a)={b in S:b<=a}$，设 $P(a)$ 表示存在 $S_(<=a)$ 上的局部解 $h_(<=a)$。
  - 对于任意 $h_(<=a),h'_(<=b)$，若二者在共同定义域内不相容，取最小的不相容的 $c$，则 $h_(<=a)(c) = {h_(<=a)(d):d<c} = {h'_(<=b)(d):d<c} =h'_(<=b)(c)$，矛盾，故 $h_(<=a),h'_(<=b)$ 相容。
  - 考虑所有不满足 $P(a)$ 的最小的一个 $a$，则令 $h=union.big_(b<a) h_(<=b)$，$h_(<=a) = h union {(a,{h(b):b<a})}$，则 $h_(<=a)$ 为 $S_(<=a)$ 的局部解，矛盾，故所有局部解都存在。
  - 令 $F=union.big_(a in S) h_(<=a)$，则 $F$ 相容，符合条件。唯一性容易证明。

- *AC ⇔ 良序定理 ⇔ Zorn*：每个集合可良序；非空偏序集每条链有上界则有极大元。应用：构造偏序集→给每条链（含无限链）的上界→极大性排除继续扩张。Dedekind 无限指与真子集等势；ZFC 下等价于无限，无 AC 时不可直接使用该等价。
