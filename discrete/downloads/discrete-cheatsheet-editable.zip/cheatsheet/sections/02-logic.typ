= 02 命题逻辑与一阶逻辑

- *语义/语法*：$Gamma ⊨ phi$＝所有满足前提的赋值/模型满足 $phi$；$Gamma tack.r phi$＝有有限形式证明。经典可靠性＋完备性：二者等价；“完备”不表示每个公式都可证或可证其否定。

- $P arrow.r Q ≡ not P or Q$；$not (P arrow.r Q) ≡ P and not Q$。DNF：真值表真行的极小项取或；CNF：假行的极大项取且。演绎定理：$Gamma,P tack.r Q ⇔ Gamma tack.r P arrow.r Q$。

- *自然演绎*：证 $P arrow.r Q$ 先假设 $P$；证 $not P$ 先假设 $P$ 导出 $bot$；$P,P arrow.r Q$ 得 $Q$；$bot$ 得任意式。RAA：假设 $not P$ 导出 $bot$，撤销假设得 $P$。去 RAA 后通常不能双否消去、排中律、Peirce 律；逆否的正向仍可证。

- *Kripke 反模型*：原子真值向上保持；$w ⊩ P arrow.r Q$ 当且仅当所有 $v>=w$，$v ⊩ P$ 蕴含 $v ⊩ Q$。两点 $w<v$，仅 $v ⊩ p$：$w ⊩ not not p$ 但 $w ⊮ p$。

- *量词*：否定逐层交换 $forall "/" exists$；先改名避免捕获。$not forall x P ≡ exists x not P$；$not exists x P ≡ forall x not P$。$forall x exists y$ 不可与 $exists y forall x$ 换序。替换项须对变量可自由代入。

- *$forall I$*：推广的变量不得自由出现于未撤销假设；*$exists E$*：新见证变量不得自由出现于结论或其余未撤销假设。先引入任意元，再证明，再全称推广。

- *Hilbert（仅 $arrow.r,not$）*：$P arrow.r (Q arrow.r P)$；$(P arrow.r (Q arrow.r R)) arrow.r ((P arrow.r Q) arrow.r (P arrow.r R))$；$(not Q arrow.r not P) arrow.r (P arrow.r Q)$；规则 MP。证明可靠性对推导长度归纳。

= 自然演绎：把目标拆开

- *合取消去/引入*：$P and Q$ 可得 $P$、$Q$；分别证得 $P,Q$ 后得 $P and Q$。*析取消去*：已知 $P or Q$，须在假设 $P$ 和假设 $Q$ 两支中证明同一个结论 $R$，才能撤销两支假设得 $R$。

- *否定与爆炸*：$not P$ 是 $P arrow.r bot$。已有 $P,not P$ 得 $bot$，再得任何 $Q$。反证法 RAA 撤销 $not P$ 得 $P$；“由 $P$ 导矛盾得 $not P$”在直觉主义中也合法。

- *例：$P arrow.r not P tack.r P arrow.r Q$*：① 假设 $P$；② MP 得 $not P$；③ 两者得 $bot$；④ 爆炸得 $Q$；⑤ 撤销①得 $P arrow.r Q$。此证明不使用 RAA。

- *Peirce 律* $((P arrow.r Q) arrow.r P) arrow.r P$：假设前件和 $not P$；再假设 $P$ 得矛盾，再爆炸得 $Q$，撤销得 $P arrow.r Q$；用前件得 $P$，与 $not P$ 矛盾，RAA 得 $P$。

- *等价式*：$P ↔ Q ≡ (P arrow.r Q) and (Q arrow.r P)$；$not(P and Q) ≡ not P or not Q$；$not(P or Q) ≡ not P and not Q$（经典语义）。逆否的逆向一般需要经典原则。

- *范式算法*：先消去 $arrow.r,↔$，把否定推至原子，再用分配律。CNF 为“子句的合取”，DNF 为“合取项的析取”；可满足不等于永真，不可证不等于可证其否定。

= 一阶语法与语义

- *签名*：常量、函数符号、关系符号各有元数。项＝变量/常量/函数作用于项；原子公式＝关系作用于项或项相等；加连接词、量词构成公式。没有自由变量的公式叫句子。

- *结构与赋值*：结构 $cal(M)$ 给非空论域及符号解释；赋值 $s$ 给变量取值。$cal(M),s ⊨ forall x phi$ 表示对每个 $a$，$cal(M),s[x mapsto a] ⊨ phi$。句子的真值与赋值无关。

- *避免捕获*：对 $exists y R(x,y)$ 代入 $x:=y$，必须先改为 $exists z R(x,z)$，结果 $exists z R(y,z)$，不能直接写 $exists y R(y,y)$。

- *四条量词规则*：$forall E$ 任取可自由代入的项；$exists I$ 从具体见证推广；$forall I$ 用与未撤销假设无关的任意变量；$exists E$ 用新变量代表未知见证，最终结论不得依赖该变量。

- *换序与分配*：$forall x forall y$ 可换序，$exists x exists y$ 可换序；$forall x (P and Q) ≡ (forall x P) and (forall x Q)$；存在量词对析取同理。全称对析取、存在对合取一般不可分配。

- *量词否定例*：$not forall x exists y (A(x,y) arrow.r exists z B(x,y,z))$ 等价于 $exists x forall y (A(x,y) and forall z not B(x,y,z))$。

- *Kripke 复核*：$w ⊩ not P$ 当且仅当所有未来世界都不强迫 $P$；$w ⊮ P$ 只说当前未强迫，不等于 $w ⊩ not P$。强迫单调性对公式结构归纳；蕴含必须检查所有未来世界。


- *可靠性*：对推导树归纳，验证每条规则在前提为真时保真。$arrow.r I$ 要考虑任意满足外部假设的赋值；若新增假设为真，用子推导得结论，否则蕴含自动为真。

- *命题完备性*：给定赋值，把每个原子按真假取为正/负文字；结构归纳证明该文字集可推出公式或其否定。若公式永真，所有赋值分支都推出它，再用排中律逐个消去分支假设。

- *紧致性与反模型*：要证 $Gamma ⊨ phi$ 可考虑 $Gamma union {not phi}$ 不可满足；要证某结论不能推出，只需找满足前提却使结论假的模型。直觉主义不可证题需用 Kripke 反模型，经典真值表不够。
