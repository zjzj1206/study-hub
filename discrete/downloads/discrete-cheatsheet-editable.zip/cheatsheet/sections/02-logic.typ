= 02 命题逻辑：语法与语义

- *公式与赋值*：$Gamma ⊨ P$ 指每个满足全部前提的赋值都满足 $P$；$Gamma tack.r P$ 指有有限形式推导。两者是元语言记号。$⟦phi⟧_v$ 表示命题 $phi$ 在赋值 $v$ 下的真假。

= 自然演绎：规则、作用域与例子

- *规则*：$and I$ 从 $P,Q$ 得 $P and Q$，$and E$ 取分量；$arrow.r E$ 从 $P,P arrow.r Q$ 得 $Q$。$arrow.r I$ 从临时假设 $[P]$ 推 $Q$，撤销后得 $P arrow.r Q$。$bot E$ 从矛盾得任意式。RAA 从 $[not P]$ 推矛盾，撤销得 $P$。

- *析取消去*：已有 $P or Q$，须从 $[P]$、$[Q]$ 两支都得到同一 $R$，再撤销两支假设。*演绎定理* $Gamma,P tack.r Q ⇔ Gamma tack.r P arrow.r Q$：正向用 $arrow.r I$，反向用 $arrow.r E$。

- *例·不用 RAA*：$P arrow.r not P tack.r P arrow.r Q$。假设 $P$，$arrow.r E$ 得 $not P$，合成 $bot$，爆炸得 $Q$，撤销 $P$。

- *Peirce 律及证*：$((P arrow.r Q) arrow.r P) arrow.r P$。假设 $H=(P arrow.r Q) arrow.r P$ 与 $not P$；临时假设 $P$，得矛盾再爆炸得 $Q$，撤销得 $P arrow.r Q$；用 $H$ 得 $P$，与 $not P$ 冲突，RAA 得 $P$，最后撤销 $H arrow.r P$。

= 可靠性、完备性与系统区别

- *可靠性及证*：$Gamma tack.r P arrow.r.double Gamma ⊨ P$。对推导树归纳检查规则保真：对于一个推导过程，设假设为 $Gamma$，结论为 $P$，证明 $Gamma tack.r P arrow.r.double Gamma ⊨ P$。

- *经典 ND 完备性*：$Gamma ⊨ phi arrow.r.double Gamma tack.r phi$。以下直接证明逆否，不循环调用紧致性；以 $and,arrow.r,bot$ 为基本连接词，$not A$ 缩写为 $A arrow.r bot$。  \
  *① 保持一致*：设 $Gamma ⊬ phi$，则 $T_0=Gamma union {not phi}$ 一致，否则用 RAA 撤销 $not phi$ 就得 $Gamma tack.r phi$。对一致 $T$，$T union {A}$ 与 $T union {not A}$ 至少一个一致：若两者都推出 $bot$，否定引入给 $T tack.r not A,not not A$，矛盾。  \
  *② 完成理论*：枚举全部公式 $A_0,A_1,dots$，每步选 $A_i$ 或 $not A_i$ 加入，保持一致；取递增并集 $T^*$。若并集有矛盾证明，有限多个前提全在某一步，违背该步一致。故 $T^*$ 一致且每个 $A,not A$ 恰有一个在其中。若 $T^* tack.r A$ 但 $A in.not T^*$，则 $not A in T^*$，又得矛盾；所以它对推导封闭。  \
  *③ 真值引理*：定义 $v(p)=1 ⇔ p in T^*$，对公式结构归纳证 $⟦A⟧_v=1 ⇔ A in T^*$。原子由定义，$bot$ 不在一致集。\
  $⟦B and C⟧_v=1 ⇔ B and C in T^*$，左边等价于 $⟦B⟧_v=⟦C⟧_v=1 ⇔ B,C in T^*$。两向分别用 $and E,I$ 与封闭性。\
  $⟦B arrow.r C⟧_v=1 ⇔ B arrow.r C in T^*$，左边等价于 $⟦B⟧_v=0$ 或 $⟦C⟧_v=1 ⇔ B in.not T^*$ 或 $C in T^*$。\
  *④ 结束*：$Gamma subset.eq T^*$，故 $v$ 满足全部前提；$not phi in T^*$，故 $v(phi)=0$。因此 $Gamma ⊭ phi$，逆否即完备性。可数语言用枚举；不可数时在 ZFC 中良序全部公式、超限逐步决定，极限取并，同样由证明只用有限前提保证一致。


- *经典/直觉主义/最小逻辑*：依次去 RAA、再去爆炸。

- *Kripke 定义*：世界有偏序关系 $<=$；$v(w,p)=0"/"1$ 原子命题在世界 $w$ 下的真假；$forall w <= u, v(w,p)=1 arrow.r.double v(u,p)=1$。\
  $v(w,phi and psi) = 1 ⇔ v(w,phi)=1 and v(w,psi)=1$；$v(w,phi or psi) = 1 ⇔ v(w,phi)=1 or v(w,psi)=1$\
  $v(w,phi arrow.r psi) = 1 ⇔ forall u >= w, v(u,phi)=1 arrow.r.double v(u,psi)=1$。$v(w,phi)=1$ 表示一定成立，$v(w,phi)=1$ 表示尚未明确。

- *持续性*：$forall w<=u$ 且 $v(w,phi)=1$，则 $v(u,phi)=1$，证明：\
  对于公式归纳，原子情形就是定义，$and,or$ 情形是简单的；$v(w,phi arrow.r psi)=1$ 的情形：$forall w <= u$，也有 $forall u <= w'$，若 $v(w',phi)=1$，也有 $v(w',psi)=1$，故 $v(u,phi arrow.r psi)=1$ 成立。

- *直觉主义素理论*：若 $T tack.r alpha$ 则 $alpha in T$；一致：$bot in.not T$；素性：若 $alpha or beta in T$ 则 $alpha in T$ 或 $beta in T$。\
  *保持 $theta$ 不可推导的素理论扩张*：枚举所有公式 $alpha_n$ 若 $T_n,alpha_n tack.r theta$ 则不加入 $alpha_n$，否则加入。则最后的 $T=union.big_(n>=0)T_n$ 为素理论：\
  若 $T tack.r alpha$ 且 $alpha in.not T arrow.r.double T, alpha tack.r theta$，则 $T tack.r theta$，矛盾；若 $bot in T$ 则爆炸得 $theta$ 矛盾；若 $alpha or beta in T$ 且 $alpha,beta in.not T$，则 $T,alpha tack.r theta$ 且 $T,beta tack.r theta$，则有 $T,alpha or beta tack.r theta$，矛盾。

- *典范模型与真值引理*：$W$ 为所有素理论的集合，以 $subset.eq$ 为偏序，对于原子公式 $p$，定义 $v(T,p)=1 ⇔ p in T$，则可证明真值引理：$v(T,phi) = 1 ⇔ phi in T$（对于公式 $phi$ 归纳证明）。

- *Kripke 语义可靠性、完备性*：$Gamma scripts(⊩)_("Kripke") phi ⇔ Gamma scripts(tack.r)_("i") phi$。\
  *完备性证明*：证明逆否命题，假设 $Gamma scripts(tack.r.not)_("i") phi$，存在素理论 $T supset.eq Gamma$ 且 $phi in.not T$；把 $T$ 放在典范模型中，则 $phi$ 在 $T$ 中不成立，故 $Gamma scripts(⊭)_("Kripke") phi$。

- *System K*：有限序列 $Gamma ⇒ Delta$ 表示 $and.big Gamma arrow.r or.big Delta$。当 $Gamma inter Delta != emptyset$ 则 $Gamma ⇒ Delta$ 为公理。
