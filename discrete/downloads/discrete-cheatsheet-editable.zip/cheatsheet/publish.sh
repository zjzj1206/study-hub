#!/usr/bin/env bash
set -euo pipefail
sheet_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$sheet_dir/publish.py" "$@"
