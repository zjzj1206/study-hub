"""Generate connected SEQ circuit schematics, with explicit data and control nets."""
from pathlib import Path
from html import escape

class Circuit:
    def __init__(self, slug, title, height=820):
        self.slug=slug; self.height=height; self.p=[]
        self.p.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="{height}" viewBox="0 0 1000 {height}" role="img" aria-labelledby="title desc"><title id="title">{escape(title)}</title><desc id="desc">连线式 SEQ 电路图。实线为数据，虚线为控制，圆点表示分支连接，无圆点交叉不连接。</desc>')
        self.p.append('''<defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#243c54"/></marker><marker id="c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#b45309"/></marker></defs><style>text{font-family:"Noto Sans CJK SC","Microsoft YaHei",sans-serif;fill:#172c45;font-size:18px}.label{paint-order:stroke;stroke:white;stroke-width:4px;stroke-linejoin:round}</style>''')
        self.p.append(f'<rect width="1000" height="{height}" fill="white"/>')
        self.text(30,38,title,size=25)
        self.text(30,72,'实线：数据 / 字段　　虚线：控制　　●：连接点　　交叉无点：不连接',size=16)
    def text(self,x,y,s,size=18,anchor='start',color=None):
        self.p.append(f'<text class="label" x="{x}" y="{y}" text-anchor="{anchor}" style="font-size:{size}px;'+(f'fill:{color};' if color else '')+f'">{escape(s)}</text>')
    def box(self,x,y,w,h,*labels,control=False,state=False):
        self.p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{10 if control else 2}" fill="{"#fff2df" if control else "#e6f1fc"}" stroke="#243c54" stroke-width="2.5"/>')
        if state:self.p.append(f'<path d="M{x+12} {y+h}l8 -12l8 12" fill="none" stroke="#243c54" stroke-width="2"/>')
        for i,s in enumerate(labels):self.text(x+w/2,y+h/2+(i-(len(labels)-1)/2)*25+6,s,anchor='middle')
    def mux(self,x,y,w,name,inputs):
        self.p.append(f'<path d="M{x} {y+75}L{x+20} {y}H{x+w-20}L{x+w} {y+75}Z" fill="#e6f1fc" stroke="#243c54" stroke-width="2.5"/>')
        self.text(x+w/2,y+33,name,anchor='middle')
        for i,(label,_) in enumerate(inputs):self.text(x+(i+1)*w/(len(inputs)+1),y+62,str(i),anchor='middle',size=15)
        return [(x+(i+1)*w/(len(inputs)+1),y+75) for i in range(len(inputs))]
    def wire(self,pts,control=False,arrow=True):
        d='M'+' L'.join(f'{x},{y}' for x,y in pts)
        self.p.append(f'<path d="{d}" fill="none" stroke="{"#b45309" if control else "#243c54"}" stroke-width="2.3"'+(' stroke-dasharray="6 5"' if control else '')+(f' marker-end="url(#{"c" if control else "a"})"' if arrow else '')+'/>')
    def dot(self,x,y,control=False):self.p.append(f'<circle cx="{x}" cy="{y}" r="4.5" fill="{"#b45309" if control else "#243c54"}"/>')
    def foot(self,lines):
        for i,s in enumerate(lines):self.text(30,self.height-25-(len(lines)-1-i)*27,s,size=17)
    def save(self):
        self.p.append('</svg>');(Path(__file__).parent/'assets'/f'seq-{self.slug}.svg').write_text('\n'.join(self.p))


def build():
    # Fetch follows the textbook's bottom-to-top physical layout.
    c=Circuit('fetch','FETCH / 取指：PC → 指令字节 → 字段与顺序地址',880)
    c.box(390,700,110,60,'PC',state=True);c.box(250,540,380,90,'指令内存')
    c.wire([(445,700),(445,630)]);c.dot(445,665)
    c.box(270,420,120,60,'Split');c.box(460,420,170,60,'Align')
    c.wire([(330,540),(330,480)]);c.text(335,518,'Byte 0')
    c.wire([(545,540),(545,480)]);c.text(550,518,'Bytes 1–9')
    c.box(240,310,90,60,'icode',control=True);c.box(350,310,90,60,'ifun',control=True)
    c.wire([(185,290),(255,290),(255,310)]);c.text(180,282,'INOP',anchor='middle',size=16)
    c.wire([(455,290),(425,290),(425,310)]);c.text(445,282,'FNONE',anchor='middle',size=16)
    c.wire([(310,420),(310,390),(285,390),(285,370)])
    c.wire([(350,420),(350,390),(395,390),(395,370)])
    for x,label in [(285,'icode'),(395,'ifun'),(490,'rA'),(550,'rB'),(610,'valC')]:
        c.wire([(x,310 if x in (285,395) else 420),(x,115)]);c.text(x,103,label,anchor='middle')
    c.box(60,190,120,65,'Instr valid',control=True)
    c.wire([(285,220),(180,220)]);c.dot(285,220);c.wire([(60,220),(20,220)]);c.text(30,175,'instr_valid → Stat',size=16)
    c.box(685,170,125,65,'Need valC',control=True);c.box(685,280,125,65,'Need regids',control=True)
    c.wire([(285,145),(655,145),(655,200),(685,200)]);c.dot(285,145)
    c.wire([(285,270),(655,270),(655,310),(685,310)]);c.dot(285,270)
    c.box(865,190,105,140,'PC','增加')
    c.wire([(445,665),(920,665),(920,330)])
    c.wire([(810,200),(865,200)],True)
    c.wire([(810,310),(835,310),(865,310)],True);c.dot(835,310,True)
    c.wire([(835,310),(835,450),(630,450)],True)
    c.wire([(920,190),(920,115)]);c.text(920,103,'valP',anchor='middle')
    c.wire([(250,585),(210,585),(210,340),(240,340)],True);c.dot(210,585,True)
    c.wire([(210,395),(465,395),(465,340),(440,340)],True);c.dot(210,395,True)
    c.wire([(210,585),(35,585)],True);c.text(38,565,'imem_error → Stat',size=16)
    c.foot(['icode / ifun 选择：imem_error=1 → INOP / FNONE；否则取 Split 的高 / 低 4 位。',
      'Align：need_regids=1 时分出 rA/rB，否则为 RNONE；常数从 PC+1+need_regids 开始。',
      'valP = PC + 1 + need_regids + 8×need_valC；valC 仅在 need_valC=1 时使用。'])
    c.save()

    c=Circuit('decode','DECODE / 译码：源选择器 → 寄存器堆 → valA / valB',800)
    c.box(285,180,430,180,'寄存器堆 R[0…14]','两个组合读端口')
    for x,name in [(390,'valA → Execute / Memory'),(610,'valB → Execute')]:
        c.wire([(x,180),(x,115)]);c.text(x,103,name,anchor='middle',size=17)
    c.text(320,340,'srcA');c.text(615,340,'srcB')
    for x,name,labels in [(180,'srcA',['rA','RRSP','RNONE']),(570,'srcB',['rB','RRSP','RNONE'])]:
        ports=c.mux(x,445,250,name,[(v,0) for v in labels])
        center=x+125;target=350 if name=='srcA' else 650
        c.wire([(center,445),(center,405),(target,405),(target,360)])
        for (px,py),v in zip(ports,labels):c.wire([(px,590),(px,py)]);c.text(px,617,v,anchor='middle')
    c.box(430,545,120,65,'源选择控制',control=True)
    c.wire([(490,650),(490,610)],True);c.text(490,677,'icode ← Fetch',anchor='middle')
    c.wire([(430,570),(415,570),(415,545),(455,545),(455,480),(420,480)],True)
    c.wire([(550,570),(555,570),(555,480),(580,480)],True)
    c.foot(['srcA：rA ← rrmovq/cmovXX、rmmovq、OPq、pushq；RRSP ← popq、ret；其余 RNONE。',
     'srcB：rB ← OPq、rmmovq、mrmovq；RRSP ← pushq、popq、call、ret；其余 RNONE。',
     'rA/rB 来自 Fetch；RRSP=0x4，RNONE=0xF。读旧状态；写回端口见 Write back 图。']);c.save()

    c=Circuit('execute','EXECUTE / 执行：输入选择 → ALU；CC → 条件判断',1060)
    c.box(370,385,250,100,'ALU','aluB OP aluA')
    c.wire([(495,385),(495,105)]);c.text(495,95,'valE → Memory / Write back',anchor='middle',size=17)
    c.box(655,245,120,70,'CC',state=True);c.box(820,145,145,70,'Cond',control=True)
    c.wire([(620,410),(715,410),(715,315)]);c.text(725,373,'候选 CC')
    c.wire([(715,245),(715,180),(820,180)]);c.text(735,168,'旧 CC')
    c.wire([(892,145),(892,105)]);c.text(892,95,'Cnd → 写回 / PC',anchor='middle',size=17)
    c.wire([(965,265),(965,180)],True);c.text(965,292,'ifun',anchor='end')
    c.box(55,220,175,95,'ALU 控制','icode / ifun',control=True)
    c.wire([(85,140),(85,220)],True);c.text(85,122,'icode ← Fetch',anchor='middle',size=16)
    c.wire([(195,140),(195,220)],True);c.text(195,170,'ifun',anchor='middle')
    c.wire([(230,250),(320,250),(320,420),(370,420)],True);c.text(245,238,'alufun')
    c.wire([(230,290),(270,290),(270,345),(640,345),(640,280),(655,280)],True);c.text(480,335,'set_cc = (icode == IOPQ)',size=16)
    c.wire([(800,350),(800,300),(775,300)],True);c.text(810,355,'CLK',size=16)
    for x,name,labels in [(85,'aluA',['valA','valC','−8','+8','0']),(605,'aluB',['valB','0'])]:
        ports=c.mux(x,590,310,name,[(v,0) for v in labels])
        c.wire([(x+155,590),(x+155,535),(420 if name=='aluA' else 570,535),(420 if name=='aluA' else 570,485)])
        for (px,py),v in zip(ports,labels):c.wire([(px,745),(px,py)]);c.text(px,773,v,anchor='middle')
    c.wire([(140,315),(140,545),(50,545),(50,625),(95,625)],True)
    c.dot(50,625,True);c.wire([(50,625),(50,830),(955,830),(955,625),(905,625)],True)
    c.text(500,820,'icode 决定两个输入选择器',anchor='middle',size=16)
    c.foot(['aluA：valA ← rrmovq/cmovXX、OPq；valC ← irmovq、rmmovq、mrmovq；',
       '         −8 ← call/pushq；+8 ← ret/popq；其余 0。valA/valB 来自 Decode，valC 来自 Fetch。',
       'aluB：valB ← rmmovq、mrmovq、OPq、pushq、popq、call、ret；其余 0。',
       'alufun：OPq 选 ifun，其余选 ALUADD。set_cc 与 CLK 控制候选 CC 的写入。',
       'Cond 使用已保存的 CC 与 Fetch 的 ifun；Cnd 不取本指令 ALU 的候选 CC。']);c.save()

    c=Circuit('memory','MEMORY / 访存：地址与写数据分别选择',860)
    c.box(300,200,400,170,'数据内存 M8','读出组合传播 / 写入在提交时钟沿')
    c.wire([(485,200),(485,115)]);c.text(485,103,'valM → Write back / PC update',anchor='middle')
    c.wire([(700,245),(940,245)]);c.text(760,230,'dmem_error → Stat',size=17)
    c.text(330,350,'addr');c.text(590,350,'data')
    c.box(35,220,180,120,'访存控制',control=True)
    for y,label in [(245,'mem_read'),(285,'mem_write')]:
        c.wire([(215,y),(300,y)],True);c.text(220,y-8,label,size=14)
    c.wire([(125,155),(125,220)],True);c.text(125,140,'icode ← Fetch',anchor='middle',size=16)
    c.wire([(250,390),(250,325),(300,325)],True);c.text(250,412,'CLK',anchor='middle',size=16)
    for x,name,labels,target in [(150,'mem_addr',['valE','valA','0'],360),(570,'mem_data',['valA','valP','0'],620)]:
        ports=c.mux(x,465,270,name,[(v,0) for v in labels]);c.wire([(x+135,465),(x+135,420),(target,420),(target,370)])
        for (px,py),v in zip(ports,labels):c.wire([(px,610),(px,py)]);c.text(px,638,v,anchor='middle')
    c.wire([(125,340),(125,500),(160,500)],True);c.dot(125,405,True)
    c.wire([(125,405),(75,405),(75,685),(920,685),(920,500),(830,500)],True)
    c.foot(['mem_addr：valE ← rmmovq/mrmovq/pushq/call；valA ← popq/ret；其余 0。',
      'mem_data：valA ← rmmovq/pushq；valP ← call；其余 0。两者的选择控制均来自 icode。',
      'mem_read：mrmovq/popq/ret；mem_write：rmmovq/pushq/call；其余均不使能。',
      'valE 来自 Execute；valA 来自 Decode；valP 来自 Fetch。popq/ret 用旧 R[%rsp] 读内存。']);c.save()

    c=Circuit('writeback','WRITE BACK / 写回：两个地址选择器、两个写端口',890)
    c.box(290,170,420,180,'寄存器堆 R[0…14]','同一时钟沿更新；同地址时 M 端口优先',state=True)
    for x,label in [(320,'dstE'),(435,'valE'),(560,'dstM'),(675,'valM')]:c.text(x,332,label,anchor='middle',size=16)
    c.wire([(435,490),(435,350)]);c.text(435,518,'valE ← Execute',anchor='middle',size=16)
    c.wire([(675,490),(675,350)]);c.text(675,518,'valM ← Memory',anchor='middle',size=16)
    for x,name,labels,target in [(80,'dstE',['rB','RRSP','RNONE'],320),(710,'dstM',['rA','RNONE'],560)]:
        ports=c.mux(x,430,230,name,[(v,0) for v in labels]);c.wire([(x+115,430),(x+115,385),(target,385),(target,350)])
        for (px,py),v in zip(ports,labels):c.wire([(px,585),(px,py)]);c.text(px,610,v,anchor='middle')
    c.box(400,590,200,70,'写地址控制',control=True)
    c.wire([(445,720),(445,660)],True);c.text(445,743,'icode ← Fetch',anchor='middle',size=16)
    c.wire([(560,720),(560,660)],True);c.text(600,704,'Cnd ← Execute',size=16)
    c.wire([(400,620),(340,620),(340,465),(300,465)],True)
    c.wire([(600,620),(670,620),(670,465),(720,465)],True)
    c.wire([(125,250),(290,250)],True);c.text(125,230,'CLK',size=18)
    c.text(725,190,'写使能：',size=17);c.text(725,217,'E：dstE ≠ RNONE',size=17);c.text(725,244,'M：dstM ≠ RNONE',size=17)
    c.foot(['dstE：rB ← irmovq/OPq 或条件真的 rrmovq/cmovXX；RRSP ← 四类栈操作；其余 RNONE。',
      'dstM：rA ← mrmovq/popq；其余 RNONE。rA/rB 来自 Fetch；RRSP 与 RNONE 为常量。',
      'E 数据固定为 valE；M 数据固定为 valM。popq %rsp：最终 R[%rsp]=valM，而不是 valE。']);c.save()

    c=Circuit('pc-update','PC UPDATE / 下一 PC：三路选择与反馈',930)
    c.box(365,160,230,85,'PC',state=True)
    c.wire([(480,160),(480,110)]);c.text(480,98,'PC → Fetch 指令内存与 PC 增量器',anchor='middle')
    ports=c.mux(265,345,430,'new_pc',[('valC',0),('valM',0),('valP',0)])
    c.wire([(480,345),(480,245)]);c.text(495,300,'new_pc')
    for (px,py),label,source in zip(ports,['valC','valM','valP'],['Fetch','Memory','Fetch']):
        c.wire([(px,515),(px,py)]);c.text(px,545,label,anchor='middle');c.text(px,570,source,anchor='middle',size=16)
    c.box(760,335,180,90,'PC 选择控制',control=True)
    c.wire([(760,380),(685,380)],True)
    c.wire([(795,530),(795,425)],True);c.text(795,554,'icode',anchor='middle');c.text(795,578,'Fetch',anchor='middle',size=16)
    c.wire([(905,530),(905,425)],True);c.text(905,554,'Cnd',anchor='middle');c.text(905,578,'Execute',anchor='middle',size=16)
    c.wire([(265,205),(365,205)],True);c.text(265,190,'CLK')
    c.box(80,685,620,65,'Stat 逻辑',control=True)
    for x,label,origin in [(145,'imem_error','Fetch'),(305,'dmem_error','Memory'),(465,'instr_valid','Fetch'),(625,'icode','Fetch')]:
        c.text(x,625,label,anchor='middle',size=16);c.text(x,647,origin,anchor='middle',size=15);c.wire([(x,655),(x,685)],True)
    c.wire([(700,718),(960,718)],True);c.text(720,700,'Stat → 执行 / 停止控制',size=16)
    c.foot(['new_pc：call → valC；jXX 且 Cnd=1 → valC；ret → valM；其余 → valP。',
      'Stat 优先级：地址错 ADR → 非法类别 INS → halt 的 HLT → 正常 AOK。',
      'PC 写入表示正常指令的时钟沿提交；halt/错误停止执行，不能将默认 valP 理解为继续运行。']);c.save()

if __name__=='__main__': build()
