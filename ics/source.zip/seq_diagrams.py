"""Build self-contained SEQ signal-path SVGs (no runtime renderer required)."""
from pathlib import Path
from html import escape

# Each lane: selector/block, all input alternatives, control origin, output consumers.
DIAGRAMS = {
'fetch': ('01 / FETCH · 取指', [
 ('指令内存', ['PC ← PC 寄存器（64 位地址）'], '地址输入决定读取位置；错误输出 imem_error', ['首字节 → imem_icode / imem_ifun', '后续 9 字节 → 字段对齐单元', 'imem_error → 编码选择器、Stat']),
 ('编码 MUX', ['imem_icode / imem_ifun ← 首字节', 'INOP / FNONE ← 固定常量'], 'imem_error ← 指令内存：1 选常量；0 选首字节', ['icode / ifun（各 4 位）', 'icode → 各阶段控制逻辑', 'ifun → ALU 功能 / 条件判断']),
 ('字段对齐', ['后续字节 ← 指令内存', 'RNONE ← 无寄存器字段时'], 'icode → need_regids（寄存器字段）、need_valC（常数字段）', ['rA / rB（各 4 位）→ 寄存器选择器', 'valC（64 位）→ Execute / PC update', '常数起点：PC+1+need_regids']),
 ('PC 增量器', ['PC ← PC 寄存器', '1 ← 首字节长度', 'need_regids + 8×need_valC ← 长度控制'], 'icode → need_regids、need_valC（各 1 位）', ['valP = PC+1+need_regids+8×need_valC', 'valP → Memory（call 返回地址）', 'valP → PC update（顺序地址）']),
 ('有效性检查', ['icode ← 编码 MUX'], '与基础指令的 icode 集合比较（见下方 HCL）', ['instr_valid（1 位）→ Stat', '这里只检查类别，不是完整编码验证']),
 ], '字段对齐的 valC 仅在 need_valC=1 时有意义；按小端序组合 8 字节。无常数字段时不使用该输出。'),
'decode': ('02 / DECODE · 两个独立读端口', [
 ('srcA MUX', ['rA ← Fetch：rrmovq/cmovXX、rmmovq、OPq、pushq', 'RRSP ← 常量：popq、ret', 'RNONE ← 常量：其余指令'], 'icode ← Fetch → srcA 选择逻辑', ['srcA（4 位）→ 寄存器堆 A 读地址', 'valA = R[srcA]（64 位）', 'valA → Execute / Memory']),
 ('srcB MUX', ['rB ← Fetch：OPq、rmmovq、mrmovq', 'RRSP ← 常量：pushq、popq、call、ret', 'RNONE ← 常量：其余指令'], 'icode ← Fetch → srcB 选择逻辑', ['srcB（4 位）→ 寄存器堆 B 读地址', 'valB = R[srcB]（64 位）', 'valB → Execute']),
 ('寄存器堆', ['旧 R[0…14] ← 上一时钟沿后的状态'], 'srcA、srcB 分别选读；读端口为组合逻辑，不需写时钟', ['A、B 两个端口可同时读同一寄存器', 'popq / ret：valA = valB = R[%rsp]', '本周期写端口详见 Write back 图']),
 ], 'RRSP=0x4 是 %rsp 的编号；RNONE=0xF 表示无寄存器。RNONE 对应的读值不参与有效操作。'),
'execute': ('03 / EXECUTE · ALU 与条件码', [
 ('aluA MUX', ['valA ← Decode：rrmovq/cmovXX、OPq', 'valC ← Fetch：irmovq、rmmovq、mrmovq', '−8 ← 常量：call、pushq', '+8 ← 常量：ret、popq', '0 ← 常量：其余'], 'icode ← Fetch → ALU A 输入选择逻辑', ['aluA（64 位）→ ALU 的 A 端']),
 ('aluB MUX', ['valB ← Decode：访存、OPq、四类栈操作', '0 ← 常量：其余（包括两类寄存器传送）'], 'icode ← Fetch；访存=rmmovq/mrmovq，栈=pushq/popq/call/ret', ['aluB（64 位）→ ALU 的 B 端']),
 ('功能 MUX', ['ifun ← Fetch：OPq', 'ALUADD ← 常量：其余'], 'icode ← Fetch → alufun 选择逻辑', ['alufun → ALU 功能控制端', 'OPq：add / sub / and / xor']),
 ('ALU', ['aluA ← A 选择器', 'aluB ← B 选择器'], 'alufun ← 功能 MUX；计算 aluB OP aluA', ['valE（64 位）→ Memory / Write back', '候选 ZF / SF / OF → CC 寄存器']),
 ('CC 寄存器', ['候选 ZF / SF / OF ← ALU'], 'icode → set_cc=(icode==IOPQ)；CLK 上升沿且使能才写', ['保存的 CC → 条件判断单元', 'pushq / popq / call / ret 不更新 CC']),
 ('条件判断', ['CC ← 已保存的条件码（旧状态）'], 'ifun ← Fetch → 条件类型（无条件 / le / l / e / ne / ge / g）', ['Cnd（1 位）→ Write back 的 dstE', 'Cnd（1 位）→ PC update 的 new_pc']),
 ], '条件传送和跳转读取已保存的 CC；不读取本指令的候选 CC。正常执行的提交时机见正文。'),
'memory': ('04 / MEMORY · 数据内存', [
 ('地址 MUX', ['valE ← Execute：rmmovq、mrmovq、pushq、call', 'valA ← Decode：popq、ret（旧 R[%rsp]）', '0 ← 常量：其余'], 'icode ← Fetch → mem_addr 选择逻辑', ['mem_addr（64 位）→ 数据内存地址端']),
 ('写数据 MUX', ['valA ← Decode：rmmovq、pushq', 'valP ← Fetch：call（返回地址）', '0 ← 常量：其余'], 'icode ← Fetch → mem_data 选择逻辑', ['mem_data（64 位）→ 数据内存写数据端']),
 ('数据内存', ['mem_addr ← 地址 MUX', 'mem_data ← 写数据 MUX'], 'icode → mem_read：mrmovq/popq/ret；mem_write：rmmovq/pushq/call', ['读：valM = M8[mem_addr] → 写回 / PC', '写：M8[mem_addr] ← mem_data（时钟沿）', 'dmem_error → Stat（地址错误）']),
 ], '读使能决定是否读，写使能和提交时钟决定是否写；默认地址 0 并不意味着访问地址 0。'),
'writeback': ('05 / WRITE BACK · 双写端口', [
 ('dstE MUX', ['rB ← Fetch：irmovq、OPq、条件满足的 rrmovq/cmovXX', 'RRSP ← 常量：pushq、popq、call、ret', 'RNONE ← 常量：其余（含条件假 cmovXX）'], 'icode ← Fetch；Cnd ← Execute 的 Cond(CC,ifun)', ['dstE（4 位）→ E 端口写地址']),
 ('dstM MUX', ['rA ← Fetch：mrmovq、popq', 'RNONE ← 常量：其余'], 'icode ← Fetch → dstM 选择逻辑', ['dstM（4 位）→ M 端口写地址']),
 ('E 写端口', ['valE ← Execute 的 ALU（64 位）'], 'dstE ← dstE MUX；dstE≠RNONE 且 CLK 上升沿', ['R[dstE] ← valE', '写回 ALU 结果 / 新 R[%rsp]']),
 ('M 写端口', ['valM ← Memory 的读结果（64 位）'], 'dstM ← dstM MUX；dstM≠RNONE 且 CLK 上升沿', ['R[dstM] ← valM', '两个端口写入同一个寄存器堆']),
 ], '写地址相同且均有效时，M 端口优先：popq %rsp 最终 R[%rsp]=valM，而不是 valE。'),
'pc-update': ('06 / PC UPDATE · 下一条指令', [
 ('next-PC MUX', ['valC ← Fetch：call，或 Cnd=1 的 jXX', 'valM ← Memory：ret', 'valP ← Fetch：其余（含 Cnd=0 的 jXX）'], 'icode ← Fetch；Cnd ← Execute → new_pc 选择逻辑', ['new_pc（64 位）→ PC 寄存器输入', '优先顺序：call → 跳转成立 → ret → 默认']),
 ('PC 寄存器', ['new_pc ← next-PC MUX'], 'CLK 上升沿提交正常指令的新 PC', ['PC（64 位）→ Fetch 的指令内存', 'PC（64 位）→ Fetch 的 PC 增量器']),
 ('状态逻辑', ['imem_error ← Fetch；dmem_error ← Memory', 'instr_valid ← Fetch 的类别检查', 'icode ← Fetch'], '优先判定：地址错 → 非法类别 → halt → 正常', ['Stat = ADR / INS / HLT / AOK', 'Stat → 处理器停止 / 执行状态控制', '错误替换为 nop 不会消除 ADR']),
 ], 'Stat 与 new_pc 是不同输出。halt/错误使执行停止，不能仅凭默认 new_pc=valP 推断还会执行下一条。'),
}


def build():
    out=Path(__file__).parent/'assets'
    for slug,(title,lanes,foot) in DIAGRAMS.items():
        heights=[max(3,len(inputs),len(outputs))*31+102 for _,inputs,_,outputs in lanes]
        height=130+sum(heights)+105
        parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1320" height="{height}" viewBox="0 0 1320 {height}" role="img" aria-labelledby="title desc">',f'<title id="title">{escape(title)}</title>', '<desc id="desc">蓝色实线为数据或字段输入，橙色虚线为控制。每行从左到右表示来源、功能单元和输出去向；重复信号名表示同一条线。</desc>', '''<defs><marker id="data" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10Z" fill="#2563a6"/></marker><marker id="ctl" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L10 5 L0 10Z" fill="#b45309"/></marker></defs>''', f'<rect width="1320" height="{height}" fill="#f8fafc"/>', '<style>text{font-family:"Noto Sans CJK SC","Microsoft YaHei",sans-serif;fill:#172c45;font-size:18px}.ctl{fill:#92400e;font-size:18px}.label{font-size:20px;font-weight:700}</style>']
        def text(x,y,s,cls=''):
            parts.append(f'<text x="{x}" y="{y}" class="{cls}">{escape(s)}</text>')
        def line(x1,y1,x2,y2,control=False):
            parts.append(f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{"#b45309" if control else "#2563a6"}" stroke-width="2" {chr(32)+"stroke-dasharray=\"7 5\"" if control else ""} marker-end="url(#{"ctl" if control else "data"})"/>')
        text(32,43,title,'label')
        text(32,77,'蓝实线 → 数据 / 字段     橙虚线 ⇢ 控制来源与条件     同名信号相连；六阶段在同一周期内传播')
        text(32,111,'输入来源（选择器每行是一种候选）')
        text(615,111,'功能单元')
        text(875,111,'输出与下游去向')
        y=130
        for (name,inputs,control,outputs),h in zip(lanes,heights):
            parts.append(f'<rect x="20" y="{y}" width="1280" height="{h-12}" rx="12" fill="white" stroke="#d9e2ec"/>')
            text(38,y+29,control,'ctl')
            line(38,y+43,710,y+43,True)
            line(710,y+43,710,y+60,True)
            n=max(3,len(inputs),len(outputs)); top=y+63; bh=n*31
            if 'MUX' in name:
                parts.append(f'<path d="M625 {top} L795 {top+14} L795 {top+bh-14} L625 {top+bh} Z" fill="#eaf2ff" stroke="#2563a6" stroke-width="2"/>')
            else:
                parts.append(f'<rect x="625" y="{top}" width="170" height="{bh}" rx="8" fill="#eaf2ff" stroke="#2563a6" stroke-width="2"/>')
            text(638,top+bh/2+6,name,'label')
            for i,s in enumerate(inputs):
                yy=top+23+i*31
                text(38,yy,s)
                line(594,yy-6,623,yy-6)
            mid=top+bh/2
            line(797,mid,855,mid)
            parts.append(f'<rect x="860" y="{top}" width="420" height="{bh}" rx="8" fill="#f0f7fb" stroke="#c4d9e9"/>')
            for i,s in enumerate(outputs):text(875,top+23+i*31,s)
            y+=h
        text(32,y+25,foot)
        text(32,y+61,'基础 Y86-64 / SEQ；正常执行的数据通路。停止、异常下的状态提交另由执行状态控制；iaddq 扩展见正文。')
        parts.append('</svg>')
        (out/f'seq-{slug}.svg').write_text('\n'.join(parts))

if __name__=='__main__': build()
