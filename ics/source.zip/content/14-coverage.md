# 附录 D · 课件覆盖索引与来源

这里保留全部现有课件的页码主题，包括附加材料。页题名由 PDF 文本抽取清理，少数无题页用内容起始行标识；它是回查索引，正文按知识主题合并重复例子。

## 覆盖情况

|来源|页数|对应章节|状态|
|---|---|---|---|
|ICS01-overview-20260907.pdf|50|01，相关补充见附录 C|已提取全部页面主题，按主题整理|
|ICS02-bits-bytes-ints-20260910.pdf|68|02，相关补充见附录 C|已提取全部页面主题，按主题整理|
|ICS03-float-20260914.pdf|48|03，相关补充见附录 C|已提取全部页面主题，按主题整理|
|ICS04-machine-basics-20260917.pdf|47|04，相关补充见附录 C|已提取全部页面主题，按主题整理|
|ICS05-machine-control-20260921.pdf|64|05，相关补充见附录 C|已提取全部页面主题，按主题整理|
|ICS06-machine-procedures-20260924.pdf|75|06，相关补充见附录 C|已提取全部页面主题，按主题整理|
|ICS07-machine-data-20260928.pdf|51|07，相关补充见附录 C|已提取全部页面主题，按主题整理|
|ICS08-machine-advanced-20261008.pdf|53|08|已逐页核对；补齐内存布局、越界、防护与 ROP|
|ICS09-Processor Arch-ISA&Logic-20261015.pdf|64|09、附录 C|完整指令编码、逻辑/HCL、存储元件与附加页|
|ICS10-Processor Arch-Sequential-20261019.pdf|51|10、附录 C|逐类六阶段、SEQ 选择器、时序与作业扩展|
|ICS11-Processor Arch-Pipelined-20261022.pdf|68|11、附录 C|五级字段、前递、三类冒险及组合控制、4.57(A)|
|ICS12-memory-hierarchy-20261026.pdf|70|12、附录 C|总线、存储器、磁盘/SSD、局部性、缓存基础|
|ICS13-cache-memories-20261029.pdf|65|13、附录 C|映射/读写、存储山、矩阵循环与分块|
|ICS14-optimization-20261102.pdf|69|14、附录 C|编译优化与障碍、CPE、依赖链、ILP/SIMD|
|ICS15-linking-20261105.pdf|65|15、附录 C|ELF、符号、重定位、静态／动态库、三类插桩|
|ICS16-ECF1-20261109.pdf|62|16、附录 C|异常、进程、上下文、fork/exit/wait/execve|
|ICS2026-测验1-v2.0-纯答案.pdf|5|附录 A|逐题答案回查；题干缺失处明确标注|

小班研讨题第 2～7、9～16 讲共 14 份、每份 2 页，已全文读取并归并到正文与附录 C；第 9～16 讲按研讨小问逐项给出回查路线。教材扫描版仅提取前部信息作为版次参考，正文公式基于课件、CS:APP 通用原理及官方资料核对；没有宣称逐页阅读整本扫描教材。

第 8 讲已按 2026-10-08 课件全部 53 页更新；教材补充与课件主题分开标注。本手册现整理第 1～16 讲；第一次测验复盘见附录 A，往年题导航见附录 B。第 9～16 讲不计入第一次测验原范围。

## 逐页主题清单

### ICS01-overview-20260907

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Course Overview 课程概述 · 1st Lecture, Sep 7, 2026 第一讲，2026年9月7日|01|
|2|主要内容 · ¢ 课程起源|01|
|3|课程起源 · ¢ 创立：|01|
|4|合作建设课程 · 课程特点：|01|
|5|小班教学的启动 · ¢ 2010-2011 学年，本科班级规模的初步统计|01|
|6|北京大学本科生“研讨型小班教学”试点 · ¢ 2012年秋开展第一批试点|01|
|7|主要内容 · ¢ 课程起源|01|
|8|本课程的教学方式 · ¢ 研讨型教学的两种主要方式|01|
|9|课程安排 · 周次 日期 大班课 主题 日期 小班课 日期 大班课 主题 LAB节点|01|
|10|大班课程安排 · ¢ 上半学期的主体内容|01|
|11|大班课程安排 · ¢ 下半学期的主体内容|01|
|12|课程特点： · 课时多，教学内容多|01|
|13|课程特点： · 大班教学和小班研讨结合|01|
|14|实验题系统 课程特点： · 学生在指定系统上完成实验题|01|
|15|主要内容 · ¢ 课程起源|01|
|16|本课程关注的问题和目标 · ¢ 本课程关注的问题：|01|
|17|本课程独特的视角 · ¢ 本课程是从编程者角度出发，描述计算机系统|01|
|18|问题1：整型不是整数，浮点型不是实数 · Ints are not Integers, Floats are not Reals|01|
|19|计算机系统中的算术 ≠ 数学中的算术(1/2) · ¢ 整数性质|01|
|20|计算机系统中的算术 ≠ 数学中的算术(2/2) · ¢ 有些性质在计算机系统中并不成立|01|
|21|问题2：了解汇编 (1/4) · You’ve Got to Know Assembly|01|
|22|问题2：了解汇编 (2/4) · You’ve Got to Know Assembly|01|
|23|问题2：了解汇编 (3/4) · You’ve Got to Know Assembly|01|
|24|问题2：了解汇编 (4/4) · You’ve Got to Know Assembly|01|
|25|问题3：内存对程序性能的影响至关重要 · Memory Matters Random Access Memory Is|01|
|26|内存引用错误 (1/3) · typedef struct {|01|
|27|内存引用错误 (2/3) · typedef struct { fun(0) à 3.14|01|
|28|内存引用错误 (3/3) · ¢ C 和 C++ 并没有提供对此类错误的防范机制，|01|
|29|问题4：算法性能分析结果 ≠ 实际程序性能 · There’s more to performance than asymptotic|01|
|30|内存性能影响程序性能 · void copyij (int src[2048][2048], void copyji (int src[2048][2048],|01|
|31|为什么性能有这些差别 · copyij|01|
|32|问题5：计算机网络环境下的新问题 · Computers do more than execute programs|01|
|33|问题5：计算机网络环境下的新问题 · Computers do more than execute programs|01|
|34|主要内容 · ¢ 课程起源|01|
|35|课程主体内容 · ① 程序与数据 Programs and Data|01|
|36|一、程序与数据 · Programs and Data (1/2)|01|
|37|一、程序与数据 · Programs and Data (2/2)|01|
|38|二、处理器体系结构 和 程序性能 · Processor Architecture & Performance|01|
|39|三、分级存储器体系 · The Memory Hierarchy|01|
|40|四、异常控制流 · Exceptional Control Flow|01|
|41|五、虚拟内存 · Virtual Memory|01|
|42|六、网络和并发 · Networking, and Concurrency|01|
|43|实验题（LAB） · L1 Datalab 位级数据操作实验|01|
|44|每个实验必须独立完成（不得由AI代做） · ¢ 每次LAB都有可能抽查代码重合度，对比对象包|01|
|45|主要内容 · ¢ 课程起源|01|
|46|课程主页 http://course.pku.edu.cn · 课程通知，课后作业等|01|
|47|课程教材 · ¢ Computer Systems: A Programmer's Perspective（3rd Edition）|01|
|48|成绩评定占比 · ¢ 期末考试：30分|01|
|49|需要注意的问题 · Q：为什么教学网的小班和安排的不一致？|01|
|50|页脚 / 结束页|01|

### ICS02-bits-bytes-ints-20260910

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Bits, Bytes, and Integers · 2nd Lecture, Sep 10, 2026|02|
|2|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|3|Binary Representations · ¢ Base 2 Number Representation|02|
|4|Encoding Byte Values · al y|02|
|5|Data Representations · C Data Type Typical 32-bit Intel IA32 x86-64|02|
|6|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|7|Boolean Algebra · ¢ Developed by George Boole in 19th Century|02|
|8|General Boolean Algebras · ¢ Operate on Bit Vectors|02|
|9|Example: Representing & Manipulating Sets · ¢ Representation|02|
|10|Bit-Level Operations in C · ¢ Operations &, /, ~, ^ Available in C|02|
|11|Contrast: Logic Operations in C · ¢ Contrast to Logical Operators|02|
|12|Shift Operations · ¢ Left Shift: x << y Argument x 01100010|02|
|13|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|14|Encoding Integers · Unsigned Two’s Complement|02|
|15|Two-complement: Simple Example · -16 8 4 2 1|02|
|16|Encoding Example (Cont.) · x = 15213: 00111011 01101101|02|
|17|Numeric Ranges · ¢ Unsigned Values|02|
|18|Values for Different Word Sizes · W|02|
|19|Unsigned & Signed Numeric Values · X B2U(X) B2T(X) ¢ Equivalence|02|
|20|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|21|Mapping Between Signed & Unsigned · Two’s Complement Unsigned|02|
|22|Mapping Signed « Unsigned · Bits Signed Unsigned|02|
|23|Mapping Signed « Unsigned · Bits Signed Unsigned|02|
|24|Relation between Signed & Unsigned · Two’s Complement Unsigned|02|
|25|Conversion Visualized · ¢ 2’s Comp. ® Unsigned|02|
|26|Signed vs. Unsigned in C · ¢ Constants|02|
|27|Casting Surprises · ¢ Expression Evaluation|02|
|28|Summary · Casting Signed ↔ Unsigned: Basic Rules|02|
|29|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|30|Sign Extension · ¢ Task:|02|
|31|Sign Extension: Simple Example · Positive number Negative number|02|
|32|Sign Extension Example · short int x = 15213;|02|
|33|Truncation: Simple Example · No sign change Sign change|02|
|34|Summary: · Expanding, Truncating: Basic Rules|02|
|35|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|36|Unsigned Addition · Operands: w bits u •••|02|
|37|Unsigned Addition · Operands: w bits u •••|02|
|38|Visualizing (Mathematical) Integer Addition · ¢ Integer Addition Add4(u , v)|02|
|39|Visualizing Unsigned Addition · ¢ Wraps Around Overflow|02|
|40|Two’s Complement Addition · Operands: w bits u •••|02|
|41|TAdd Overflow · ¢ Functionality True Sum|02|
|42|Visualizing 2’s Complement Addition · NegOver|02|
|43|Characterizing TAdd · Positive Overflow|02|
|44|Multiplication · ¢ Goal: Computing Product of w-bit numbers x, y|02|
|45|Unsigned Multiplication in C · u •••|02|
|46|Signed Multiplication in C · u •••|02|
|47|Power-of-2 Multiply with Shift · ¢ Operation|02|
|48|Unsigned Power-of-2 Divide with Shift · ¢ Quotient of Unsigned by Power of 2|02|
|49|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|50|Arithmetic: Basic Rules · ¢ Addition:|02|
|51|Why Should I Use Unsigned? · ¢ Don’t use without understanding implications|02|
|52|Counting Down with Unsigned · ¢ Proper way to use unsigned as loop index|02|
|53|Why Should I Use Unsigned? (cont.) · ¢ Do Use When Performing Modular Arithmetic|02|
|54|Today: Bits, Bytes, and Integers · ¢ Representing information as bits|02|
|55|Byte-Oriented Memory Organization · •0 •F|02|
|56|Machine Words · ¢ Any given computer has a “Word Size”|02|
|57|Word-Oriented Memory Organization · 32-bit 64-bit|02|
|58|Example Data Representations · C Data Type Typical 32-bit Typical 64-bit x86-64|02|
|59|Byte Ordering · ¢ So, how are the bytes within a multi-byte word ordered in|02|
|60|Byte Ordering Example · ¢ Example|02|
|61|Decimal: 15213 · Representing Integers Binary: 0011 1011 0110 1101|02|
|62|Examining Data Representations · ¢ Code to Print Byte Representation of Data|02|
|63|show_bytes Execution Example · int a = 15213;|02|
|64|Representing Pointers · int B = -15213;|02|
|65|Representing Strings · char S[6] = "18213";|02|
|66|Reading Byte-Reversed Listings · ¢ Disassembly|02|
|67|Summary · ¢ Representing information as bits|02|
|68|Integer C Puzzles · x < 0 Þ ((x*2) < 0)|02|

### ICS03-float-20260914

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Floating Point · 3rd Lecture, Sep. 14, 2026|03|
|2|Today: Floating Point · ¢ Background: Fractional binary numbers|03|
|3|Fractional binary numbers · ¢ What is 1011.1012?|03|
|4|Fractional Binary Numbers · 2i|03|
|5|Fractional Binary Numbers: Examples · ¢ Value Representation|03|
|6|Representable Numbers · ¢ Limitation #1|03|
|7|Today: Floating Point · ¢ Background: Fractional binary numbers|03|
|8|IEEE Floating Point · ¢ IEEE Standard 754|03|
|9|This is important! · ¢ Ariane 5 explodes on maiden voyage: $500 MILLION dollars lost|03|
|10|(Binary) Scientific Notation · ¢ What are the parts of a number in scientific notation?|03|
|11|Floating Point Representation · Example:|03|
|12|Precision options · ¢ Single precision: 32 bits|03|
|13|Three “kinds” of floating point numbers · s exp frac|03|
|14|“Normalized” Values v = (–1)s M 2E · ¢ When: exp ≠ 000…0 and exp ≠ 111…1|03|
|15|Normalized Encoding Example v = (–1)s M 2E · E = Exp – Bias|03|
|16|Denormalized Values v = (–1)s M 2E · E = 1 – Bias|03|
|17|Special Values · ¢ Condition: exp = 111…1|03|
|18|C float Decoding Example v = (–1)s M 2E · E = exp – Bias|03|
|19|C float Decoding Example #1 v = (–1)s M 2E · E = exp – Bias|03|
|20|C float Decoding Example #1 v = (–1)s M 2E · E = exp – Bias|03|
|21|C float Decoding Example #2 v = (–1)s M 2E · E = 1 – Bias|03|
|22|C float Decoding Example #2 v = (–1)s M 2E · E = 1 – Bias|03|
|23|Visualization: Floating Point Encodings · −¥ +¥|03|
|24|Today: Floating Point · ¢ Background: Fractional binary numbers|03|
|25|Tiny Floating Point Example · s exp frac|03|
|26|v = (–1)s M 2E · Dynamic Range (s=0 only) norm: E = exp – Bias|03|
|27|Distribution of Values · ¢ 6-bit IEEE-like format|03|
|28|Distribution of Values (close-up view) · ¢ 6-bit IEEE-like format|03|
|29|Special Properties of the IEEE Encoding · ¢ FP Zero Same as Integer Zero|03|
|30|Today: Floating Point · ¢ Background: Fractional binary numbers|03|
|31|Floating Point Operations: Basic Idea · ¢ x +f y = Round(x + y)|03|
|32|Rounding · ¢ Rounding Modes (illustrate with $ rounding)|03|
|33|Closer Look at Round-To-Even · ¢ Default Rounding Mode|03|
|34|Rounding Binary Numbers · ¢ Binary Fractional Numbers|03|
|35|FP Multiplication · ¢ (–1)s1 M1 2E1 x (–1)s2 M2 2E2|03|
|36|Floating Point Addition · ¢ (–1)s1 M1 2E1 + (-1)s2 M2 2E2|03|
|37|Mathematical Properties of FP Add · ¢ Compare to those of Abelian Group|03|
|38|Mathematical Properties of FP Mult · ¢ Compare to Commutative Ring|03|
|39|Today: Floating Point · ¢ Background: Fractional binary numbers|03|
|40|Floating Point in C · ¢ C Guarantees Two Levels|03|
|41|Floating Point Puzzles · ¢ For each of the following C expressions, either:|03|
|42|Summary · ¢ IEEE Floating Point has clear mathematical properties|03|
|43|Additional Slides|03|
|44|Creating Floating Point Number · ¢ Steps s exp frac|03|
|45|Normalize s exp frac · 1 4-bits 3-bits|03|
|46|Rounding 1.BBGRXXX · Guard bit: LSB of result|03|
|47|Postnormalize · ¢ Issue|03|
|48|Interesting Numbers {single,double} · Description exp frac Numeric Value|03|

### ICS04-machine-basics-20260917

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Machine-Level Programming I: Basics · 4th Lecture, Sep. 17, 2026|04|
|2|Today: Machine Programming I: Basics · ¢ History of Intel processors and architectures|04|
|3|Intel x86 Processors · ¢ Dominate laptop/desktop/server market|04|
|4|Intel x86 Evolution: Milestones · Name Date Transistors MHz|04|
|5|Intel x86 Processors, cont. · ¢ Machine Evolution|04|
|6|Intel x86 Processors, cont. · ¢ Past Generations Process technology|04|
|7|2018 State of the Art: Coffee Lake · ¢ Mobile Model: Core i7 ¢ Server Model: Xeon E|04|
|8|x86 Clones: Advanced Micro Devices (AMD) · ¢ Historically|04|
|9|Intel’s 64-Bit History · ¢ 2001: Intel Attempts Radical Shift from IA32 to IA64|04|
|10|Our Coverage · ¢ IA32|04|
|11|Today: Machine Programming I: Basics · ¢ History of Intel processors and architectures|04|
|12|Definitions · ¢ Architecture: (also ISA: instruction set architecture) The|04|
|13|Assembly/Machine Code View · CPU Memory|04|
|14|Turning C into Object Code · § Code in files p1.c p2.c|04|
|15|Compiling Into Assembly · C Code (sum.c) Generated x86-64 Assembly|04|
|16|What it really looks like · .globl sumstore|04|
|17|What it really looks like · .globl sumstore|04|
|18|Assembly Characteristics: Data Types · ¢ “Integer” data of 1, 2, 4, or 8 bytes|04|
|19|Assembly Characteristics: Operations · ¢ Transfer data between memory and register|04|
|20|Object Code · Code for sumstore|04|
|21|Machine Instruction Example · ¢ C Code|04|
|22|Disassembling Object Code · Disassembled|04|
|23|Alternate Disassembly · Disassembled|04|
|24|What Can be Disassembled? · % objdump -d WINWORD.EXE|04|
|25|Today: Machine Programming I: Basics · ¢ History of Intel processors and architectures|04|
|26|x86-64 Integer Registers · %rax %eax %r8 %r8d|04|
|27|Some History: IA32 Registers Origin · (mostly obsolete)|04|
|28|Moving Data %rax · ¢ Moving Data %rcx|04|
|29|movq Operand Combinations · Source Dest Src,Dest C Analog|04|
|30|Simple Memory Addressing Modes · ¢ Normal (R) Mem[Reg[R]]|04|
|31|Example of Simple Addressing Modes · void swap|04|
|32|Understanding Swap() · Memory|04|
|33|Understanding Swap() · Memory|04|
|34|Understanding Swap() · Memory|04|
|35|Understanding Swap() · Memory|04|
|36|Understanding Swap() · Memory|04|
|37|Understanding Swap() · Memory|04|
|38|Simple Memory Addressing Modes · ¢ Normal (R) Mem[Reg[R]]|04|
|39|Complete Memory Addressing Modes · ¢ Most General Form|04|
|40|Address Computation Examples · %rdx 0xf000|04|
|41|Today: Machine Programming I: Basics · ¢ History of Intel processors and architectures|04|
|42|Address Computation Instruction · ¢ leaq Src, Dst|04|
|43|Some Arithmetic Operations · ¢ Two Operand Instructions:|04|
|44|Some Arithmetic Operations · ¢ One Operand Instructions|04|
|45|Arithmetic Expression Example · arith:|04|
|46|Understanding Arithmetic Expression · Example arith:|04|
|47|Machine Programming I: Summary · ¢ History of Intel processors and architectures|04|

### ICS05-machine-control-20260921

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Machine-Level Programming II: Control · 5th Lecture, Sep. 21, 2026|05|
|2|Recall: ISA = Assembly/Machine Code View · CPU Memory|05|
|3|Recall: Turning C into Object Code · § Code in files p1.c p2.c|05|
|4|Recall: Move & Arithmetic Operations · ¢ Some Two Operand Instructions:|05|
|5|Recall: Addressing Modes · ¢ Most General Form|05|
|6|Memory operands and LEA · ¢ In most instructions, a memory operand accesses memory|05|
|7|Why use LEA? · ¢ CPU designers’ intended use: calculate a pointer to an object|05|
|8|Sidebar: instruction suffixes · ¢ Most x86 instructions can be written with or without a|05|
|9|Today · ¢ Control: Condition codes|05|
|10|Control flow · extern void op1(void);|05|
|11|Control flow in assembly language · extern void op1(void); decision:|05|
|12|Control flow in assembly language · extern void op1(void); decision:|05|
|13|Processor State (x86-64, Partial) · ¢ Information about|05|
|14|Condition Codes (Implicit Setting) · ¢ Single bit registers|05|
|15|ZF set when · 000000000000…00000000000|05|
|16|SF set when · yxxxxxxxxxxxx...|05|
|17|CF set when · 1xxxxxxxxxxxx...|05|
|18|OF set when · yxxxxxxxxxxxx... a|05|
|19|Condition Codes (Explicit Setting: Compare) · ¢ Explicit Setting by Compare Instruction|05|
|20|Condition Codes (Explicit Setting: Test) · ¢ Explicit Setting by Test instruction|05|
|21|Reading Condition Codes · ¢ SetX Instructions|05|
|22|Example: setl (Signed <) · ¢ Condition: SF^OF|05|
|23|x86-64 Integer Registers · %rax %al %r8 %r8b|05|
|24|Reading Condition Codes (Cont.) · ¢ SetX Instructions:|05|
|25|Explicit Reading Condition Codes (Cont.) · SetX Instructions:|05|
|26|Today · ¢ Control: Condition codes|05|
|27|Jumping · ¢ jX Instructions|05|
|28|Conditional Branch Example (Old Style) · ¢ Generation Get to this shortly|05|
|29|Expressing with Goto Code · ¢ C allows goto statement|05|
|30|General Conditional Expression · Translation (Using Branches)|05|
|31|Using Conditional Moves · ¢ Conditional Move Instructions|05|
|32|Conditional Move Example · long absdiff|05|
|33|Bad Cases for Conditional Move · Expensive Computations|05|
|34|Exercise · SetX Condition Description|05|
|35|Exercise · SetX Condition Description|05|
|36|Today · ¢ Control: Condition codes|05|
|37|“Do-While” Loop Example · C Code Goto Version|05|
|38|General “Do-While” Translation · C Code Goto Version|05|
|39|“Do-While” Loop Compilation · Goto Version|05|
|40|General “While” Translation #1 · ¢ “Jump-to-middle” translation|05|
|41|While Loop Example #1 · C Code Jump to Middle|05|
|42|General “While” Translation #2 · While version|05|
|43|While Loop Example #2 · C Code Do-While Version|05|
|44|“For” Loop Form Init · General Form i = 0|05|
|45|“For” Loop à While Loop · For Version|05|
|46|For-While Conversion · long pcount_for_while|05|
|47|“For” Loop Do-While Conversion · Goto Version|05|
|48|Today · ¢ Control: Condition codes|05|
|49|long switch_eg · (long x, long y, long z) Switch Statement|05|
|50|Jump Table Structure · Switch Form Jump Table Jump Targets|05|
|51|Switch Statement Example · long switch_eg(long x, long y, long z)|05|
|52|Switch Statement Example · long switch_eg(long x, long y, long z)|05|
|53|Assembly Setup Explanation · ¢ Table Structure Jump table|05|
|54|Jump Table · Jump table|05|
|55|Code Blocks (x == 1) · switch(x) { .L3:|05|
|56|Handling Fall-Through · long w = 1;|05|
|57|Code Blocks (x == 2, x == 3) · .L5: # Case 2|05|
|58|Code Blocks (x == 5, x == 6, default) · switch(x) { .L7: # Case 5,6|05|
|59|Summarizing · ¢ C Control|05|
|60|Summary · ¢ Today|05|
|61|Additional Slides|05|
|62|Finding Jump Table in Binary · 00000000004005e0 <switch_eg>:|05|
|63|Finding Jump Table in Binary (cont.) · 00000000004005e0 <switch_eg>:|05|
|64|Finding Jump Table in Binary (cont.) · % gdb switch|05|

### ICS06-machine-procedures-20260924

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Machine-Level Programming III: · Procedures|06|
|2|Objectives · ¢ Basic functionality of the pairs: push / pop and call / ret|06|
|3|Today · ¢ Procedures|06|
|4|Mechanisms in Procedures · P(…) {|06|
|5|Mechanisms in Procedures · P(…) {|06|
|6|Mechanisms in Procedures · P(…) {|06|
|7|Mechanisms in Procedures · P(…) {|06|
|8|Mechanisms in Procedures · P(…) {|06|
|9|Today · ¢ Procedures|06|
|10|x86-64 Stack · ¢ Region of memory managed|06|
|11|x86-64 Stack · ¢ Region of memory Stack “Bottom”|06|
|12|x86-64 Stack · ¢ Region of memory managed|06|
|13|x86-64 Stack: Push · ¢ pushq Src|06|
|14|x86-64 Stack: Push · ¢ pushq Src|06|
|15|x86-64 Stack: Pop · ¢ popq Dest Stack “Bottom”|06|
|16|x86-64 Stack: Pop · ¢ popq Dest Stack “Bottom”|06|
|17|x86-64 Stack: Pop · ¢ popq Dest Stack “Bottom”|06|
|18|Today · ¢ Procedures|06|
|19|void multstore · (long x, long y, long *dest) Code Examples|06|
|20|Procedure Control Flow · ¢ Use stack to support procedure call and return|06|
|21|Control Flow Example #1 • · 0000000000400540 <multstore>:|06|
|22|Control Flow Example #2 • · 0000000000400540 <multstore>:|06|
|23|Control Flow Example #3 • · 0000000000400540 <multstore>:|06|
|24|Control Flow Example #4 • · 0000000000400540 <multstore>:|06|
|25|Today · ¢ Procedures|06|
|26|Procedure Data Flow · Registers Stack|06|
|27|void multstore · Data Flow (long x, long y, long *dest)|06|
|28|Today · ¢ Procedures|06|
|29|Stack-Based Languages · ¢ Languages that support recursion|06|
|30|Call Chain Example · Example|06|
|31|Stack Frames Previous · Frame|06|
|32|Stack · Example|06|
|33|Stack · Example|06|
|34|Stack · Example|06|
|35|Stack · Example|06|
|36|Stack · Example|06|
|37|Stack · Example|06|
|38|Stack · Example|06|
|39|Stack · Example|06|
|40|Stack · Example|06|
|41|Stack · Example|06|
|42|Stack · Example|06|
|43|x86-64/Linux Stack Frame · ¢ Current Stack Frame (“Top” to|06|
|44|Example: incr · long incr(long *p, long val) {|06|
|45|Example: Calling incr #1 · Initial Stack Structure|06|
|46|Example: Calling incr #2 · Stack Structure|06|
|47|Example: Calling incr #2 · Stack Structure|06|
|48|Example: Calling incr #2 · Stack Structure|06|
|49|Example: Calling incr #3a Stack Structure · long call_incr() {|06|
|50|Example: Calling incr #3b Stack Structure · long call_incr() {|06|
|51|Example: Calling incr #4 Stack Structure · long call_incr() {|06|
|52|Example: Calling incr #5a Stack Structure · long call_incr() {|06|
|53|Example: Calling incr #5b · long call_incr() { Updated Stack Structure|06|
|54|Register Saving Conventions · ¢ When procedure yoo calls who:|06|
|55|Register Saving Conventions · ¢ When procedure yoo calls who:|06|
|56|x86-64 Linux Register Usage #1 · ¢ %rax Return value %rax|06|
|57|x86-64 Linux Register Usage #2 · ¢ %rbx, %r12, %r13, %r14 %rbx|06|
|58|Callee-Saved Example #1 · Initial Stack Structure|06|
|59|Callee-Saved Example #2 · Initial Stack Structure|06|
|60|Callee-Saved Example #3 · Initial Stack Structure|06|
|61|Callee-Saved Example #4 Stack Structure · long call_incr2(long x) {|06|
|62|Callee-Saved Example #5 Stack Structure · long call_incr2(long x) {|06|
|63|Callee-Saved Example #6 Stack Structure · long call_incr2(long x) {|06|
|64|Callee-Saved Example #7 Stack Structure · long call_incr2(long x) {|06|
|65|Callee-Saved Example #8 Initial Stack Structure · long call_incr2(long x) {|06|
|66|Today · ¢ Procedures|06|
|67|Recursive Function pcount_r: · movl $0, %eax|06|
|68|Recursive Function Terminal Case · /* Recursive popcount */ pcount_r:|06|
|69|Recursive Function Register Save · pcount_r:|06|
|70|Recursive Function Call Setup · /* Recursive popcount */ pcount_r:|06|
|71|Recursive Function Call · /* Recursive popcount */ pcount_r:|06|
|72|Recursive Function Result · /* Recursive popcount */ pcount_r:|06|
|73|Recursive Function Completion · pcount_r:|06|
|74|Observations About Recursion · ¢ Handled Without Special Consideration|06|
|75|x86-64 Procedure Summary · ¢ Important Points|06|

### ICS07-machine-data-20260928

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Machine-Level Programming IV: · Data|07|
|2|Today · ¢ Arrays|07|
|3|Array Allocation · ¢ Basic Principle|07|
|4|Array Access · ¢ Basic Principle|07|
|5|Array Access · ¢ Basic Principle|07|
|6|Array Access · ¢ Basic Principle|07|
|7|Array Example · #define ZLEN 5|07|
|8|Array Accessing Example · zip_dig cmu; 1 5 2 1 3|07|
|9|Array Loop Example · void zincr(zip_dig z) {|07|
|10|Multidimensional (Nested) Arrays · ¢ Declaration A[0][0] • • • A[0][C-1]|07|
|11|Nested Array Example · #define PCOUNT 4|07|
|12|Nested Array Row Access · ¢ Row Vectors|07|
|13|Nested Array Row Access Code · 1 5 2 0 6 1 5 2 1 3 1 5 2 1 7 1 5 2 2 1|07|
|14|Nested Array Element Access · ¢ Array Elements|07|
|15|Nested Array Element Access Code · 1 5 2 0 6 1 5 2 1 3 1 5 2 1 7 1 5 2 2 1|07|
|16|Multi-Level Array Example · zip_dig cmu = { 1, 5, 2, 1, 3 }; ¢ Variable univ denotes|07|
|17|Element Access in Multi-Level Array · int get_univ_digit|07|
|18|Array Element Accesses · Nested array Multi-level array|07|
|19|N X N Matrix #define N 16 · typedef int fix_matrix[N][N];|07|
|20|16 X 16 Matrix Access · ¢ Array Elements|07|
|21|n X n Matrix Access · ¢ Array Elements|07|
|22|Example: Array Access · #include <stdio.h>|07|
|23|Example: Array Access · #include <stdio.h>|07|
|24|Today · ¢ Arrays|07|
|25|Structure Representation · r|07|
|26|Generating Pointer to Structure Member · r r+4*idx|07|
|27|struct rec { · Following Linked List int a[4];|07|
|28|Structures & Alignment · ¢ Unaligned Data struct S1 {|07|
|29|Alignment Principles · ¢ Aligned Data|07|
|30|Specific Cases of Alignment (x86-64) · ¢ 1 byte: char, …|07|
|31|Satisfying Alignment with Structures · ¢ Within structure: struct S1 {|07|
|32|Meeting Overall Alignment Requirement · ¢ For largest alignment requirement K struct S2 {|07|
|33|Arrays of Structures · struct S2 {|07|
|34|Accessing Array Elements struct S3 { · short i;|07|
|35|Saving Space · ¢ Put large data types first|07|
|36|Today · ¢ Arrays|07|
|37|Background · ¢ History|07|
|38|Programming with SSE3 · XMM Registers|07|
|39|Scalar & SIMD Operations · n Scalar Operations: Single Precision addss %xmm0,%xmm1|07|
|40|FP Basics · ¢ Arguments passed in %xmm0, %xmm1, ...|07|
|41|FP Memory Referencing · ¢ Integer (and pointer) arguments passed in regular registers|07|
|42|Other Aspects of FP Code · ¢ Lots of instructions|07|
|43|Summary · ¢ Arrays|07|
|44|Additional Slides|07|
|45|Understanding Pointers & Arrays #1 · Decl An *An|07|
|46|Understanding Pointers & Arrays #1 · Decl An *An|07|
|47|Understanding Pointers & Arrays #2 · Decl An *An **An|07|
|48|Understanding Pointers & Arrays #2 · Decl An *An **An|07|
|49|Understanding Pointers & Arrays #3 · Decl An *An **An|07|
|50|Allocated pointer Declaration · Allocated pointer to unallocated int|07|
|51|Understanding Pointers & Arrays #3 · Decl An *An **An|07|

### ICS08-machine-advanced-20261008

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|课程封面与日期|[08](08-advanced.html)|
|2|本讲提纲|[08](08-advanced.html)|
|3|union 与 struct 的分配对照|[08](08-advanced.html)|
|4|union 位重解释与数值强转|[08](08-advanced.html)|
|5|大端、小端与可配置端序|[08](08-advanced.html)|
|6|不同数据模型下 union 字段宽度|[08](08-advanced.html)|
|7|依次写入 f0～f7 的例程|[08](08-advanced.html)|
|8|IA32 小端输出|[08](08-advanced.html)|
|9|Sun 大端输出|[08](08-advanced.html)|
|10|x86-64 小端输出|[08](08-advanced.html)|
|11|数组、结构体与联合总结|[08](08-advanced.html)|
|12|提纲：内存布局|[08](08-advanced.html)|
|13|Linux x86-64 地址空间|[08](08-advanced.html)|
|14|全局数组、局部变量与 malloc 例子|[08](08-advanced.html)|
|15|示例实际地址与大块映射|[08](08-advanced.html)|
|16|递归耗尽栈空间|[08](08-advanced.html)|
|17|提纲：缓冲区溢出|[08](08-advanced.html)|
|18|越界 int 写覆盖 double|[08](08-advanced.html)|
|19|不同布局下的越界结果|[08](08-advanced.html)|
|20|缓冲区溢出的危害|[08](08-advanced.html)|
|21|gets 及不受限字符串函数|[08](08-advanced.html)|
|22|小缓冲区 echo 示例|[08](08-advanced.html)|
|23|echo 与调用者反汇编|[08](08-advanced.html)|
|24|buf、填充与返回地址布局|[08](08-advanced.html)|
|25|返回地址 0x4006f6 与小端字节|[08](08-advanced.html)|
|26|23 字符：越界但未覆盖返回地址|[08](08-advanced.html)|
|27|24 字符：结尾 NUL 破坏返回地址|[08](08-advanced.html)|
|28|覆盖返回地址改变控制流|[08](08-advanced.html)|
|29|课堂示例的输入布局|[08](08-advanced.html)|
|30|覆盖后的控制流|[08](08-advanced.html)|
|31|十六进制表示与实际输入字节|[08](08-advanced.html)|
|32|缓冲区中代码注入|[08](08-advanced.html)|
|33|RIP 与 RSP 的执行轨迹|[08](08-advanced.html)|
|34|缓冲区漏洞历史案例概览|[08](08-advanced.html)|
|35|1988 年 Internet worm|[08](08-advanced.html)|
|36|1999 年即时通信互通背景|[08](08-advanced.html)|
|37|IM War 与客户端特征检测|[08](08-advanced.html)|
|38|历史邮件与来源说明|[08](08-advanced.html)|
|39|worm 与 virus 区别|[08](08-advanced.html)|
|40|三类防护总览|[08](08-advanced.html)|
|41|限制输入长度及库函数选择|[08](08-advanced.html)|
|42|栈地址随机化|[08](08-advanced.html)|
|43|不可执行数据页|[08](08-advanced.html)|
|44|栈金丝雀与编译选项|[08](08-advanced.html)|
|45|金丝雀保护版本反汇编|[08](08-advanced.html)|
|46|设置金丝雀|[08](08-advanced.html)|
|47|校验金丝雀|[08](08-advanced.html)|
|48|ROP 与 gadget|[08](08-advanced.html)|
|49|函数尾部的 gadget|[08](08-advanced.html)|
|50|变长指令中间的 gadget|[08](08-advanced.html)|
|51|ret 串接代码片段|[08](08-advanced.html)|
|52|两段 gadget 的组合效果|[08](08-advanced.html)|
|53|最后一次 ret 与后续控制流|[08](08-advanced.html)|

## 可核对的外部来源

- [指定 GitHub 仓库](https://github.com/zhuozhiyongde/Introduction-to-Computer-System-2023Fall-PKU)：公开试卷、2024 勘误、复习细节。作者也提醒笔记可能有错误，本手册已单列纠正。
- [CS:APP 第 3 版官方勘误](https://csapp.cs.cmu.edu/3e/errata.html)：用于核对移位、扩展等细节；可继续到其中文版勘误链接。
- [Intel 官方手册](https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html)：指令的最终机器语义参考。
- [System V AMD64 ABI 项目](https://gitlab.com/x86-psABIs/x86-64-ABI)：Linux x86-64 调用与类型布局参考。
- [Microsoft x64 ABI](https://learn.microsoft.com/en-us/cpp/build/x64-calling-convention?view=msvc-170)：Windows 对比。

## 使用与维护

知识点使用原创表述与重新推导的例子；历史题给出处、题号、页码与解法导向；本地 2026 测验另整理已提供的答案与可核验推导。网站没有发布扫描教材和课堂 PDF。更新时优先补新的课件，再更新正文和此清单；考试政策以教师最新通知为准。

## 已知限制

1. 当前考试最终通知仍以教师发布为准；第 1～16 讲课件已齐，第一次测验原范围仍为第 1～8 讲。
2. 2014 旧卷存在 OCR 乱码，精确作答应看原始 PDF。
3. 早年卷仅完成题型浏览，没有对所有标准答案做独立验算。
4. 部分开放调研（如最新 CPU 产品排行）不属于稳定知识，这里解释比较方法而不编造当前市场表。
5. 课堂口头补充不在本地文件中，未纳入“已覆盖”的承诺。

### ICS09-Processor Arch-ISA&Logic-20261015

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Processor Architecture I: · ISA & Logic Design|[第 09 章](09-isa-logic.html)|
|2|Part A · Instruction Set Architecture|[第 09 章](09-isa-logic.html)|
|3|Instruction Set Architecture · n Assembly Language View|[第 09 章](09-isa-logic.html)|
|4|Y86-64 Processor State · RF: Program CC:|[第 09 章](09-isa-logic.html)|
|5|Y86-64 Instruction Set #1 · Byte 0 1 2 3 4 5 6 7 8 9|[第 09 章](09-isa-logic.html)|
|6|Y86-64 Instructions · n Format|[第 09 章](09-isa-logic.html)|
|7|Y86-64 Instruction Set #2 rrmovq 2 0 · Byte 0 1 2 3 4 5 6 7 8 9|[第 09 章](09-isa-logic.html)|
|8|Y86-64 Instruction Set #3 · Byte 0 1 2 3 4 5 6 7 8 9|[第 09 章](09-isa-logic.html)|
|9|Y86-64 Instruction Set #4 · Byte 0 1 2 3 4 5 6 7 8|[第 09 章](09-isa-logic.html)|
|10|Encoding Registers · n Each register has 4-bit ID|[第 09 章](09-isa-logic.html)|
|11|Instruction Example · n Addition Instruction|[第 09 章](09-isa-logic.html)|
|12|Arithmetic and Logical Operations · Instruction Code Function Code|[第 09 章](09-isa-logic.html)|
|13|Move Operations · Register è Register|[第 09 章](09-isa-logic.html)|
|14|Move Instruction Examples · X86-64 Y86-64|[第 09 章](09-isa-logic.html)|
|15|Conditional Move Instructions · Move Unconditionally|[第 09 章](09-isa-logic.html)|
|16|Jump Instructions · Jump (Conditionally)|[第 09 章](09-isa-logic.html)|
|17|Jump Instructions · Jump Unconditionally|[第 09 章](09-isa-logic.html)|
|18|Y86-64 Program Stack · Stack|[第 09 章](09-isa-logic.html)|
|19|Stack Operations · pushq rA A 0 rA F|[第 09 章](09-isa-logic.html)|
|20|Subroutine Call and Return · call Dest 8 0 Dest|[第 09 章](09-isa-logic.html)|
|21|Miscellaneous Instructions · nop 1 0|[第 09 章](09-isa-logic.html)|
|22|Status Conditions · Mnemonic Code n Normal operation|[第 09 章](09-isa-logic.html)|
|23|Writing Y86-64 Code · n Try to Use C Compiler as Much as Possible|[第 09 章](09-isa-logic.html)|
|24|Y86-64 Code Generation Example · nFirst Try nProblem|[第 09 章](09-isa-logic.html)|
|25|Y86-64 Code Generation Example #2 · nSecond Try nResult|[第 09 章](09-isa-logic.html)|
|26|Y86-64 Code Generation Example #3 · len:|[第 09 章](09-isa-logic.html)|
|27|Y86-64 Sample Program Structure #1 · init: # Initialization|[第 09 章](09-isa-logic.html)|
|28|Y86-64 Program Structure #2 · init:|[第 09 章](09-isa-logic.html)|
|29|Y86-64 Program Structure #3 · Main:|[第 09 章](09-isa-logic.html)|
|30|Assembling Y86-64 Program · unix> yas len.ys|[第 09 章](09-isa-logic.html)|
|31|Simulating Y86-64 Program · unix> yis len.yo|[第 09 章](09-isa-logic.html)|
|32|CISC Instruction Sets · n Complex Instruction Set Computer|[第 09 章](09-isa-logic.html)|
|33|RISC Instruction Sets · n Reduced Instruction Set Computer|[第 09 章](09-isa-logic.html)|
|34|MIPS Registers · `$0` 为常量零寄存器；`$16/$s0` 为保存寄存器|[第 09 章](09-isa-logic.html)|
|35|MIPS Instruction Examples · R-R|[第 09 章](09-isa-logic.html)|
|36|CISC vs. RISC · n Original Debate|[第 09 章](09-isa-logic.html)|
|37|Summary · n Y86-64 Instruction Set Architecture|[第 09 章](09-isa-logic.html)|
|38|Part B · Logic Design|[第 09 章](09-isa-logic.html)|
|39|Overview of Logic Design · n Fundamental Hardware Requirements|[第 09 章](09-isa-logic.html)|
|40|Digital Signals · 0 1 0|[第 09 章](09-isa-logic.html)|
|41|Computing with Logic Gates · And Or Not|[第 09 章](09-isa-logic.html)|
|42|Combinational Circuits · Acyclic Network|[第 09 章](09-isa-logic.html)|
|43|Bit Equality · Bit equal|[第 09 章](09-isa-logic.html)|
|44|Word Equality · Word-Level Representation|[第 09 章](09-isa-logic.html)|
|45|Bit-Level Multiplexor · s Bit MUX|[第 09 章](09-isa-logic.html)|
|46|Word Multiplexor Word-Level Representation · s|[第 09 章](09-isa-logic.html)|
|47|HCL Word-Level Examples · Minimum of 3 Words|[第 09 章](09-isa-logic.html)|
|48|Arithmetic Logic Unit · 0 1 2 3|[第 09 章](09-isa-logic.html)|
|49|Registers · Structure|[第 09 章](09-isa-logic.html)|
|50|Register Operation · State = x State = y|[第 09 章](09-isa-logic.html)|
|51|State Machine Example · Comb. Logic|[第 09 章](09-isa-logic.html)|
|52|Random-Access Memory · valA|[第 09 章](09-isa-logic.html)|
|53|Register File Timing · valA|[第 09 章](09-isa-logic.html)|
|54|Hardware Control Language · n Very simple hardware description language|[第 09 章](09-isa-logic.html)|
|55|HCL Operations · n Classify by type of value returned|[第 09 章](09-isa-logic.html)|
|56|Summary · n Computation|[第 09 章](09-isa-logic.html)|
|57|Additional Slides|[第 09 章](09-isa-logic.html)|
|58|Storing 1 Bit · Bistable Element|[第 09 章](09-isa-logic.html)|
|59|Storing 1 Bit (cont.) · Bistable Element|[第 09 章](09-isa-logic.html)|
|60|Physical Analogy Stable 1 · 1|[第 09 章](09-isa-logic.html)|
|61|Storing and Accessing 1 Bit · Bistable Element|[第 09 章](09-isa-logic.html)|
|62|1-Bit Latch · D Latch|[第 09 章](09-isa-logic.html)|
|63|Transparent 1-Bit Latch · Latching Changing D|[第 09 章](09-isa-logic.html)|
|64|Edge-Triggered Latch · D|[第 09 章](09-isa-logic.html)|


### ICS10-Processor Arch-Sequential-20261019

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Processor Architecture II: · SEQ: Sequential Implementation|[第 10 章](10-sequential.html)|
|2|Y86-64 Instruction Set #1 · Byte 0 1 2 3 4 5 6 7 8 9|[第 10 章](10-sequential.html)|
|3|Y86-64 Instruction Set #2 rrmovq 2 0 · Byte 0 1 2 3 4 5 6 7 8 9|[第 10 章](10-sequential.html)|
|4|Y86-64 Instruction Set #3 · Byte 0 1 2 3 4 5 6 7 8 9|[第 10 章](10-sequential.html)|
|5|Y86-64 Instruction Set #4 · Byte 0 1 2 3 4 5 6 7 8|[第 10 章](10-sequential.html)|
|6|Building Blocks fun · n Combinational Logic A|[第 10 章](10-sequential.html)|
|7|Hardware Control Language · n Very simple hardware description language|[第 10 章](10-sequential.html)|
|8|HCL Operations · n Classify by type of value returned|[第 10 章](10-sequential.html)|
|9|newPC · SEQ Hardware PC|[第 10 章](10-sequential.html)|
|10|newPC · PC|[第 10 章](10-sequential.html)|
|11|Instruction Decoding · Optional Optional|[第 10 章](10-sequential.html)|
|12|Executing Arith./Logical Operation · OPq rA, rB 6 fn rA rB|[第 10 章](10-sequential.html)|
|13|Stage Computation: Arith/Log. Ops · OPq rA, rB|[第 10 章](10-sequential.html)|
|14|Executing rmmovq · rmmovq rA, D(rB) 4 0 rA rB D|[第 10 章](10-sequential.html)|
|15|Stage Computation: rmmovq · rmmovq rA, D(rB)|[第 10 章](10-sequential.html)|
|16|Executing popq · popq rA b 0 rA 8|[第 10 章](10-sequential.html)|
|17|Stage Computation: popq · popq rA|[第 10 章](10-sequential.html)|
|18|Executing Conditional Moves · cmovXX rA, rB 2 fn rA rB|[第 10 章](10-sequential.html)|
|19|Stage Computation: Cond. Move · cmovXX rA, rB|[第 10 章](10-sequential.html)|
|20|Executing Jumps · jXX Dest 7 fn Dest|[第 10 章](10-sequential.html)|
|21|Stage Computation: Jumps · jXX Dest|[第 10 章](10-sequential.html)|
|22|Executing call · call Dest 8 0 Dest|[第 10 章](10-sequential.html)|
|23|Stage Computation: call · call Dest|[第 10 章](10-sequential.html)|
|24|Executing ret · ret 9 0|[第 10 章](10-sequential.html)|
|25|Stage Computation: ret · ret|[第 10 章](10-sequential.html)|
|26|Computation Steps · OPq rA, rB|[第 10 章](10-sequential.html)|
|27|Computation Steps · call Dest|[第 10 章](10-sequential.html)|
|28|Computed Values · nFetch nExecute|[第 10 章](10-sequential.html)|
|29|SEQ Hardware · n Key|[第 10 章](10-sequential.html)|
|30|icode ifun rA rB valC valP · Fetch Logic|[第 10 章](10-sequential.html)|
|31|icode ifun rA rB valC valP · Fetch Logic|[第 10 章](10-sequential.html)|
|32|Fetch Control · Logic in HCL|[第 10 章](10-sequential.html)|
|33|Fetch Control halt 0 0 · Logic in HCL nop 1 0|[第 10 章](10-sequential.html)|
|34|Decode Logic · n Register File|[第 10 章](10-sequential.html)|
|35|OPq rA, rB · A Source Decode valA ¬ R[rA] Read operand A|[第 10 章](10-sequential.html)|
|36|OPq rA, rB · Write-back R[rB] ¬ valE Write back result|[第 10 章](10-sequential.html)|
|37|Execute Logic · n Units|[第 10 章](10-sequential.html)|
|38|ALU A Execute · OPq rA, rB|[第 10 章](10-sequential.html)|
|39|OPl rA, rB · ALU Execute valE ¬ valB OP valA Perform ALU operation|[第 10 章](10-sequential.html)|
|40|Memory Logic · Stat|[第 10 章](10-sequential.html)|
|41|Instruction Status · Stat|[第 10 章](10-sequential.html)|
|42|Memory Address · OPq rA, rB|[第 10 章](10-sequential.html)|
|43|Memory Read · OPq rA, rB|[第 10 章](10-sequential.html)|
|44|PC Update Logic · PC|[第 10 章](10-sequential.html)|
|45|PC PC update · OPq rA, rB|[第 10 章](10-sequential.html)|
|46|SEQ Operation · n State|[第 10 章](10-sequential.html)|
|47|Cycle 1 Cycle 2 Cycle 3 Cycle 4 · Clock|[第 10 章](10-sequential.html)|
|48|Cycle 1 Cycle 2 Cycle 3 Cycle 4 · Clock|[第 10 章](10-sequential.html)|
|49|Cycle 1 Cycle 2 Cycle 3 Cycle 4 · Clock|[第 10 章](10-sequential.html)|
|50|Cycle 1 Cycle 2 Cycle 3 Cycle 4 · Clock|[第 10 章](10-sequential.html)|
|51|SEQ Summary · n Implementation|[第 10 章](10-sequential.html)|


## 2026 第一次测验与新增研讨资料

|来源 / 页|覆盖内容|入口|
|---|---|---|
|测验答案 p.1|第 2 讲、3.1～3.2|[11 答案回查](11-quiz01.html)|
|测验答案 p.2|3.3～3.5、第 4 讲前半|[11 答案回查](11-quiz01.html)|
|测验答案 p.3|4.4、第 5 讲、6.1|[11 答案回查](11-quiz01.html)|
|测验答案 p.4|6.2～6.3、7.1 前半|[11 答案回查](11-quiz01.html)|
|测验答案 p.5|7.1 后半、7.2、第 8 讲|[11 答案回查](11-quiz01.html)|
|第 9 讲研讨 p.1|ISA 7 小问、逻辑设计 7 小问|[13 研讨路线](13-seminars.html)|
|第 9 讲研讨 p.2|教材 4.47～4.49|[13 作业索引](13-seminars.html)|
|第 10 讲研讨 p.1|操作分解 7 小问、部件设计 9 小问|[13 研讨路线](13-seminars.html)|
|第 10 讲研讨 p.2|教材 4.51 iaddq|[10 扩展控制](10-sequential.html)|

新课页码表覆盖标题、主体、总结及附加页；重复图表在正文按主题合并。课件个别排印和边界问题在对应正文说明，未把课件中的误写直接当作规则。测验答案中的字母、缺题和重复编号保持来源状态。


## ICS11-Processor Arch-Pipelined-20261022：逐页覆盖

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Processor Architecture III: · PIPE: Pipelined Implementation|[第 11 章](11-pipeline.html)|
|2|Overview · n General Principles of Pipelining|[第 11 章](11-pipeline.html)|
|3|Real-World Pipelines: Car Washes · Sequential                 Parallel|[第 11 章](11-pipeline.html)|
|4|Computational Example · 300 ps         20 ps|[第 11 章](11-pipeline.html)|
|5|3-Way Pipelined Version · 100 ps    20 ps     100 ps       20 ps   100 ps       20 ps|[第 11 章](11-pipeline.html)|
|6|Pipeline Diagrams · n Unpipelined|[第 11 章](11-pipeline.html)|
|7|Operating a Pipeline · 239|[第 11 章](11-pipeline.html)|
|8|Limitations: Nonuniform Delays · 50 ps    20 ps          150 ps           20 ps            100 ps      20 ps|[第 11 章](11-pipeline.html)|
|9|Limitations: Register Overhead · 50 ps 20 ps 50 ps 20 ps 50 ps 20 ps 50 ps 20 ps 50 ps 20 ps 50 ps 20 ps|[第 11 章](11-pipeline.html)|
|10|Data Dependencies · R|[第 11 章](11-pipeline.html)|
|11|Data Hazards · Comb.     R        Comb.        R       Comb.             R|[第 11 章](11-pipeline.html)|
|12|Data Dependencies in Processors · 1   irmovq ＄50, %rax|[第 11 章](11-pipeline.html)|
|13|SEQ Hardware · n Stages occur in sequence|[第 11 章](11-pipeline.html)|
|14|SEQ+ Hardware · n Still sequential|[第 11 章](11-pipeline.html)|
|15|Adding Pipeline Registers  newPC · PC|[第 11 章](11-pipeline.html)|
|16|Pipeline Stages · n Fetch|[第 11 章](11-pipeline.html)|
|17|PIPE- Hardware · n Pipeline registers hold|[第 11 章](11-pipeline.html)|
|18|Signal Naming Conventions · n S_Field|[第 11 章](11-pipeline.html)|
|19|Feedback Paths · n Predicted PC|[第 11 章](11-pipeline.html)|
|20|Predicting the · PC|[第 11 章](11-pipeline.html)|
|21|Our Prediction Strategy · n Instructions that Don’t Transfer Control|[第 11 章](11-pipeline.html)|
|22|Recovering · from PC|[第 11 章](11-pipeline.html)|
|23|Pipeline Demonstration · 1   2   3   4      5      6     7     8      9|[第 11 章](11-pipeline.html)|
|24|Data Dependencies: No Nop · # demo-h0.ys              1   2   3      4      5     6      7      8|[第 11 章](11-pipeline.html)|
|25|Data Dependencies: 1 Nop · # demo-h1.ys              1   2   3   4      5      6     7      8      9|[第 11 章](11-pipeline.html)|
|26|Data Dependencies: 2 Nop’s · # demo-h2.ys              1   2   3   4    5      6      7     8      9     10|[第 11 章](11-pipeline.html)|
|27|Data Dependencies: 3 Nop’s · # demo-h3.ys              1   2    3     4        5     6      7     8       9    10     11|[第 11 章](11-pipeline.html)|
|28|Stalling for Data Dependencies · # demo-h2.ys                1   2   3   4   5     6      7      8     9     10     11|[第 11 章](11-pipeline.html)|
|29|Stall Condition · n Source Registers|[第 11 章](11-pipeline.html)|
|30|Detecting Stall Condition · # demo-h2.ys              1   2   3   4      5      6      7     8     9     10     11|[第 11 章](11-pipeline.html)|
|31|Stalling X3 · # demo-h0.ys                      1   2    3      4      5     6      7      8     9     10     11|[第 11 章](11-pipeline.html)|
|32|What Happens When Stalling? · # demo-h0.ys|[第 11 章](11-pipeline.html)|
|33|Implementing Stalling · n Pipeline Control|[第 11 章](11-pipeline.html)|
|34|Pipeline Register Modes · Rising|[第 11 章](11-pipeline.html)|
|35|Data Forwarding · n Naïve Pipeline|[第 11 章](11-pipeline.html)|
|36|Data Forwarding Example · # demo-h2.ys              1   2     3    4    5      6      7   8    9    10|[第 11 章](11-pipeline.html)|
|37|Bypass Paths · n Decode Stage|[第 11 章](11-pipeline.html)|
|38|Data Forwarding Example #2 · # demo-h0.ys        1     2      3      4      5     6     7      8|[第 11 章](11-pipeline.html)|
|39|Forwarding Priority · # demo-priority.ys          1   2   3   4      5      6     7      8      9     10|[第 11 章](11-pipeline.html)|
|40|Implementing · Forwarding|[第 11 章](11-pipeline.html)|
|41|Implementing Forwarding · ## What should be the A value?|[第 11 章](11-pipeline.html)|
|42|Limitation of Forwarding · n Load-use dependency|[第 11 章](11-pipeline.html)|
|43|Avoiding Load/Use Hazard · n Stall using instruction for|[第 11 章](11-pipeline.html)|
|44|Detecting Load/Use Hazard · Condition         Trigger|[第 11 章](11-pipeline.html)|
|45|Control for Load/Use Hazard · # demo-luh.ys              1   2       3   4    5        6     7     8    9    10    11   12|[第 11 章](11-pipeline.html)|
|46|Branch Misprediction Example|[第 11 章](11-pipeline.html)|
|47|Branch Misprediction Example · demo-j.ys|[第 11 章](11-pipeline.html)|
|48|Branch Misprediction Trace · # demo-j                       1   2    3      4      5      6   7    8     9|[第 11 章](11-pipeline.html)|
|49|Handling Misprediction · Predict branch as taken|[第 11 章](11-pipeline.html)|
|50|Detecting Mispredicted Branch · Condition         Trigger|[第 11 章](11-pipeline.html)|
|51|Control for Misprediction · Condition             F        D        E               M              W|[第 11 章](11-pipeline.html)|
|52|Return Example|[第 11 章](11-pipeline.html)|
|53|demo-retb.ys · Return Example|[第 11 章](11-pipeline.html)|
|54|Incorrect Return Example · n Incorrectly execute 3|[第 11 章](11-pipeline.html)|
|55|Correct Return Example · # demo-retb|[第 11 章](11-pipeline.html)|
|56|Detecting Return · Condition        Trigger|[第 11 章](11-pipeline.html)|
|57|Control for Return · # demo-retb|[第 11 章](11-pipeline.html)|
|58|Special Control Cases · n Detection|[第 11 章](11-pipeline.html)|
|59|Implementing Pipeline Control · n Combinational logic generates pipeline control signals|[第 11 章](11-pipeline.html)|
|60|Initial Version of Pipeline Control · bool F_stall =|[第 11 章](11-pipeline.html)|
|61|Control Combinations|[第 11 章](11-pipeline.html)|
|62|Control Combinations · Load/use    Mispredict           ret 1        ret 2              ret 3|[第 11 章](11-pipeline.html)|
|63|Control Combination A · Mispredict          ret 1|[第 11 章](11-pipeline.html)|
|64|Control Combination B · Load/use                          ret 1|[第 11 章](11-pipeline.html)|
|65|Handling Control Combination B · Load/use                          ret 1|[第 11 章](11-pipeline.html)|
|66|Corrected Pipeline Control Logic · bool D_bubble =|[第 11 章](11-pipeline.html)|
|67|Pipeline Part 1: Summary · n Concept|[第 11 章](11-pipeline.html)|
|68|Pipeline Part 2: Summary · n Data Hazards|[第 11 章](11-pipeline.html)|


## ICS12-memory-hierarchy-20261026：逐页覆盖

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|The Memory Hierarchy · 12th Lecture, Oct. 26, 2026|[第 12 章](12-memory-hierarchy.html)|
|2|Today · ¢ The memory abstraction|[第 12 章](12-memory-hierarchy.html)|
|3|Traditional Bus Structure Connecting · CPU and Memory|[第 12 章](12-memory-hierarchy.html)|
|4|Memory Read Transaction (1) · ¢   CPU places address A on the memory bus.|[第 12 章](12-memory-hierarchy.html)|
|5|Memory Read Transaction (2) · ¢   Main memory reads A from the memory bus, retrieves|[第 12 章](12-memory-hierarchy.html)|
|6|Memory Read Transaction (3) · ¢   CPU read word x from the bus and copies it into register|[第 12 章](12-memory-hierarchy.html)|
|7|Memory Write Transaction (1) · ¢   CPU places address A on bus. Main memory reads it and|[第 12 章](12-memory-hierarchy.html)|
|8|Memory Write Transaction (2) · ¢   CPU places data word y on the bus.|[第 12 章](12-memory-hierarchy.html)|
|9|Memory Write Transaction (3) · ¢    Main memory reads data word y from the bus and stores|[第 12 章](12-memory-hierarchy.html)|
|10|Today · ¢ The memory abstraction|[第 12 章](12-memory-hierarchy.html)|
|11|Random-Access Memory (RAM) · ¢   Key features|[第 12 章](12-memory-hierarchy.html)|
|12|RAM Technologies · ¢   DRAM                   ¢    SRAM|[第 12 章](12-memory-hierarchy.html)|
|13|SRAM vs DRAM Summary · Trans. Access Needs Needs|[第 12 章](12-memory-hierarchy.html)|
|14|Enhanced DRAMs · ¢   Basic DRAM cell has not changed since its invention in 1966.|[第 12 章](12-memory-hierarchy.html)|
|15|Nonvolatile Memories · ¢   DRAM and SRAM are volatile memories|[第 12 章](12-memory-hierarchy.html)|
|16|Conventional DRAM Organization · ¢   d x w DRAM:|[第 12 章](12-memory-hierarchy.html)|
|17|Reading DRAM Supercell (2,1) · Step 1(a): Row access strobe (RAS) selects row 2.|[第 12 章](12-memory-hierarchy.html)|
|18|Reading DRAM Supercell (2,1) · Step 2(a): Column access strobe (CAS) selects column 1.|[第 12 章](12-memory-hierarchy.html)|
|19|Memory Modules · addr (row = i, col = j)|[第 12 章](12-memory-hierarchy.html)|
|20|Today · ¢ The memory abstraction|[第 12 章](12-memory-hierarchy.html)|
|21|Storage Technologies · ¢   Magnetic Disks    ¢   Nonvolatile (Flash)|[第 12 章](12-memory-hierarchy.html)|
|22|What’s Inside A Disk Drive? · Arm   Spindle|[第 12 章](12-memory-hierarchy.html)|
|23|Disk Geometry · ¢ Disks consist of platters, each with two surfaces.|[第 12 章](12-memory-hierarchy.html)|
|24|Disk Geometry (Muliple-Platter View) · ¢   Aligned tracks form a cylinder.|[第 12 章](12-memory-hierarchy.html)|
|25|Disk Capacity · ¢   Capacity: maximum number of bits that can be stored.|[第 12 章](12-memory-hierarchy.html)|
|26|Recording zones · ¢   Modern disks partition tracks|[第 12 章](12-memory-hierarchy.html)|
|27|Computing Disk Capacity · Capacity = (# bytes/sector) x (avg. # sectors/track) x|[第 12 章](12-memory-hierarchy.html)|
|28|Disk Operation (Single-Platter View) · The disk surface|[第 12 章](12-memory-hierarchy.html)|
|29|Disk Operation (Multi-Platter View) · Read/write heads|[第 12 章](12-memory-hierarchy.html)|
|30|Disk Structure - top view of single platter · Surface organized into tracks|[第 12 章](12-memory-hierarchy.html)|
|31|Disk Access · Head in position above a track|[第 12 章](12-memory-hierarchy.html)|
|32|Disk Access · Rotation is counter-clockwise|[第 12 章](12-memory-hierarchy.html)|
|33|Disk Access – Read · About to read blue sector|[第 12 章](12-memory-hierarchy.html)|
|34|Disk Access – Read · After BLUE read|[第 12 章](12-memory-hierarchy.html)|
|35|Disk Access – Read · After BLUE read|[第 12 章](12-memory-hierarchy.html)|
|36|Disk Access – Seek · After BLUE read   Seek for RED|[第 12 章](12-memory-hierarchy.html)|
|37|Disk Access – Rotational Latency · After BLUE read   Seek for RED   Rotational latency|[第 12 章](12-memory-hierarchy.html)|
|38|Disk Access – Read · After BLUE read   Seek for RED   Rotational latency         After RED read|[第 12 章](12-memory-hierarchy.html)|
|39|Disk Access – Service Time Components · After BLUE read   Seek for RED   Rotational latency         After RED read|[第 12 章](12-memory-hierarchy.html)|
|40|Disk Access Time · ¢   Average time to access some target sector approximated by:|[第 12 章](12-memory-hierarchy.html)|
|41|Disk Access Time Example · ¢   Given:|[第 12 章](12-memory-hierarchy.html)|
|42|Disk Access Time Example · ¢   Given:|[第 12 章](12-memory-hierarchy.html)|
|43|I/O Bus · CPU chip|[第 12 章](12-memory-hierarchy.html)|
|44|Reading a Disk Sector (1) · CPU chip|[第 12 章](12-memory-hierarchy.html)|
|45|Reading a Disk Sector (2) · CPU chip|[第 12 章](12-memory-hierarchy.html)|
|46|Reading a Disk Sector (3) · CPU chip|[第 12 章](12-memory-hierarchy.html)|
|47|Solid State Disks (SSDs) · I/O bus|[第 12 章](12-memory-hierarchy.html)|
|48|SSD Performance Characteristics · ¢   Benchmark of Samsung 940 EVO Plus|[第 12 章](12-memory-hierarchy.html)|
|49|SSD Tradeoffs vs Rotating Disks · ¢   Advantages|[第 12 章](12-memory-hierarchy.html)|
|50|The CPU-Memory Gap · The gap                             between DRAM, disk, and CPU speeds.|[第 12 章](12-memory-hierarchy.html)|
|51|Locality to the Rescue! · The key to bridging this CPU-Memory gap is a fundamental|[第 12 章](12-memory-hierarchy.html)|
|52|Today · ¢ The memory abstraction|[第 12 章](12-memory-hierarchy.html)|
|53|Locality · ¢   Principle of Locality: Programs tend to use data and|[第 12 章](12-memory-hierarchy.html)|
|54|Locality Example · sum = 0;|[第 12 章](12-memory-hierarchy.html)|
|55|Qualitative Estimates of Locality · ¢   Claim: Being able to look at code and get a qualitative|[第 12 章](12-memory-hierarchy.html)|
|56|Locality Example · ¢   Question: Does this function have good locality with|[第 12 章](12-memory-hierarchy.html)|
|57|Locality Example · ¢   Question: Can you permute the loops so that the function|[第 12 章](12-memory-hierarchy.html)|
|58|Memory Hierarchies · ¢   Some fundamental and enduring properties of hardware|[第 12 章](12-memory-hierarchy.html)|
|59|Today · ¢ The memory abstraction|[第 12 章](12-memory-hierarchy.html)|
|60|Example Memory · Hierarchy L0:|[第 12 章](12-memory-hierarchy.html)|
|61|Caches · ¢ Cache: A smaller, faster storage device that acts as a staging|[第 12 章](12-memory-hierarchy.html)|
|62|General Cache Concepts · Smaller, faster, more expensive|[第 12 章](12-memory-hierarchy.html)|
|63|General Cache Concepts: Hit · Request: 14         Data in block b is needed|[第 12 章](12-memory-hierarchy.html)|
|64|General Cache Concepts: Miss · Request: 12         Data in block b is needed|[第 12 章](12-memory-hierarchy.html)|
|65|General Caching Concepts: · Types of Cache Misses|[第 12 章](12-memory-hierarchy.html)|
|66|Examples of Caching in the Mem. Hierarchy · Cache Type       What is Cached?     Where is it Cached? Latency (cycles)             Managed By|[第 12 章](12-memory-hierarchy.html)|
|67|Summary · ¢   The speed gap between CPU, memory and mass storage|[第 12 章](12-memory-hierarchy.html)|
|68|Supplemental slides|[第 12 章](12-memory-hierarchy.html)|
|69|Storage Trends · SRAM|[第 12 章](12-memory-hierarchy.html)|
|70|CPU Clock Rates                        Inflection point in computer history · when designers hit the “Power Wall”|[第 12 章](12-memory-hierarchy.html)|

第 11、12 讲研讨单各 2 页；逐问路线见附录 C。教材已回查 p.329 的 4.57(A) 和 pp.451～452 的 6.23/6.24，非整本扫描教材逐页校读。


## SEQ / PIPE 硬件总图补充（2026-10-26）

- [SEQ 原图与逐段读图](10-sequential.html#seq-hardware)：用户新增的 `screenshot_20261026_185016_com.huawei.hmos.hinote.jpg`，按原文件保留，公开资源名为 `hardware-seq.jpg`。正文沿总图解释六阶段、选择器、写回和 PC 回路，并追踪 add/load/call/ret/条件指令。
- [PIPE 原图与逐段读图](11-pipeline.html#pipe-hardware)：用户新增的 `screenshot_20261026_181535_com.huawei.hmos.hinote.jpg`，按原文件保留，公开资源名为 `hardware-pipe.jpg`。正文按 F/D/E/M/W 横条、D 的前递选择器、右侧反馈和左侧状态链展开；未画出的 stall/bubble 控制另行定位。
- 两张原图及相关讲解纳入可编辑源码包；原有局部 SVG 用于辅助展开，原始课堂 PDF 仍不公开提供。


## ICS13-cache-memories-20261029：逐页覆盖

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Cache Memories · 13th Lecture, Oct. 29, 2026|[第13章](13-cache-memories.html)|
|2|Today · ¢ Cache memory organization and operation|[第13章](13-cache-memories.html)|
|3|Recall: Locality · ¢   Principle of Locality: Programs tend to use data and|[第13章](13-cache-memories.html)|
|4|Recall: Memory · Hierarchy                            L0:|[第13章](13-cache-memories.html)|
|5|Recall: General Cache Concepts · Smaller, faster, more expensive|[第13章](13-cache-memories.html)|
|6|General Cache Concepts: Hit · Request: 14         Data in block b is needed|[第13章](13-cache-memories.html)|
|7|General Cache Concepts: Miss · Request: 12         Data in block b is needed|[第13章](13-cache-memories.html)|
|8|Recall: General Caching Concepts: · 3 Types of Cache Misses|[第13章](13-cache-memories.html)|
|9|Cache Memories · ¢   Cache memories are small, fast SRAM-based memories|[第13章](13-cache-memories.html)|
|10|Example: Direct Mapped Cache (E = 1) · Direct mapped: One line per set|[第13章](13-cache-memories.html)|
|11|Example: Direct Mapped Cache (E = 1) · Direct mapped: One line per set|[第13章](13-cache-memories.html)|
|12|Example: Direct Mapped Cache (E = 1) · Direct mapped: One line per set|[第13章](13-cache-memories.html)|
|13|Direct-Mapped Cache Simulation · t=1   s=2   b=1           4-bit addresses (address space size M=16 bytes)|[第13章](13-cache-memories.html)|
|14|E-way Set Associative Cache (Here: E = 2) · E = 2: Two lines per set|[第13章](13-cache-memories.html)|
|15|E-way Set Associative Cache (Here: E = 2) · E = 2: Two lines per set|[第13章](13-cache-memories.html)|
|16|E-way Set Associative Cache (Here: E = 2) · E = 2: Two lines per set|[第13章](13-cache-memories.html)|
|17|2-Way Set Associative Cache Simulation · t=2   s=1   b=1|[第13章](13-cache-memories.html)|
|18|General Cache Organization (S, E, B) · E = 2e lines per set|[第13章](13-cache-memories.html)|
|19|Cache Read                                                      • Locate set · • Check if any line in set|[第13章](13-cache-memories.html)|
|20|What about writes? · B-1|[第13章](13-cache-memories.html)|
|21|Practical Write-back Write-allocate · v    d       tag        0 1 2                B-1|[第13章](13-cache-memories.html)|
|22|Why Index Using Middle Bits? · Direct mapped: One line per set|[第13章](13-cache-memories.html)|
|23|Illustration of Indexing                                                         0000xx · Approaches                                                                      0001xx|[第13章](13-cache-memories.html)|
|24|0000xx · Middle Bit Indexing                                                           0001xx|[第13章](13-cache-memories.html)|
|25|0000xx · High Bit Indexing                                                             0001xx|[第13章](13-cache-memories.html)|
|26|Intel Core i7 Cache Hierarchy · Processor package|[第13章](13-cache-memories.html)|
|27|Example: Core i7 L1 Data Cache · 32 kB 8-way set associative|[第13章](13-cache-memories.html)|
|28|Example: Core i7 L1 Data Cache · 32 kB 8-way set associative|[第13章](13-cache-memories.html)|
|29|Cache Performance Metrics · ¢   Miss Rate|[第13章](13-cache-memories.html)|
|30|Let’s think about those numbers · ¢   Huge difference between a hit and a miss|[第13章](13-cache-memories.html)|
|31|Writing Cache Friendly Code · ¢   Make the common case go fast|[第13章](13-cache-memories.html)|
|32|Today · ¢ Cache organization and operation|[第13章](13-cache-memories.html)|
|33|The Memory Mountain · ¢   Read throughput (read bandwidth)|[第13章](13-cache-memories.html)|
|34|Memory Mountain Test Function · long data[MAXELEMS];   /* Global array to traverse */|[第13章](13-cache-memories.html)|
|35|Core i7 Haswell · The Memory Mountain                                                                                                2.1 GHz|[第13章](13-cache-memories.html)|
|36|Today · ¢ Cache organization and operation|[第13章](13-cache-memories.html)|
|37|Matrix Multiplication Example · Variable sum|[第13章](13-cache-memories.html)|
|38|Miss Rate Analysis for Matrix Multiply · ¢   Assume:|[第13章](13-cache-memories.html)|
|39|Layout of C Arrays in Memory (review) · ¢   C arrays allocated in row-major order|[第13章](13-cache-memories.html)|
|40|Matrix Multiplication (ijk) · /* ijk */|[第13章](13-cache-memories.html)|
|41|Matrix Multiplication (jik) · /* jik */|[第13章](13-cache-memories.html)|
|42|Matrix Multiplication (kij) · /* kij */|[第13章](13-cache-memories.html)|
|43|Matrix Multiplication (ikj) · /* ikj */|[第13章](13-cache-memories.html)|
|44|Matrix Multiplication (jki) · /* jki */                          Inner loop:|[第13章](13-cache-memories.html)|
|45|Matrix Multiplication (kji) · /* kji */|[第13章](13-cache-memories.html)|
|46|Summary of Matrix Multiplication · for (i=0; i<n; i++) {|[第13章](13-cache-memories.html)|
|47|Core i7 Matrix Multiply Performance · Cycles per inner loop iteration|[第13章](13-cache-memories.html)|
|48|Today · ¢ Cache organization and operation|[第13章](13-cache-memories.html)|
|49|Example: Matrix Multiplication · c = (double *) calloc(sizeof(double), n*n);|[第13章](13-cache-memories.html)|
|50|Cache Miss Analysis · ¢   Assume:|[第13章](13-cache-memories.html)|
|51|Cache Miss Analysis · ¢   Assume:|[第13章](13-cache-memories.html)|
|52|Blocked Matrix Multiplication · c = (double *) calloc(sizeof(double), n*n);|[第13章](13-cache-memories.html)|
|53|Cache Miss Analysis · ¢   Assume:|[第13章](13-cache-memories.html)|
|54|Cache Miss Analysis · ¢   Assume:|[第13章](13-cache-memories.html)|
|55|Blocking Summary · ¢ No blocking: (9/8) * n3|[第13章](13-cache-memories.html)|
|56|Cache Summary · ¢   Cache memories can have significant performance impact|[第13章](13-cache-memories.html)|
|57|Supplemental slides · 57|[第13章](13-cache-memories.html)|
|58|Recall: Modern CPU Design · Instruction Control|[第13章](13-cache-memories.html)|
|59|What it Really Looks Like · CPU chip|[第13章](13-cache-memories.html)|
|60|What it Really Looks Like (Cont.) · Intel Sandy Bridge|[第13章](13-cache-memories.html)|
|61|Core i5 Haswell · The Memory Mountain                                                                                               3.1 GHz|[第13章](13-cache-memories.html)|
|62|Cache Capacity Effects from                                                                                                 Core i7 Haswell · 3.1 GHz|[第13章](13-cache-memories.html)|
|63|Cache Block Size Effects from                                                        Core i7 Haswell · 2.26 GHz|[第13章](13-cache-memories.html)|
|64|Modeling Block Size Effects                                                     Core i7 Haswell · 2.26 GHz|[第13章](13-cache-memories.html)|
|65|Core 2 Duo · 2008 Memory Mountain                                                                                             2.4 GHz|[第13章](13-cache-memories.html)|


## ICS14-optimization-20261102：逐页覆盖

|PDF 页|页内主题 / 内容起始|正文回查|
|---|---|---|
|1|Program Optimization · 14th Lecture, Nov. 2, 2026|[第14章](14-optimization.html)|
|2|Today · ¢ Overview|[第14章](14-optimization.html)|
|3|Performance Realities · ¢   There’s more to performance than asymptotic complexity|[第14章](14-optimization.html)|
|4|Optimizing Compilers · ¢   Provide efficient mapping of program to machine|[第14章](14-optimization.html)|
|5|Today · ¢ Overview|[第14章](14-optimization.html)|
|6|Generally Useful Optimizations · ¢   Optimizations that you or the compiler should do regardless|[第14章](14-optimization.html)|
|7|Compiler-Generated Code Motion (-O1) · void set_row(double *a, double *b,|[第14章](14-optimization.html)|
|8|Reduction in Strength · § Replace costly operation with simpler one|[第14章](14-optimization.html)|
|9|Share Common Subexpressions · § Reuse portions of expressions|[第14章](14-optimization.html)|
|10|Optimization Example: Bubblesort · ¢   Bubblesort program that sorts an array A that is allocated|[第14章](14-optimization.html)|
|11|Translated (Pseudo) Code · i := n-1                      t8 := j-1|[第14章](14-optimization.html)|
|12|Redundancy in Address Calculation · i := n-1                      t8 :=j-1|[第14章](14-optimization.html)|
|13|Redundancy Removed · i := n-1                       t8 :=j-1|[第14章](14-optimization.html)|
|14|More Redundancy · i := n-1                       t8 :=j-1|[第14章](14-optimization.html)|
|15|Redundancy Removed · i := n-1                       A[t2] := t7         // A[j]:=A[j+1]|[第14章](14-optimization.html)|
|16|Redundancy in Loops · i := n-1|[第14章](14-optimization.html)|
|17|Redundancy Eliminated · i := n-1                       i := n-1|[第14章](14-optimization.html)|
|18|Final Pseudo Code · i := n-1                             Instruction Count|[第14章](14-optimization.html)|
|19|Today · ¢ Overview|[第14章](14-optimization.html)|
|20|Limitations of Optimizing Compilers · ¢   Operate under fundamental constraint|[第14章](14-optimization.html)|
|21|Optimization Blocker #1: Procedure Calls · ¢   Procedure to Convert String to Lower Case|[第14章](14-optimization.html)|
|22|Lower Case Conversion Performance · § Time quadruples when double string length|[第14章](14-optimization.html)|
|23|Convert Loop To Goto Form · void lower(char *s)|[第14章](14-optimization.html)|
|24|Calling Strlen · /* My version of strlen */|[第14章](14-optimization.html)|
|25|Improving Performance · void lower(char *s)|[第14章](14-optimization.html)|
|26|Lower Case Conversion Performance · § Time doubles when double string length|[第14章](14-optimization.html)|
|27|Optimization Blocker: Procedure Calls · ¢   Why couldn’t compiler move strlen out of inner loop?|[第14章](14-optimization.html)|
|28|Memory Matters · /* Sum rows is of n X n matrix a|[第14章](14-optimization.html)|
|29|Memory Aliasing · /* Sum rows is of n X n matrix a|[第14章](14-optimization.html)|
|30|Removing Aliasing · /* Sum rows is of n X n matrix a|[第14章](14-optimization.html)|
|31|Optimization Blocker: Memory Aliasing · ¢   Aliasing|[第14章](14-optimization.html)|
|32|Today · ¢ Overview|[第14章](14-optimization.html)|
|33|Exploiting Instruction-Level Parallelism · ¢   Need general understanding of modern processor design|[第14章](14-optimization.html)|
|34|Benchmark Example: Data Type for · Vectors|[第14章](14-optimization.html)|
|35|Benchmark Computation · void combine1(vec_ptr v, data_t *dest)|[第14章](14-optimization.html)|
|36|Cycles Per Element (CPE) · ¢   Convenient way to express performance of program that operates on|[第14章](14-optimization.html)|
|37|Benchmark Performance · void combine1(vec_ptr v, data_t *dest)|[第14章](14-optimization.html)|
|38|Basic Optimizations · void combine4(vec_ptr v, data_t *dest)|[第14章](14-optimization.html)|
|39|Effect of Basic Optimizations · void combine4(vec_ptr v, data_t *dest)|[第14章](14-optimization.html)|
|40|Modern CPU Design · Instruction Control|[第14章](14-optimization.html)|
|41|Superscalar Processor · ¢   Definition: A superscalar processor can issue and execute|[第14章](14-optimization.html)|
|42|Pipelined Functional Units                                            Stage 1 · long mult_eg(long a, long b, long c) {|[第14章](14-optimization.html)|
|43|Haswell CPU · § 8 Total Functional Units|[第14章](14-optimization.html)|
|44|x86-64 Compilation of Combine4 · ¢   Inner Loop (Case: Integer Multiply)|[第14章](14-optimization.html)|
|45|Combine4 = Serial Computation (OP = *) · 1 d0|[第14章](14-optimization.html)|
|46|Loop Unrolling (2x1) · void unroll2a_combine(vec_ptr v, data_t *dest)|[第14章](14-optimization.html)|
|47|Effect of Loop Unrolling · Method                Integer                Double FP|[第14章](14-optimization.html)|
|48|Loop Unrolling with Reassociation (2x1a) · void unroll2aa_combine(vec_ptr v, data_t *dest)|[第14章](14-optimization.html)|
|49|Effect of Reassociation · Method                    Integer                   Double FP|[第14章](14-optimization.html)|
|50|Reassociated Computation · x = x OP (d[i] OP d[i+1]);              ¢   What changed:|[第14章](14-optimization.html)|
|51|Loop Unrolling with Separate Accumulators · (2x2)  void unroll2a_combine(vec_ptr v, data_t *dest)|[第14章](14-optimization.html)|
|52|Effect of Separate Accumulators · Method                       Integer                     Double FP|[第14章](14-optimization.html)|
|53|Separate Accumulators · x0 = x0 OP d[i];                              ¢   What changed:|[第14章](14-optimization.html)|
|54|Unrolling & Accumulating · ¢   Idea|[第14章](14-optimization.html)|
|55|Unrolling & Accumulating: Double * · ¢         Case|[第14章](14-optimization.html)|
|56|Unrolling & Accumulating: Int + · ¢         Case|[第14章](14-optimization.html)|
|57|Achievable Performance · Method                   Integer                    Double FP|[第14章](14-optimization.html)|
|58|Programming with AVX2 · YMM Registers|[第14章](14-optimization.html)|
|59|SIMD Operations · n SIMD Operations: Single Precision|[第14章](14-optimization.html)|
|60|Using Vector Instructions · Method                         Integer                     Double FP|[第14章](14-optimization.html)|
|61|What About Branches? · ¢   Challenge|[第14章](14-optimization.html)|
|62|Modern CPU Design · Instruction Control|[第14章](14-optimization.html)|
|63|Branch Outcomes · § When encounter conditional branch, cannot determine where to continue|[第14章](14-optimization.html)|
|64|Branch Prediction · ¢    Idea|[第14章](14-optimization.html)|
|65|Branch Prediction Through Loop · 401029:   vmulsd (%rdx),%xmm0,%xmm0    Assume|[第14章](14-optimization.html)|
|66|Branch Misprediction Invalidation · 401029:   vmulsd (%rdx),%xmm0,%xmm0    Assume|[第14章](14-optimization.html)|
|67|Branch Misprediction Recovery · 401029:   vmulsd (%rdx),%xmm0,%xmm0|[第14章](14-optimization.html)|
|68|Branch Prediction Numbers · ¢   Default behavior:|[第14章](14-optimization.html)|
|69|Getting High Performance · ¢ Good compiler and flags|[第14章](14-optimization.html)|

第13、14讲研讨单各2页，逐小问对照见附录 C。教材回查范围新增 pp.453～455 的 Cache/转置题与 pp.393～394 的内积题；未声称逐页阅读整本教材。

## 第 15 讲：链接逐页索引

|PDF 页|主题回查|
|---|---|
|1|Linking / Introduction to Computer Systems|
|2|Outline of Linking / ¢   Linking: combining object files into programs|
|3|Example C Program / int sum(int *a, int n);           int sum(int *a, int n)|
|4|Compiler Driver, GCC as an Example / ¢ Gcc is the compiler driver in compilation toolchain.|
|5|Preprocessor / ¢   First, gcc compiler driver invokes cpp to generate expanded source|
|6|Compiler / ¢   Next, gcc invokes cc1 to generate assembly code|
|7|Assembler / ¢   Furthermore, gcc invokes gas to generate object code|
|8|(Static) Linking / ¢   Programs are translated and linked using a compiler driver:|
|9|Why Linkers? / ¢   Reason 1: Modularity|
|10|Why Linkers? (cont) / ¢   Reason 2: Efficiency|
|11|What Do Linkers Do? / ¢   Step 1: Symbol resolution|
|12|Symbols in Example C Program / Declaration                           Definitions|
|13|What Do Linkers Do? (cont) / ¢   Step 2: Relocation|
|14|Three Kinds of Object Files (Modules) / ¢   Relocatable object file (.o file)|
|15|Executable and Linkable Format (ELF) / ¢   Standard binary format for object files|
|16|ELF Object File Format / ¢   ELF header|
|17|ELF Object File Format (cont.) / ¢   .symtab section|
|18|Parallel Views of a ELF File / ¢ Program header table/Segments is used to build a process image|
|19|Linker Symbols / ¢   Global symbols|
|20|Step 1: Symbol Resolution / …that’s defined here     Referencing|
|21|Local Symbols / ¢   Local non-static C variables vs. local static C variables|
|22|How Linker Resolves Duplicate Symbol Names / ¢    Program symbols are either strong or weak|
|23|Linker’s Symbol Rules / ¢   Rule 1: Multiple strong symbols are not allowed|
|24|Linker Puzzles / int x;|
|25|Rules for avoiding type mismatches / ¢ Avoid global variables as much as possible|
|26|Step 2: Relocation / Relocatable Object Files       Executable Object File|
|27|2-Step Relocation in Static Linking / ¢   Relocating sections and symbol definitions|
|28|Relocation Entries / ¢   A relocation entry generates from reference with unknown location.|
|29|Two Most Basic Relocation Types / ¢   R_X86_64_PC32|
|30|Relocation Entries / int array[2] = {1, 2};|
|31|Relocation Entries (in main.o) / int array[2] = {1, 2};|
|32|Relocation Entries (in main.o) / int array[2] = {1, 2};|
|33|Relocation Entries (in sum.o) / int sum(int *a, int n)|
|34|Original Object File of main.o / int array[2] = {1, 2};|
|35|Original Object File of sum.o / int sum(int *a, int n){|
|36|.text=0xbabe00             0000000000babe00 <_start>: / ...|
|37|Loading Executable Object Files                                                          Memory / invisible to|
|38|Libraries: Packaging a Set of Functions / ¢   How to package functions commonly used by programmers?|
|39|Old-fashioned Solution: Static Libraries / ¢   Static libraries (.a archive files)|
|40|Creating Static Libraries / atoi.c        printf.c                  random.c|
|41|Commonly Used Libraries / libc.a (the C standard library)|
|42|Linking with                               libvector.a / Static Libraries|
|43|Linking with Static Libraries / addvec.o         multvec.o|
|44|Using Static Libraries / ¢   Linker’s algorithm for resolving external references:|
|45|Modern Solution: Shared Libraries / ¢   Static libraries have the following disadvantages:|
|46|Shared Libraries (cont.) / ¢   Dynamic linking can occur when executable is first loaded|
|47|Dynamic Library Example / addvec.c      multvec.c|
|48|Dynamic Linking at Load-time / main2.c   vector.h           unix> gcc -shared -o libvector.so \|
|49|Dynamic Linking at Run-time / #include <stdio.h>|
|50|Dynamic Linking at Run-time (cont) / ...|
|51|Dynamic Linking at Run-time / dll.c     vector.h        unix> gcc -shared -o libvector.so \|
|52|What dynamic libraries are required? / ¢   .interp section|
|53|Static vs. Dynamic Linking Tradeoffs / Static:|
|54|Linking Summary / ¢   Linking is a technique that allows programs to be|
|55|Case Study: Library Interpositioning / ¢ Documented in Section 7.13 of textbook|
|56|Some Interpositioning Applications / ¢   Security|
|57|Some Interpositioning Applications / ¢   Monitoring and Profiling|
|58|Example program / #include <stdio.h>|
|59|Compile-time Interpositioning / #ifdef COMPILETIME|
|60|Compile-time Interpositioning / #define malloc(size) mymalloc(size)|
|61|Load/Run-time Interpositioning / #ifdef RUNTIME|
|62|Load/Run-time Interpositioning / /* free wrapper function */|
|63|Load/Run-time Interpositioning / linux> make intr|
|64|Interpositioning Recap / ¢   Compile Time|
|65|Linking Recap / ¢ Usually: Just happens, no big deal|

## 第 16 讲：异常控制流与进程逐页索引

|PDF 页|主题回查|
|---|---|
|1|Exceptional Control Flow: / Exceptions and Processes|
|2|Printers Used to Catch on Fire|
|3|Highly Exceptional Control Flow / https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/drivers/char/lp.c?h=v5.0-rc3|
|4|Today / ¢ Exceptional Control Flow|
|5|Control Flow / ¢   Processors do only one thing:|
|6|Altering the Control Flow / ¢   Up to now: two mechanisms for changing control flow:|
|7|Exceptional Control Flow / ¢ Exists at all levels of a computer system|
|8|Today / ¢ Exceptional Control Flow|
|9|Exceptions / ¢   An exception is a transfer of control to the OS kernel in response|
|10|Exception Tables / Exception|
|11|(partial) Taxonomy / ECF|
|12|Asynchronous Exceptions (Interrupts) / ¢   Caused by events external to the processor|
|13|Synchronous Exceptions / ¢   Caused by events that occur as a result of executing an|
|14|System Calls / ¢ Each x86-64 system call has a unique ID number|
|15|System Call Example: Opening File / ¢    User calls: open(filename, options)|
|16|System Call Example:       Opening / Almost like a function call File|
|17|Fault Example: Page Fault                                    int a[1000]; / ¢   User writes to memory location                           main ()|
|18|Fault Example: Invalid Memory Reference / int a[1000];|
|19|Today / ¢ Exceptional Control Flow|
|20|Processes / ¢   Definition: A process is an instance of a running|
|21|Multiprocessing: The Illusion / Memory           Memory                   Memory|
|22|Multiprocessing Example / ¢   Running program “top” on Mac|
|23|Multiprocessing: The (Traditional) Reality / Memory|
|24|Multiprocessing: The (Traditional) Reality / Memory|
|25|Multiprocessing: The (Traditional) Reality / Memory|
|26|Multiprocessing: The (Traditional) Reality / Memory|
|27|Multiprocessing: The (Modern) Reality / Memory|
|28|Concurrent Processes / ¢ Each process is a logical control flow.|
|29|User View of Concurrent Processes / ¢   Control flows for concurrent processes are physically|
|30|Context Switching / ¢   Processes are managed by a shared chunk of memory-|
|31|Today / ¢ Exceptional Control Flow|
|32|System Call Error Handling / ¢ On error, Linux system-level functions typically return -1 and|
|33|Error-reporting functions / ¢   Can simplify somewhat using an error-reporting function:|
|34|Error-handling Wrappers / ¢   We simplify the code we present to you even further by|
|35|Obtaining Process IDs / ¢   pid_t getpid(void)|
|36|Creating and Terminating Processes / From a programmer’s perspective, we can think of a process|
|37|Creating Processes / ¢   Parent process creates a new running child process by|
|38|Conceptual View of fork / Memory                                              Memory|
|39|fork Example / int main(int argc, char** argv)             ¢ Call once, return twice|
|40|Making fork More Nondeterministic / ¢   Problem|
|41|Variable delay fork / /* fork wrapper function */|
|42|forkx2 Example                        ¢ Call once, return twice / int main(int argc, char** argv)|
|43|Modeling fork with Process Graphs / ¢   A process graph is a useful tool for capturing the partial|
|44|Process Graph Example / int main(int argc, char** argv)|
|45|Interpreting Process Graphs / ¢   Original graph:|
|46|fork Example: Two consecutive forks / Bye|
|47|fork Example: Nested forks in parent / void fork4()|
|48|fork Example: Nested forks in children / void fork5()|
|49|Terminating Processes / ¢   Process becomes terminated for one of three reasons:|
|50|Reaping Child Processes / ¢   Idea|
|51|Zombie / void fork7() {|
|52|Non- / void fork8()|
|53|wait: Synchronizing with Children / ¢    Parent reaps a child by calling the wait function|
|54|wait: Synchronizing with Children / ¢   Parent reaps a child by calling the wait function|
|55|wait: Synchronizing with Children / void fork9() {|
|56|Another wait Example / ¢   If multiple children completed, will take in arbitrary order|
|57|waitpid: Waiting for a Specific Process / ¢   pid_t waitpid(pid_t pid, int *status, int options)|
|58|execve: Loading and Running Programs / ¢   int execve(char *filename, char *argv[], char *envp[])|
|59|execve Example / ¢   Execute "/bin/ls –lt /usr/include" in child process|
|60|Null-terminated                Bottom of stack / Structure of        environment variable strings|
|61|Summary / ¢   Exceptions|
|62|Summary (cont.) / ¢   Spawning processes|
