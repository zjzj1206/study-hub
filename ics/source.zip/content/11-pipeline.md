# 11 · PIPE 流水线与冒险控制

依据第 11 讲 2026-10-22 课件全部 68 页与第 11 讲研讨单。先掌握[第 10 章 SEQ](10-sequential.html)的指令语义与六阶段操作，再把不同指令的阶段重叠。这里讨论基础 Y86-64、顺序发射和顺序写回的五级 PIPE；所有寄存器名称保留 `%` 前缀。

## 流水线的目标：吞吐量、延迟与时钟周期

- **流水化**：在组合电路之间插入流水线寄存器，让不同操作同时占用不同的级。洗车类比中，一辆车依次清洗、冲水、烘干，多辆车可分别占用三个工位；并行复制整套洗车设备则是另一种组织方式。
- **延迟 latency**：一个操作从进入到产生最终结果所经历的时间。
- **吞吐量 throughput**：单位时间完成的操作数。稳定运行且每周期完成一个操作时，吞吐量为时钟周期的倒数。
- **流水线寄存器开销**：用 $r$ 概括课件模型中的寄存器、建立时间等时序开销；第 $i$ 级的组合延迟为 $d_i$，级数为 $k$。忽略额外时钟偏斜时：

$$
T_{clk}\geq\max_{1\leq i\leq k}d_i+r,\qquad
L=kT_{clk},\qquad Q_{ideal}=\frac1{T_{clk}}.
$$

- **有限条指令的填充与排空**：无冒险、每条操作经过全部 $k$ 级、初始为空时，完成 $n$ 条需要 $n+k-1$ 周期。平均吞吐量为 $n/((n+k-1)T_{clk})$；只有 $n$ 很大时才接近理想值。
- **课件数值对比**：总组合延迟均为 300 ps，寄存器开销均为 20 ps。

|组织|组合延迟分配|周期|单操作延迟|稳态吞吐量|寄存器开销占周期|
|---|---|---|---|---|---|
|单级|300 ps|320 ps|320 ps|3.125 GIPS|6.25%|
|均衡三级|100、100、100 ps|120 ps|360 ps|8.333 GIPS|16.67%|
|不均衡三级|50、150、100 ps|170 ps|510 ps|5.882 GIPS|11.76%|
|均衡六级|每级 50 ps|70 ps|420 ps|14.286 GIPS|28.57%|

- **划分原则**：尽量平衡各级组合延迟；慢级决定整个周期。增加级数会增加寄存器、功耗和控制复杂度，且使分支恢复等代价上升，不能只按 $300/k$ 估算周期。
- **时钟沿前后**：旧流水线寄存器输出先驱动组合逻辑，候选输入逐渐稳定；时钟沿统一采样。239 ps 与 241 ps 可分别位于 240 ps 采样沿的两侧，300 ps 时组合逻辑仍可能传播，359 ps 时应已满足下一采样沿的建立要求。具体边沿方向以时序图约定为准。

## 数据相关、冒险与资源冲突

- **程序次序**：写在前面的指令称为较老指令，后面的称为较年轻指令。正确流水线必须保留 ISA 定义的顺序执行效果。
- **RAW，写后读相关**：较老指令写寄存器 $r$，较年轻指令读取该写入产生的值。例如 `irmovq $50,%rax` 后的 `addq %rax,%rbx`。相关由程序决定，不因插入前递线路而消失。
- **数据冒险**：实现的实际取值时刻早于所需结果可用时刻，以致可能读到错误值。RAW 相关是否造成冒险取决于指令间隔、流水级划分和前递能力。
- **WAR，读后写反相关**：较老指令必须先读旧值，较年轻指令再覆盖同名位置。**WAW，写后写输出相关**：两次写入同一位置，最终必须保留较年轻指令的结果。
- **本章 WAR/WAW 的边界**：固定阶段读寄存器、顺序流经各级、统一在 W 写回时，年轻指令不会抢在老指令之前读写，因而普通程序寄存器 WAR/WAW 不产生本章的顺序颠倒冒险。可变延迟、乱序完成等设计需要另行处理；内存读写还须分析是否访问同一地址。
- **控制冒险**：下一条正确指令地址尚未确定或预测错误，包括条件跳转和返回。
- **结构冒险**：同周期多个操作争用不能并行使用的硬件资源。课件以取指与数据内存分开的逻辑接口、足够的寄存器端口等条件避免相应冲突；现实中的共享资源需要额外仲裁。

## 从 SEQ 到 SEQ+，再到 PIPE

- **SEQ**：一条指令的取指、译码、执行、访存、写回和下一 PC 计算在同一长周期完成。
- **SEQ+**：仍一次执行一条指令，把 PC 选择移到取指开始，用前一条指令已保存的结果决定当前取指地址。原独立 PC 状态由预测/选择所需的等价状态承载；没有凭空消除保存控制流信息的需要。
- **PIPE−**：在阶段间加入寄存器，形成 F、D、E、M、W 五级；此处减号表示还未完善冒险处理。不同指令在同周期并行占用不同级。
- **PIPE**：在基本流水线之上加入前递、暂停、气泡和控制恢复，使重叠执行保持 ISA 语义。SEQ 的 PC 更新并入 PIPE 的 F 级 PC 选择，所以是五级而非六级。

[![PIPE 五级与反馈路径](pipe-overview.svg)](pipe-overview.svg)

|流水级|本周期主要组合操作|进入该级的寄存器保存什么|
|---|---|---|
|F Fetch|选择 `f_pc`、取指、形成字段和 `f_valP`、预测后继|F：`predPC`|
|D Decode|解释源/目的编号；读寄存器与前递选择|D：`stat,icode,ifun,rA,rB,valC,valP`|
|E Execute|选 ALU 输入、计算 `e_valE/e_Cnd`、修正条件传送目的|E：`stat,icode,ifun,valC,valA,valB,dstE,dstM,srcA,srcB`|
|M Memory|按该指令地址/使能读写内存，形成 `m_valM/m_stat`|M：`stat,icode,Cnd,valE,valA,dstE,dstM`|
|W Write back|将保存的结果写回程序寄存器，产生处理器状态|W：`stat,icode,valE,valM,dstE,dstM`|

- **大写与小写前缀**：`E_valA` 是 E 流水线寄存器当前保存的字段；`e_valE` 是当前 E 级组合逻辑刚算出的结果。`M_valE` 与 `m_valM` 更不能互换。
- **逐级传递**：某条指令的字段要与该指令一起前进；F 产生的 `valC` 先进入 D，再进入 E，不能把当前 F 指令的常数直接送给另一条 E 指令。
- **反馈路径**：预测地址送回 F；M 的分支结果和顺序地址修正 F；W 的返回地址修正 F；W 的数据与目的编号送寄存器写端口。前递还增加 E/M/W 到 D 的反馈。
- **复用 `valA`**：call/jXX 在 D 将 `D_valP` 放入 `d_valA`。call 后续用它存返回地址，jXX 后续用它恢复未跳转地址。因此 `M_valA` 不总是某个寄存器原值。

## PC 预测和恢复的完整来源

- 普通指令预测 `f_valP`；call 与所有 jXX 都预测 `f_valC`。无条件跳转和 call 的目标已在取指字段中，条件跳转则采用“预测跳转成立”。ret 不预测返回栈顶。
- 条件分支在 E 算出 `e_Cnd`；若预测错，时钟沿后分支进入 M，F 从 `M_valA` 恢复顺序地址。
- ret 在 M 读出返回地址，再存入 W；F 在其处于 W 时选择 `W_valM`。

```hcl
int f_pc = [
    M_icode == IJXX && !M_Cnd : M_valA;
    W_icode == IRET : W_valM;
    1 : F_predPC;
];
int f_predPC = [
    f_icode in { IJXX, ICALL } : f_valC;
    1 : f_valP;
];
```

- **优先级**：HCL 先检查 M 分支恢复，再检查 W-ret，最后选择预测值；实际合法指令序列与冲刷约束使相关冲突受到限制，不应脱离可达状态任意解释组合输入。
- **课件勘误**：第 63 页文字的 `M_valM` 应为 `M_valA`；分支没有从数据内存读出顺序地址。第 48、55、57 页动画残留的地址或 32 位寄存器字样，按完整 Y86-64 编码重算；例如地址 `0x002` 的 9 字节 jXX 的顺序地址为 `0x00b`。

## 先理解停顿：nop、bubble、stall 的区别

- **nop 指令**：程序中的真实编码，消耗取指空间，按正常阶段前进且不改变程序寄存器、内存或 CC。静态插 nop 要知道具体硬件时序，增加代码体积，也可能在本可前递时仍浪费周期。
- **bubble 气泡**：控制逻辑向某流水线寄存器注入无副作用状态。它占用后续流水线槽，但不是从程序存储器取出的字节，不推进一条原程序指令。
- **stall 暂停**：某流水线寄存器在时钟沿保持原字段不变，下一周期继续处理原指令。
- **normal 正常**：时钟沿装入前一级组合逻辑给出的候选字段。
- **冻结前端、排空后端**：D 等待操作数时冻结 F 和 D，向 E 注入 bubble，让原 E/M/W 指令继续前进。冻结所有级会使生产者也停止，等待的结果永远不能到达。
- **为何朴素设计要三个 nop**：课件初始设计的 D 取值不能利用同周期 W 的新结果；生产者 W 与消费者 D 同周期仍可能读旧值。三个 nop 使消费者 D 延后到写回完成之后。加入 W→D 前递后，此约束改变，不能跨实现死记 nop 数量。
- **同一寄存器的控制互斥**：正常的控制不得让它同时 `stall=1` 与 `bubble=1`；这不是“先做一个再做另一个”。

## 前递：取最近的、已经可用的结果

- **前递 forwarding / bypassing**：结果尚未写回程序寄存器时，直接送到消费者 D 级的值选择器，替换过时的寄存器堆读值。
- 可用来源依次是 E 的 `e_valE`，M 的 `m_valM/M_valE`，W 的 `W_valM/W_valE`，最后才是寄存器堆读值。
- **多重匹配的年龄规则**：E 中的生产者比 M/W 中的年轻，代表顺序执行中更近的一次写；应先取 E，再取 M，再取 W。同一条 pop 同时写两个目的时，M 结果优先于 E 结果。
- **条件传送**：比较的是经过条件判定的 `e_dstE`；条件假时它已被置为 `RNONE`，不能把未发生的写入前递给消费者。
- **有效编号**：只有实际使用的源寄存器和有效目的才代表依赖；`RNONE` 表示不使用/不写。下面显式加有效源判断，避免把两个 `RNONE` 相等误读为真实相关。

```hcl
int d_valA = [
    D_icode in { ICALL, IJXX } : D_valP;
    d_srcA != RNONE && d_srcA == e_dstE : e_valE;
    d_srcA != RNONE && d_srcA == M_dstM : m_valM;
    d_srcA != RNONE && d_srcA == M_dstE : M_valE;
    d_srcA != RNONE && d_srcA == W_dstM : W_valM;
    d_srcA != RNONE && d_srcA == W_dstE : W_valE;
    1 : d_rvalA;
];
int d_valB = [
    d_srcB != RNONE && d_srcB == e_dstE : e_valE;
    d_srcB != RNONE && d_srcB == M_dstM : m_valM;
    d_srcB != RNONE && d_srcB == M_dstE : M_valE;
    d_srcB != RNONE && d_srcB == W_dstM : W_valM;
    d_srcB != RNONE && d_srcB == W_dstE : W_valE;
    1 : d_rvalB;
];
int e_dstE = [
    E_icode == IRRMOVQ && !e_Cnd : RNONE;
    1 : E_dstE;
];
```

- **例：两个源可来自不同级**。`irmovq $10,%rdx; irmovq $3,%rax; addq %rdx,%rax` 中，add 在 D 时第一条在 M、第二条在 E，于是 `d_valA=M_valE=10`，`d_valB=e_valE=3`，最终算出 13。
- **例：连续覆盖同一寄存器**。连续向 `%rax` 写 1、2、3，紧接着读取它；即使 E/M/W 都匹配，必须取最近的 3。

## Load-use：前递仍来不及的相关

- `mrmovq` 和 `popq` 的内存结果在 M 末端才可用；紧随其后的消费者已经在 D 末端需要该值。E 的 `e_valE` 只是地址或递增后的栈指针，不能替代将来读出的 `valM`。
- 定义检测条件 $L$：E 是读内存到寄存器的指令，且有效目的 `E_dstM` 匹配 D 的实际源 `d_srcA/d_srcB`。
- 处理方式：F stall、D stall、E bubble；原 E 的 load 正常进 M。下一周期消费者仍在 D，从当前 M 的 `m_valM` 前递，随后进入 E。**基础 PIPE 的紧邻 load-use 代价为一个周期**。

```asm
mrmovq 0(%rbx), %rax
addq %rax, %rcx
```

|指令 / 周期|1|2|3|4|5|6|7|
|---|---|---|---|---|---|---|---|
|load|F|D|E|M|W|||
|add||F|D（等待）|D（取 m_valM）|E|M|W|
|注入的气泡||||E|M|W||

- 若 load 后有一条独立指令，再使用加载值，通常已有足够间隔，不需这一次暂停。
- `mrmovq` 后紧邻 `rmmovq`，即使相关只在存储数据上，**本章把数据统一在 D 确定的实现**仍会按 load-use 暂停；另加晚期存储数据前递的优化不属于本章基础线路。
- `popq %rsp` 的后继若读 `%rsp`，需要内存弹出值；不得仅前递 E 产生的 `R[%rsp]+8`。load-use 检测及 M 结果优先共同保证正确。

## 分支预测失败：冲刷两条错误路径指令

- 当 E 中 `jXX` 的 `e_Cnd=0` 时，预测目标路径已分别占据 D、F；正确指令应从该分支的顺序地址开始。
- 时钟沿对 D、E 注入 bubble：原 F 不进入 D，原 D 不进入 E；分支自身正常进入 M。
- 下一周期由 M 的 `M_valA` 选择正确 `f_pc`。错误路径尚未进入有程序副作用的阶段，冲刷后不允许它们写寄存器、内存或 CC。
- **基础预测失败代价为两周期**；预测正确不需要这项罚时。错误路径指令的取指次数不等于应提交的指令数。

|指令 / 周期|1|2|3|4|5|6|7|8|
|---|---|---|---|---|---|---|---|---|
|未成立的 jXX|F|D|E|M|W||||
|错误目标指令||F|D|取消|||||
|错误目标的后继|||F|取消|||||
|正确顺序指令||||F|D|E|M|W|

## ret：等待从栈取回的 PC

- ret 的目标来自 `M8[R[%rsp]]`，取指时未知。ret 在 D、E、M 的每个周期暂停 F，并向 D 注入 bubble，阻止 ret 后面顺序地址的指令进入执行。
- ret 自身继续向后走；进入 W 后，F 选择 `W_valM`，恢复正确取指。正常无额外依赖时产生三个空槽，代价为三周期。
- 恢复的是栈中的返回地址，与 ret 自身的 `valP=PC+1` 无关。

|指令 / 周期|1|2|3|4|5|6|7|8|9|
|---|---|---|---|---|---|---|---|---|---|
|ret|F|D|E|M|W|||||
|正确返回点|||||F|D|E|M|W|
|F 在此前的动作||stall|stall|stall||||||

## 三种情况统一成流水线控制

令 $L$ 为 load-use，$B$ 为分支预测失败，$R$ 为 D/E/M 存在 ret；下列布尔量在当前周期计算，控制**下一个时钟沿**的流水线寄存器动作。

```hcl
bool load_use = E_icode in { IMRMOVQ, IPOPQ }
    && E_dstM != RNONE && E_dstM in { d_srcA, d_srcB };
bool mispredict = E_icode == IJXX && !e_Cnd;
bool ret_pending = IRET in { D_icode, E_icode, M_icode };

bool F_stall = load_use || ret_pending;
bool F_bubble = 0;
bool D_stall = load_use;
bool D_bubble = mispredict || (!load_use && ret_pending);
bool E_stall = 0;
bool E_bubble = mispredict || load_use;
```

|当前情况|F|D|E|M / W（无异常）|
|---|---|---|---|---|
|只存在 load-use|stall|stall|bubble|normal|
|只存在错误预测|normal|bubble|bubble|normal|
|只存在 ret 等待|stall|bubble|normal|normal|
|错误预测且 D 是错误路径 ret|stall|bubble|bubble|normal|
|load-use 且 D 是 ret|stall|stall|bubble|normal|

### 组合 A：未成立分支后预测到 ret

- E 的分支已知预测错误，D 的 ret 属于要取消的错误路径。两种控制都要求 D bubble，分支还要求 E bubble；F 即使因 ret 暂停，下一周期仍会由 M 分支恢复地址选择覆盖 `F_predPC`。
- 不能因为看见 ret，就坚持等它运行到 W；它不应提交。

### 组合 B：load 写 `%rsp`，紧跟 ret

```asm
mrmovq 0(%rbx), %rsp
ret
```

- E 的 load 写 `%rsp`，D 的 ret 要读 `%rsp`，所以 $L=1,R=1$。
- 初版 `D_bubble = B || R` 会同时要求 D stall 与 D bubble，造成冲突，并可能丢掉 ret。
- 修正为 `D_bubble = B || (!L && R)`：load-use 优先，让 ret 在 D 多等一个周期，E 注入气泡。取到正确 `%rsp` 后再按 ret 规则继续。
- 同一条 E 指令不可能同时是 load 与 jXX，因此基础指令集的 $L$ 与 $B$ 不会同时成立；控制互斥应结合可达指令状态核对。

## 状态、异常与条件码提交

- Fetch 把地址错/非法编码/停止信息存入 `f_stat`，随该条指令逐级传播；M 的数据内存错误将该条状态改为 ADR。
- 程序可见停止状态在 W 判定。年轻指令不能越过较老的错误/停止指令留下额外副作用。
- 标准 PIPE 在 `m_stat` 或 `W_stat` 为 ADR、INS、HLT 时禁止 E 更新 CC，并通过 M bubble、W stall 保持停止状态。此处是教材实现补充，用于解释为什么“OPq 就写 CC”不是完整控制。

```hcl
bool set_cc = E_icode == IOPQ
    && !(m_stat in { SADR, SINS, SHLT })
    && !(W_stat in { SADR, SINS, SHLT });
bool M_stall = 0;
bool M_bubble = m_stat in { SADR, SINS, SHLT }
    || W_stat in { SADR, SINS, SHLT };
bool W_stall = W_stat in { SADR, SINS, SHLT };
bool W_bubble = 0;
```

## 周期数、CPI 与研讨题的解题步骤

- 五级、空管启动、无缓存等待且计到末条 W 时，基础周期为 $N+4$。若各项罚时独立且不重叠，可写：

$$
C=N+4+N_L+2N_B+3N_R,\qquad CPI=\frac CN.
$$

- $N_L$ 计实际产生的紧邻 load-use 暂停，$N_B$ 计实际预测失败分支，$N_R$ 计需要标准返回等待的 ret；组合冒险、末尾停止和题设计数起点可能使直接相加失效，应以逐周期时序为准。
- 稳态、忽略填充排空时，若相应频率为 $p_L,p_B,p_R$，近似 $CPI=1+p_L+2p_B+3p_R$。频率的分母与事件定义必须一致。
- **画表流程**：先列正确程序路径与每条指令的源/目的；按正常 F/D/E/M/W 填表；逐周期检查 load-use、分支与 ret；标记 stall/bubble；再按前递优先级填写 D 的实际数据；最后核对寄存器、内存、CC 与总周期数。

## 作业 4.57(A)：只在执行阶段需要加载值时暂停

- 本地教材 p.329 的改进称为 **load forwarding**：M 中 load 的 `m_valM` 可送给当前 E 中 store 的 `e_valA`，下一时钟沿进入 M 的 `valA`，供该 store 下一周期写内存。
- 对 `rmmovq/pushq`，若加载结果仅作为待存数据（源 A），可利用此路径免去暂停；若作为地址计算的源 B，E 立即需要，仍必须暂停。
- 修正检测条件如下；它是作业扩展，前文基础 PIPE 的 load-use 公式保持原样。

```hcl
bool load_use_with_lf = E_icode in { IMRMOVQ, IPOPQ }
    && E_dstM != RNONE
    && (E_dstM == d_srcB
        || (E_dstM == d_srcA
            && !(D_icode in { IRMMOVQ, IPUSHQ })));
```

- **例 1**：`mrmovq 0(%rcx),%rdx` 后跟 `pushq %rdx`，`%rdx` 只供写内存，晚期前递可免暂停。
- **例 2**：`popq %rdx` 后跟 `rmmovq %rax,0(%rdx)`，`%rdx` 供 ALU 计算地址，必须暂停。
- **双重使用**：`rmmovq %rdx,0(%rdx)` 同时把 `%rdx` 用于数据和地址，即使源 A 可晚供给，源 B 依赖仍使检测为真。


来源：第 11 讲课件 pp.1–68、第 11 讲小班研讨单；控制表达式另与本地 CS:APP 官方模拟器 `pipe-std.hcl` 核对。硬件产品与更复杂的乱序处理器不是本讲 PIPE 模型的默认假设。
