# 10 · SEQ 顺序处理器与 HCL 控制

依据第 10 讲 2026-10-19 课件全部 51 页及对应研讨单。[第 09 章](09-isa-logic.html)规定 Y86 的行为，本章把每类指令拆成相同的六个逻辑阶段，再汇总成控制信号。**SEQ 一条指令占一个长周期，六阶段不是六个时钟周期，也不是六级流水线。**

## 从机器状态到六个阶段

- **Fetch 取指**：用 PC 读指令字节，得到 `icode/ifun`、可选 `rA/rB`、可选常数 valC，同时形成顺序后继 valP。
- **Decode 译码/读寄存器**：控制 srcA/srcB 选择需要的寄存器，读出 valA/valB。
- **Execute 执行**：选择 ALU 两个输入与运算，产生 valE；需要时计算条件 Cnd 和候选 CC。
- **Memory 访存**：选择地址、读/写使能及写数据；读结果记为 valM。
- **Write back 写回**：将 valE 写到 dstE、valM 写到 dstM；RNONE 表示该端口不写寄存器。
- **PC update 更新 PC**：在 valP、valC、valM 中选择下一 PC。

### 信号不是同义词

|信号|含义|易混点|
|---|---|---|
|`rA/rB`|指令编码中的寄存器编号|并非每条指令都直接读两者|
|`srcA/srcB`|本周期实际读端口的寄存器编号|pop/ret 都需读 `%rsp`|
|`valA/valB`|读端口输出的数据字|与寄存器编号不同|
|`valC`|立即数、位移或目标地址|具体含义由指令决定|
|`valP`|PC 加指令长度|call 压入的返回地址|
|`valE`|ALU 输出|可能是算术结果，也可能是有效地址或新的 `%rsp` 值|
|`valM`|数据内存读出的字|load 的值、pop 的值或 ret 的返回地址|
|`dstE/dstM`|两个写回端口的目的编号|与写回数据配对理解|
|`Cnd`|`Cond(CC,ifun)` 的结果|cmov 控制写回；jXX 控制下一 PC|
|`Stat`|正常、停止或错误状态|不同于只描述算术结果的 CC|

- ALU 按 `valB OP valA` 组织。减法是 B−A，调换两侧会改变结果。
- 数据通路中的“箭头”表示组合信号传播；架构状态在时钟沿才统一提交正常指令的结果。
- 以下步骤表假设指令与地址有效；故障状态需走后面的状态控制。

## 每类指令的六阶段操作

共同取指规则：首字节分成 `icode:ifun`；需要寄存器字节时从 PC+1 读取；常数字段从 PC+1 或 PC+2 开始读取。下表直接用 `R[%rsp]` 表示该指令执行前的栈指针值。

|类别|取指所得顺序地址 valP|读寄存器|执行|访存|写回|实际下一 PC|
|---|---|---|---|---|---|---|
|`halt/nop`|`PC+1`|无|无有效 ALU 结果|无|无|nop：`PC ← valP`；halt：停止执行|
|`rrmovq/cmovXX`|`PC+2`|`valA=R[rA]`|`valE=0+valA`；计算 Cnd|无|条件真：`R[rB]=valE`；否则不写|`PC ← valP`|
|`irmovq`|`PC+10`|无|`valE=0+valC`|无|`R[rB]=valE`|`PC ← valP`|
|`rmmovq`|`PC+10`|`valA=R[rA]`；`valB=R[rB]`|`valE=valB+valC`|`M8[valE]=valA`|无|`PC ← valP`|
|`mrmovq`|`PC+10`|`valB=R[rB]`|`valE=valB+valC`|`valM=M8[valE]`|`R[rA]=valM`|`PC ← valP`|
|`OPq`|`PC+2`|`valA=R[rA]`；`valB=R[rB]`|`valE=valB OP valA`；更新 CC|无|`R[rB]=valE`|`PC ← valP`|
|`jXX`|`PC+9`|无|`Cnd=Cond(CC,ifun)`|无|无|`PC ← Cnd ? valC : valP`|
|`pushq`|`PC+2`|`valA=R[rA]`；`valB=R[%rsp]`|`valE=valB−8`|`M8[valE]=valA`|`R[%rsp]=valE`|`PC ← valP`|
|`popq`|`PC+2`|`valA=R[%rsp]`；`valB=R[%rsp]`|`valE=valB+8`|`valM=M8[valA]`|`R[%rsp]=valE`；`R[rA]=valM`|`PC ← valP`|
|`call`|`PC+9`，作为返回地址压栈|`valB=R[%rsp]`|`valE=valB−8`|`M8[valE]=valP`|`R[%rsp]=valE`|`PC ← valC`（被调函数入口）|
|`ret`|`PC+1`，本指令不使用该顺序地址|`valA=R[%rsp]`；`valB=R[%rsp]`|`valE=valB+8`|`valM=M8[valA]`|`R[%rsp]=valE`|`PC ← valM`（栈中的返回地址）|

- **valP 的定义**：若当前指令位于地址 p、长度为 L，则 $valP=p+L$，表示紧接着该指令之后的地址；是否真正执行那里，要由 PC 更新逻辑另行决定。
- **call 的两个地址**：`valC` 来自指令的目标地址字段，立即成为下一 PC；`valP=p+9` 被写入栈中，供将来的 ret 返回。它们不是两次连续的 PC 赋值。
- **ret 的两个地址**：`valM` 来自旧栈顶保存的返回地址，成为下一 PC；`valP=p+1` 只是统一取指电路形成的顺序地址，不用于该 ret 的 PC 更新。

- `rmmovq` 的 valA 是待写数据，valB 是基址；不能把两者都送去 ALU 相加而忘掉位移。
- `mrmovq` 的目的写在 M 端口，ALU 的 valE 是地址，不是要写入目的寄存器的数据。
- `pushq/call` 先形成新栈顶地址 valE，向它写；`popq/ret` 从旧栈顶 valA 读。新旧地址是两套信号，不能用统一“栈地址”代替。
- `popq` 需要两个写回。若 `rA=%rsp`，M 端口写入的弹出值优先于 E 端口的递增值，最终栈指针等于弹出的字。
- `cmovXX` 即使条件假也可计算 valE，只把 dstE 置为 RNONE；`jXX` 不写寄存器，只选择新 PC。两者都使用此前 CC，而非本指令 ALU 的新结果。
- `call` 与 push 共用 `R[%rsp]−8`，但写数据分别为 valP 和 valA；`ret` 与 pop 共用从旧栈顶读，但读出值分别流向 PC 和寄存器。

### 数值追踪：pop、call、ret

- **pop**：设 `%rsp=0x200`，`M8[0x200]=0x1234`。`popq %rax` 读得 valA=valB=0x200，valE=0x208，valM=0x1234，写回 `%rsp=0x208,%rax=0x1234`。
- **popq %rsp**：同样初值执行 `popq %rsp`，最终 `%rsp=0x1234`；不能写成 0x208。
- **call**：地址 `0x100` 的 `call 0x300`，原 `%rsp=0x200`，有 valP=0x109、valE=0x1f8，故 `M8[0x1f8]=0x109`、新 `%rsp=0x1f8`、新 PC=0x300。
- **ret**：被调过程保持该返回栈布局时，ret 读出 0x109，恢复 `%rsp=0x200`，转回 0x109。返回地址是完整 call 后继，不是 call 首地址加 1。

## Fetch：字段位置、长度和有效性

```hcl
int icode = [ imem_error : INOP; 1 : imem_icode; ];
int ifun  = [ imem_error : FNONE; 1 : imem_ifun; ];
bool need_regids = icode in {
    IRRMOVQ, IIRMOVQ, IRMMOVQ, IMRMOVQ, IOPQ, IPUSHQ, IPOPQ
};
bool need_valC = icode in { IIRMOVQ, IRMMOVQ, IMRMOVQ, IJXX, ICALL };
bool instr_valid = icode in {
    IHALT, INOP, IRRMOVQ, IIRMOVQ, IRMMOVQ, IMRMOVQ,
    IOPQ, IJXX, ICALL, IRET, IPUSHQ, IPOPQ
};
```

- `need_regids` 控制是否解释 PC+1 为寄存器编号，不能总读它为 rA/rB；jmp 的 PC+1 已是目标地址第一个字节。
- `need_valC` 控制是否取 8 字节常数。若两者都真，valC 从 PC+2 开始；只需常数时从 PC+1 开始。
- 顺序后继为

$$
valP=PC+1+\mathbf1_{need\_regids}+8\mathbf1_{need\_valC}.
$$

- 取指地址错误时输出 nop 型编码，是让下游组合逻辑获得确定输入；Stat 仍报告 ADR，不能因此认为出错指令成功变成可继续执行的 nop。
- 这里 `instr_valid` 是课件给出的**icode 类别检查**，不等于完整验证每种 ifun、寄存器字段与编码组合；模拟器/扩展实现应按实际 ISA 再作检查。

## Decode / Write back：四个寄存器选择器

```hcl
int srcA = [
    icode in { IRRMOVQ, IRMMOVQ, IOPQ, IPUSHQ } : rA;
    icode in { IPOPQ, IRET } : RRSP;
    1 : RNONE;
];
int srcB = [
    icode in { IOPQ, IRMMOVQ, IMRMOVQ } : rB;
    icode in { IPUSHQ, IPOPQ, ICALL, IRET } : RRSP;
    1 : RNONE;
];
int dstE = [
    icode == IRRMOVQ && Cnd : rB;
    icode in { IIRMOVQ, IOPQ } : rB;
    icode in { IPUSHQ, IPOPQ, ICALL, IRET } : RRSP;
    1 : RNONE;
];
int dstM = [
    icode in { IMRMOVQ, IPOPQ } : rA;
    1 : RNONE;
];
```

- 选择 srcA 是因为需要“被存数据/运算 A/旧栈顶”，选择 srcB 是因为需要“运算 B/基址/旧的 `%rsp` 值”。按数据用途推导，而非死记集合。
- `call` 的写内存数据来自 valP，因此不需要为它读 srcA。
- `mrmovq` 只写 dstM；`popq` 同时写 dstE 和 dstM；`rmmovq/jXX` 均不写寄存器。
- `IRRMOVQ` 包括条件传送，其 dstE 由 Cnd 使能。RNONE 是抑制端口的编号，不是“向某个假寄存器写零”。

## Execute：ALU 的两个输入、功能和 CC

```hcl
int aluA = [
    icode in { IRRMOVQ, IOPQ } : valA;
    icode in { IIRMOVQ, IRMMOVQ, IMRMOVQ } : valC;
    icode in { ICALL, IPUSHQ } : -8;
    icode in { IRET, IPOPQ } : 8;
    1 : 0;
];
int aluB = [
    icode in { IRMMOVQ, IMRMOVQ, IOPQ, ICALL, IPUSHQ, IRET, IPOPQ } : valB;
    icode in { IRRMOVQ, IIRMOVQ } : 0;
    1 : 0;
];
int alufun = [ icode == IOPQ : ifun; 1 : ALUADD; ];
bool set_cc = icode == IOPQ;
```

- 数据传送也可能使用 ALU：`rrmovq` 是 0+valA，`irmovq` 是 0+valC，load/store 是基址+位移。
- 栈操作用 ALU 加 ±8，但 **set_cc 为假**，因此不会破坏调用前的算术标志。
- `alufun=ifun` 仅对 OPq 成立；其他需要 ALU 的指令统一使用加法，不能把 cmov 的条件功能码当成 ALU 运算码。
- 上面是课件的正常执行控制。停止或地址错误下，是否提交各状态还需要执行状态/使能控制；不能把这个 set_cc 片段单独当作完整异常处理方案。

## Memory：地址、数据与读写使能

```hcl
int mem_addr = [
    icode in { IRMMOVQ, IMRMOVQ, IPUSHQ, ICALL } : valE;
    icode in { IPOPQ, IRET } : valA;
    1 : 0;
];
int mem_data = [
    icode in { IRMMOVQ, IPUSHQ } : valA;
    icode == ICALL : valP;
    1 : 0;
];
bool mem_read  = icode in { IMRMOVQ, IPOPQ, IRET };
bool mem_write = icode in { IRMMOVQ, IPUSHQ, ICALL };
```

- `mem_addr` 有值不等于发生访问；必须同时查看读/写使能。默认地址 0 在使能为假时不代表读写了地址 0。
- valM 由数据内存的读端提供；只有 load/pop/ret 使用其结果。
- call 的写数据必须是 valP；若错接 valC，就把被调函数地址而非返回地址压栈，ret 将跳错。
- 每次正常指令最多进行一次本节所指的数据内存读或写；取指内存访问另算。

## 状态与 PC 更新的优先选择

```hcl
int Stat = [
    imem_error || dmem_error : SADR;
    !instr_valid : SINS;
    icode == IHALT : SHLT;
    1 : SAOK;
];
int new_pc = [
    icode == ICALL : valC;
    icode == IJXX && Cnd : valC;
    icode == IRET : valM;
    1 : valP;
];
```

- 状态 case 按第一条真条件取值：地址错优先于非法指令，非法指令优先于 halt，均无异常时为 AOK。
- call 总选择 valC；条件跳转只有条件真才选择 valC；ret 选择 valM；普通指令和未跳转的 JXX 选择 valP。
- 条件不满足的 cmov 仍取 valP，并且不修改目的寄存器和 CC。

## 一周期内什么变化，时钟沿上什么变化

- 周期开始时，PC、寄存器堆、CC、数据内存提供旧状态。
- 取指、读寄存器、ALU、条件判断、内存读与各选择器在周期内传播，候选写回值和新 PC 逐渐稳定。
- 正常指令在约定的上升沿更新状态；新状态出现后，组合网络开始为下一条指令传播。不能因为图上画了“Write back”，就额外给它安排一拍。
- 对 `rmmovq`，更新的是数据内存而不是程序寄存器；对 OPq，寄存器与 CC 更新；对 jXX，主要更新 PC。

### 课件 pp.47–50 的执行轨迹

|周期|当前 PC|指令|周期结束后的主要结果|
|---|---|---|---|
|1|0x000|`irmovq $0x100,%rbx`|rbx=0x100，PC=0x00a|
|2|0x00a|`irmovq $0x200,%rdx`|rdx=0x200，PC=0x014|
|3|0x014|`addq %rdx,%rbx`|rbx=0x300；ZF=SF=OF=0；PC=0x016|
|4|0x016|`je dest`|ZF=0，不跳，PC=0x01f|
|5|0x01f|`rmmovq %rbx,0(%rdx)`|M8[0x200]=0x300，PC=0x029|

- 第 3 周期的计算先使用旧 rbx=0x100；它变成 0x300 后，下一条指令才看到新结果。
- je 必须读取 addq 设置的 ZF。它自身不能把“用于形成地址的 ALU 结果”写成新的标志。

## 作业 4.51：扩展 iaddq 的完整改动清单

设扩展采用 `icode=C, ifun=0`、`FrB` 与 8 字节立即数字段，`iaddq V,rB` 语义为 `R[rB] ← R[rB]+V`，并更新 CC。这是作业扩展，基础 Y86 指令表未包含它。

- **取指**：将该扩展的指令常量名记为 `IIADDQ`；将它加入 instr_valid、need_regids、need_valC，长度为 10。
- **译码**：srcA=RNONE、srcB=rB；不能为立即数去读一个寄存器。
- **执行**：aluA=valC、aluB=valB、alufun=ALUADD；把 `IIADDQ` 加入 set_cc 的条件。
- **写回**：dstE=rB、dstM=RNONE。
- **访存**：不加入 mem_read 或 mem_write；不因它有常数字段就误当作数据内存访问。
- **PC**：普通顺序路径选择 valP，不需增加分支项。
- **测试**：正数、负立即数、零结果、有符号溢出以及 `rB=%rsp` 都应核对；每种测试分别看结果、标志和 PC。

## 性能边界与课件勘误

- **时钟周期下界**：必须覆盖本设计最慢的组合路径及建立/时钟开销。典型长路径涉及取指、寄存器读、ALU、数据内存读与写回选择，不能只按一次加法延迟定频率。
- SEQ 的优点是每条指令使用统一阶段，控制逻辑容易由操作表推导；缺点是所有指令都等待最坏路径，各单元在一个长周期内只有部分时间有用。
- 后续流水线可改善吞吐率，但本章不把流水线、缓存或程序优化的旧资料自动并入当前课程范围。
- 第 16 页的 popq 编码末半字节应按 ISA 为 F；第 33 页的立即数传送未用寄存器位也应为 F，A0 那一行应是 pushq。第 39 页残留 `OPl/rmmovl` 字样按本课 64 位模型读为 `OPq/rmmovq`。

来源：本地第 10 讲课件 pp.1–51、第 10 讲小班研讨单；HCL 常量名与六阶段约定以教材第 4 章的 SEQ 模型为准。
