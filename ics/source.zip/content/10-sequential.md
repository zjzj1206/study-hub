# 10 · SEQ 顺序处理器与 HCL 控制

依据第 10 讲 2026-10-19 课件全部 51 页及对应研讨单。[第 09 章](09-isa-logic.html)规定 Y86 的行为，本章把每类指令拆成相同的六个逻辑阶段，再汇总成控制信号。**SEQ 一条指令占一个长周期，六阶段不是六个时钟周期，也不是六级流水线。**

## 本章先解决什么问题

**沿着一条 load 读懂整台 SEQ。** 先在原始总图上找到 PC、指令内存、寄存器文件、ALU、数据内存，再读六阶段。每遇到一个信号，就记录它是“寄存器编号、数据值还是内存地址”，并追问谁产生它、谁使用它。

阅读时可先看本章各节的分步例子，再回到信号表、公式和边界说明核对；最后用[第二次测验分章习题](15-quiz02.html)检验能否独立填写。

## 先看硬件总图：同一条指令怎样走完整个电路

[![SEQ 硬件结构总图：底部 PC、取指与译码，中部 ALU，上部数据内存与新 PC，以及右侧写回线路](hardware-seq.jpg)](hardware-seq.jpg)

用户提供的 SEQ 硬件结构照片。点击打开原图，手机/平板可放大查看线路；后文的“总图”均指这张图。六张分模块矢量图用来展开局部选择器，阅读时始终回到总图定位它们的位置。

### 读图顺序与图形含义

- **第一遍，自下而上找部件**：最底部 `PC` → 左下“指令内存”和右下“PC 增加” → 中下“寄存器文件” → 中部 `ALU A / ALU B / ALU fun.` 与 ALU → 上方“地址/数据/内存控制”及“数据内存” → 顶部“新 PC”。
- **第二遍，追右侧回路**：ALU 的 `valE`、数据内存的 `valM` 经右侧长实线送回寄存器文件的 E/M 写端口；顶部“新 PC”的输出再沿最右侧绕回底部 PC。这些回路分别更新程序寄存器与下一条指令地址。
- **矩形与圆角框**：蓝色部件包含指令内存、数据内存、寄存器文件、ALU、CC 等；灰色圆角框负责选择或产生控制，例如 `srcA/srcB/dstE/dstM`、“地址”“数据”“内存控制”和“新 PC”。某部件是否保存状态要结合功能判断，ALU 是组合电路，CC 才保存条件码。
- **圆圈只是信号名**：`valA`、`valB`、`valE`、`Cnd`、`Stat` 等圆圈用于标识线路，不表示该处另有一级寄存器。不要把圆圈数目当作时钟周期数。
- **实线与虚线**：原图实线传递数据、地址或寄存器编号；虚线主要表达控制关系，例如 Cnd 控制目的选择与 PC 选择。注意寄存器编号也是一组线路上的编码，不是寄存器数据本身。交叉是否相连看分支点与线路走向，不能把所有交叉都连起来。
- **同一周期的含义**：本图没有 PIPE 那样横贯整张图的 D/E/M/W 流水线寄存器条。当前指令的各组合信号在一个长周期内传播，约定时钟沿再完成正常指令的状态更新。

### 把图中的位置和接下来的小节对应起来

|总图位置 / 标记|先看输入从哪里来|再看输出送往哪里|本章对应部分|
|---|---|---|---|
|底部 PC、指令内存、PC 增加|PC 是本周期的旧地址|`icode/ifun/rA/rB/valC/valP` 向上与向侧面分流|Fetch|
|寄存器文件及其上方编号选择框|`rA/rB/icode`，以及栈寄存器常量|A/B 读口给 `valA/valB`；E/M 是两个写口|Decode / Write back|
|ALU A、ALU B、ALU fun.、ALU|`valA/valB/valC`、固定常量与 `ifun/icode`|`valE` 同时可能流向内存地址与寄存器写口|Execute|
|CC 与 Cnd|ALU 候选标志写入 CC，旧 CC 配合 ifun 判断条件|Cnd 送条件传送目的选择和新 PC 选择|Execute / PC update|
|地址、数据、内存控制、数据内存|地址与写数据分别选择，读写使能另算|读出 `valM`，错误给 `dmem_error`|Memory|
|顶部新 PC、左上 stat|`valC/valP/valM/Cnd/icode` 与错误信号|新地址回到底部 PC；Stat 指示执行状态|PC update / 状态|

- **分清两种“内存”**：底部指令内存给出指令编码，上部数据内存给 load/pop/ret 的数据。图按功能分别画出接口，不意味着程序代码和数据在 ISA 中必定属于两个互不相干的地址空间。
- **分清两种“寄存器”**：PC、CC 和寄存器文件属于会保存状态的部件；`srcA/dstE` 只是组合逻辑选出的编号。本图中的“寄存器文件”即 register file，也常称寄存器堆，不是操作系统文件。
- 对照阅读：[PIPE 总图](11-pipeline.html#pipe-hardware)保留大量相同功能部件，却在中间插入流水线寄存器，并把多个后级结果反馈给 D 级选择器。

## 从机器状态到六个阶段

- **Fetch 取指**：用 PC 读指令字节，得到 `icode/ifun`、可选 `rA/rB`、可选常数 valC，同时形成顺序后继 valP。
- **Decode 译码/读寄存器**：控制 srcA/srcB 选择需要的寄存器，读出 valA/valB。
- **Execute 执行**：选择 ALU 两个输入与运算，产生 valE；需要时计算条件 Cnd 和候选 CC。
- **Memory 访存**：选择地址、读/写使能及写数据；读结果记为 valM。
- **Write back 写回**：将 valE 写到 dstE、valM 写到 dstM；RNONE 表示该端口不写寄存器。
- **PC update 更新 PC**：在 valP、valC、valM 中选择下一 PC。

### 信号不是同义词

|信号|含义|易混点|
|---|---|---|
|`rA/rB`|指令编码中的寄存器编号|并非每条指令都直接读两者|
|`srcA/srcB`|本周期实际读端口的寄存器编号|pop/ret 都需读 `%rsp`|
|`valA/valB`|读端口输出的数据字|与寄存器编号不同|
|`valC`|立即数、位移或目标地址|具体含义由指令决定|
|`valP`|PC 加指令长度|call 压入的返回地址|
|`valE`|ALU 输出|可能是算术结果，也可能是有效地址或新的 `%rsp` 值|
|`valM`|数据内存读出的字|load 的值、pop 的值或 ret 的返回地址|
|`dstE/dstM`|两个写回端口的目的编号|与写回数据配对理解|
|`Cnd`|`Cond(CC,ifun)` 的结果|cmov 控制写回；jXX 控制下一 PC|
|`Stat`|正常、停止或错误状态|不同于只描述算术结果的 CC|

- ALU 按 `valB OP valA` 组织。减法是 B−A，调换两侧会改变结果。
- 数据通路中的“箭头”表示组合信号传播；架构状态在时钟沿才统一提交正常指令的结果。
- 以下步骤表假设指令与地址有效；故障状态需走后面的状态控制。

### 用一条指令建立六阶段的因果关系

考虑 `mrmovq 8(%rbx),%rax`，旧 `R[%rbx]=0x200`，`M8[0x208]=37`。

- **Fetch**：从 PC 取出指令，得到 load 类别、目的编号 `%rax`、基址编号 `%rbx`、位移 8，并算出长度为 10 的顺序后继地址。此时知道要干什么，但还没有读取基址的值。
- **Decode**：寄存器编号 `%rbx` 接到读地址端，读出 0x200，成为 `valB`。`%rax` 的编号留给后面的写回选择，不表示要先读 `%rax` 的旧值。
- **Execute**：ALU 把位移 8 与基址 0x200 相加，得到 `valE=0x208`。这一步得到的是地址，不是最终装入值 37。
- **Memory**：用 0x208 读数据内存，得到 `valM=37`。
- **Write back**：将 `valM` 送到写数据端，将 `%rax` 编号送到目的端，更新 `%rax`；load 不应把地址 `valE` 写入 `%rax`。
- **PC update**：没有转移时选择 `valP`。六个名字按数据依赖划分功能，在 SEQ 中并不是六个时钟周期。


## 每类指令的六阶段操作

共同取指规则：首字节分成 `icode:ifun`；需要寄存器字节时从 PC+1 读取；常数字段从 PC+1 或 PC+2 开始读取。下表直接用 `R[%rsp]` 表示该指令执行前的栈指针值。

|类别|取指所得顺序地址 valP|读寄存器|执行|访存|写回|实际下一 PC|
|---|---|---|---|---|---|---|
|`halt/nop`|`PC+1`|无|无有效 ALU 结果|无|无|nop：`PC ← valP`；halt：停止执行|
|`rrmovq/cmovXX`|`PC+2`|`valA=R[rA]`|`valE=0+valA`；计算 Cnd|无|条件真：`R[rB]=valE`；否则不写|`PC ← valP`|
|`irmovq`|`PC+10`|无|`valE=0+valC`|无|`R[rB]=valE`|`PC ← valP`|
|`rmmovq`|`PC+10`|`valA=R[rA]`；`valB=R[rB]`|`valE=valB+valC`|`M8[valE]=valA`|无|`PC ← valP`|
|`mrmovq`|`PC+10`|`valB=R[rB]`|`valE=valB+valC`|`valM=M8[valE]`|`R[rA]=valM`|`PC ← valP`|
|`OPq`|`PC+2`|`valA=R[rA]`；`valB=R[rB]`|`valE=valB OP valA`；更新 CC|无|`R[rB]=valE`|`PC ← valP`|
|`jXX`|`PC+9`|无|`Cnd=Cond(CC,ifun)`|无|无|`PC ← Cnd ? valC : valP`|
|`pushq`|`PC+2`|`valA=R[rA]`；`valB=R[%rsp]`|`valE=valB−8`|`M8[valE]=valA`|`R[%rsp]=valE`|`PC ← valP`|
|`popq`|`PC+2`|`valA=R[%rsp]`；`valB=R[%rsp]`|`valE=valB+8`|`valM=M8[valA]`|`R[%rsp]=valE`；`R[rA]=valM`|`PC ← valP`|
|`call`|`PC+9`，作为返回地址压栈|`valB=R[%rsp]`|`valE=valB−8`|`M8[valE]=valP`|`R[%rsp]=valE`|`PC ← valC`（被调函数入口）|
|`ret`|`PC+1`，本指令不使用该顺序地址|`valA=R[%rsp]`；`valB=R[%rsp]`|`valE=valB+8`|`valM=M8[valA]`|`R[%rsp]=valE`|`PC ← valM`（栈中的返回地址）|

- **valP 的定义**：若当前指令位于地址 p、长度为 L，则 $valP=p+L$，表示紧接着该指令之后的地址；是否真正执行那里，要由 PC 更新逻辑另行决定。
- **call 的两个地址**：`valC` 来自指令的目标地址字段，立即成为下一 PC；`valP=p+9` 被写入栈中，供将来的 ret 返回。它们不是两次连续的 PC 赋值。
- **ret 的两个地址**：`valM` 来自旧栈顶保存的返回地址，成为下一 PC；`valP=p+1` 只是统一取指电路形成的顺序地址，不用于该 ret 的 PC 更新。

- `rmmovq` 的 valA 是待写数据，valB 是基址；不能把两者都送去 ALU 相加而忘掉位移。
- `mrmovq` 的目的写在 M 端口，ALU 的 valE 是地址，不是要写入目的寄存器的数据。
- `pushq/call` 先形成新栈顶地址 valE，向它写；`popq/ret` 从旧栈顶 valA 读。新旧地址是两套信号，不能用统一“栈地址”代替。
- `popq` 需要两个写回。若 `rA=%rsp`，M 端口写入的弹出值优先于 E 端口的递增值，最终栈指针等于弹出的字。
- `cmovXX` 即使条件假也可计算 valE，只把 dstE 置为 RNONE；`jXX` 不写寄存器，只选择新 PC。两者都使用此前 CC，而非本指令 ALU 的新结果。
- `call` 与 push 共用 `R[%rsp]−8`，但写数据分别为 valP 和 valA；`ret` 与 pop 共用从旧栈顶读，但读出值分别流向 PC 和寄存器。

### 数值追踪：pop、call、ret

- **pop**：设 `%rsp=0x200`，`M8[0x200]=0x1234`。`popq %rax` 读得 valA=valB=0x200，valE=0x208，valM=0x1234，写回 `%rsp=0x208,%rax=0x1234`。
- **popq %rsp**：同样初值执行 `popq %rsp`，最终 `%rsp=0x1234`；不能写成 0x208。
- **call**：地址 `0x100` 的 `call 0x300`，原 `%rsp=0x200`，有 valP=0x109、valE=0x1f8，故 `M8[0x1f8]=0x109`、新 `%rsp=0x1f8`、新 PC=0x300。
- **ret**：被调过程保持该返回栈布局时，ret 读出 0x109，恢复 `%rsp=0x200`，转回 0x109。返回地址是完整 call 后继，不是 call 首地址加 1。

## 总图与六张局部图怎样配合阅读

- 以下六张局部矢量图中，**深色实线** 表示数据、指令字段或寄存器编号，**橙色虚线** 表示控制；箭头指向接收端。总图照片使用原书的实线/虚线与配色，两套图例分别适用。
- 按实际连线追踪 **来源 → 功能单元 → 去向**，主数据通路大多自下而上。实心圆点表示分支连接；交叉但没有圆点的线互不相连。同名跨图信号表示同一条连接，不代表额外寄存器或额外周期。
- **梯形是多路选择器**：底部接各候选数据，顶部输出选择结果，侧面的虚线接选择控制。端口数字仅用于区分候选输入，不是指令编码；对应的选择条件列在图下，并可与本节 HCL 逐项对照。浅蓝色矩形是数据通路或存储单元，浅橙色圆角矩形是控制逻辑。
- `icode`、`ifun`、`rA/rB` 均来自 Fetch；`Cnd` 来自 Execute 的条件判断。数据字和地址为 64 位，寄存器编号与 `icode/ifun` 为 4 位，条件与使能为 1 位。
- `CLK` 是处理器的公共时钟。图中写使能描述正常执行；停止和错误下的状态提交还要服从处理器执行状态控制。六张图均画基础指令集，`iaddq` 的新增路径见后文扩展清单。

## Fetch：字段位置、长度和有效性

- **在总图中定位**：看最底部 PC 向左上接“指令内存”、向右上接“PC 增加”的分叉。它们同时使用当前 PC，分别产生字段与顺序后继 `valP`。
- **从字段追去向**：`rA/rB` 送编号选择；`valC` 既通向 ALU A，又沿长线通向顶部新 PC；`valP` 也分流到新 PC 和 call 的写内存数据选择。`icode/ifun` 决定上层部件的选择方式，图没有把所有控制扇出都逐根展开。
- **左侧的错误线**：`imem_error` 与 `instr_valid` 最终送到上方 stat；它们处理“取指是否正常”，与本条跳转条件 Cnd 是两回事。

[![Fetch：取指内存、编码选择、字段对齐、长度计算及有效性检查](seq-fetch.svg)](seq-fetch.svg)

点击图可打开矢量电路大图，放大后文字、分支点与连线仍清晰。


```hcl
int icode = [ imem_error : INOP; 1 : imem_icode; ];
int ifun  = [ imem_error : FNONE; 1 : imem_ifun; ];
bool need_regids = icode in {
    IRRMOVQ, IIRMOVQ, IRMMOVQ, IMRMOVQ, IOPQ, IPUSHQ, IPOPQ
};
bool need_valC = icode in { IIRMOVQ, IRMMOVQ, IMRMOVQ, IJXX, ICALL };
bool instr_valid = icode in {
    IHALT, INOP, IRRMOVQ, IIRMOVQ, IRMMOVQ, IMRMOVQ,
    IOPQ, IJXX, ICALL, IRET, IPUSHQ, IPOPQ
};
```

- `need_regids` 控制是否解释 PC+1 为寄存器编号，不能总读它为 rA/rB；jmp 的 PC+1 已是目标地址第一个字节。
- `need_valC` 控制是否取 8 字节常数。若两者都真，valC 从 PC+2 开始；只需常数时从 PC+1 开始。
- 顺序后继为

$$
valP=PC+1+\mathbf1_{need\_regids}+8\mathbf1_{need\_valC}.
$$

- 取指地址错误时输出 nop 型编码，是让下游组合逻辑获得确定输入；Stat 仍报告 ADR，不能因此认为出错指令成功变成可继续执行的 nop。
- 这里 `instr_valid` 是课件给出的**icode 类别检查**，不等于完整验证每种 ifun、寄存器字段与编码组合；模拟器/扩展实现应按实际 ISA 再作检查。

## Decode：两个读端口与源寄存器选择

- **在总图中定位**：看取指字段上方、寄存器文件附近的 `srcA/srcB` 选择框。它们先选“读哪个寄存器”，A/B 端口才输出 `valA/valB`。
- **沿 valA 的分叉看用途**：一条送 ALU A，一条向上送内存“数据”，还可送“地址”供 pop/ret 读取旧栈顶；一条线同时有多个下游不表示会多执行一条指令。
- **沿 valB 看用途**：主要送 ALU B，作为算术 B 操作数、访存基址或旧 `R[%rsp]`。寄存器文件右边标 E/M 的线是稍后写回的输入，不是额外两个读口。

[![Decode：srcA/srcB 的全部来源及寄存器堆的两个读端口](seq-decode.svg)](seq-decode.svg)

点击图可打开矢量电路大图，放大后文字、分支点与连线仍清晰。


```hcl
int srcA = [
    icode in { IRRMOVQ, IRMMOVQ, IOPQ, IPUSHQ } : rA;
    icode in { IPOPQ, IRET } : RRSP;
    1 : RNONE;
];
int srcB = [
    icode in { IOPQ, IRMMOVQ, IMRMOVQ } : rB;
    icode in { IPUSHQ, IPOPQ, ICALL, IRET } : RRSP;
    1 : RNONE;
];

```

- 选择 srcA 是因为需要“被存数据/运算 A/旧栈顶”，选择 srcB 是因为需要“运算 B/基址/旧的 `%rsp` 值”。按数据用途推导，而非死记集合。
- `call` 的写内存数据来自 valP，因此不需要为它读 srcA。
- `mrmovq` 只写 dstM；`popq` 同时写 dstE 和 dstM；`rmmovq/jXX` 均不写寄存器。
- `IRRMOVQ` 包括条件传送，其 dstE 由 Cnd 使能。RNONE 是抑制端口的编号，不是“向某个假寄存器写零”。

## Execute：ALU 的两个输入、功能和 CC

- **在总图中定位**：中间的 ALU 下面是 `ALU A/ALU B` 两个输入选择，右侧 `ALU fun.` 选择运算，左侧 CC 保存条件码。三个选择各司其职：数据 A、数据 B、运算类型。
- **沿 valE 向上和向右追踪**：它送内存地址选择器，供 load/store 或压栈访问；也绕到寄存器文件的 E 端口，供算术结果和新的 `%rsp` 写回。`valE` 不固定等于“要存入内存的数据”。
- **沿 Cnd 的虚线追踪**：它由已保存 CC 和 `ifun` 决定，向下影响条件传送的 `dstE`，向上影响顶部新 PC。图中的 CC 更新与 Cnd 判断要分开理解。

[![Execute：ALU 输入与功能选择、条件码写使能以及 Cnd 来源](seq-execute.svg)](seq-execute.svg)

点击图可打开矢量电路大图，放大后文字、分支点与连线仍清晰。

- **ALU 的数据路径**：`valA/valB` 来自 Decode，`valC` 来自 Fetch，`−8/+8/0` 是硬件常量。`aluA/aluB` 是选择后的输入，运算方向始终为 `aluB OP aluA`。
- **ALU 的控制路径**：`icode` 选择两侧数据来源，并决定 `alufun` 取 `ifun` 还是固定 `ALUADD`。只有 `OPq` 将 `ifun` 解释为算术逻辑功能。
- **条件码分成两条路径**：ALU 产生候选 CC，在 `set_cc` 有效的提交时钟沿写入 CC 寄存器；条件判断单元读取已保存的 CC，并结合 `ifun` 形成 `Cnd`，分别送给条件传送写回和条件跳转。


```hcl
int aluA = [
    icode in { IRRMOVQ, IOPQ } : valA;
    icode in { IIRMOVQ, IRMMOVQ, IMRMOVQ } : valC;
    icode in { ICALL, IPUSHQ } : -8;
    icode in { IRET, IPOPQ } : 8;
    1 : 0;
];
int aluB = [
    icode in { IRMMOVQ, IMRMOVQ, IOPQ, ICALL, IPUSHQ, IRET, IPOPQ } : valB;
    icode in { IRRMOVQ, IIRMOVQ } : 0;
    1 : 0;
];
int alufun = [ icode == IOPQ : ifun; 1 : ALUADD; ];
bool set_cc = icode == IOPQ;
```

- 数据传送也可能使用 ALU：`rrmovq` 是 0+valA，`irmovq` 是 0+valC，load/store 是基址+位移。
- 栈操作用 ALU 加 ±8，但 **set_cc 为假**，因此不会破坏调用前的算术标志。
- `alufun=ifun` 仅对 OPq 成立；其他需要 ALU 的指令统一使用加法，不能把 cmov 的条件功能码当成 ALU 运算码。
- 上面是课件的正常执行控制。停止或地址错误下，是否提交各状态还需要执行状态/使能控制；不能把这个 set_cc 片段单独当作完整异常处理方案。

### 三个控制问题必须分别回答

- 第一个问题是“输入从哪来”：加法指令取两个寄存器值，访存指令取基址和位移，栈指令取栈指针与 ±8。
- 第二个问题是“对输入做什么”：访存地址一般做加法，`subq` 做目的减源。选择输入与选择运算功能是两套控制，不能看到 ALU 就默认是算术指令。
- 第三个问题是“结果影响哪些状态”：地址运算需要 `valE`，但不应改 CC；OPq 才按规则更新 CC。否则一次 push 的减 8 就会破坏此前比较留下的条件，使随后的条件跳转出错。


## Memory：地址、数据与读写使能

- **在总图中定位**：ALU 上方的“地址”和“数据”是两个独立选择器，再上方才是数据内存；左侧“内存控制”单独提供读/写使能。
- **分别追三组输入**：地址选 `valE` 或旧栈顶 `valA`；写数据选 `valA` 或 call 的返回地址 `valP`；读写使能由 `icode` 产生。只看某条地址线有数值，不能认定发生了内存访问。
- **追输出的两条用途**：数据出口 `valM` 沿右侧回寄存器 M 端口，也向上送新 PC（ret）；`dmem_error` 则沿虚线到 stat，不作为返回数据或跳转条件。

[![Memory：地址与写数据所有来源、读写使能及错误输出](seq-memory.svg)](seq-memory.svg)

点击图可打开矢量电路大图，放大后文字、分支点与连线仍清晰。


```hcl
int mem_addr = [
    icode in { IRMMOVQ, IMRMOVQ, IPUSHQ, ICALL } : valE;
    icode in { IPOPQ, IRET } : valA;
    1 : 0;
];
int mem_data = [
    icode in { IRMMOVQ, IPUSHQ } : valA;
    icode == ICALL : valP;
    1 : 0;
];
bool mem_read  = icode in { IMRMOVQ, IPOPQ, IRET };
bool mem_write = icode in { IRMMOVQ, IPUSHQ, ICALL };
```

- `mem_addr` 有值不等于发生访问；必须同时查看读/写使能。默认地址 0 在使能为假时不代表读写了地址 0。
- valM 由数据内存的读端提供；只有 load/pop/ret 使用其结果。
- call 的写数据必须是 valP；若错接 valC，就把被调函数地址而非返回地址压栈，ret 将跳错。
- 每次正常指令最多进行一次本节所指的数据内存读或写；取指内存访问另算。

## Write back：两个目的选择器与双写端口

- **在总图中定位**：回到中下部“寄存器文件”右侧 E/M 两个写入口。E 的数据沿右侧长回路来自 ALU 的 `valE`；M 的数据来自数据内存的 `valM`。
- **地址线和数据线配对**：`dstE` 指明 `valE` 写到哪里，`dstM` 指明 `valM` 写到哪里。目的编号由下方控制框生成，不能把 E/M 当成两种寄存器名称。
- **为何写回画在译码附近**：读端口和写端口属于同一寄存器堆，所以物理位置靠近；“Write back”是功能步骤，不要求图上另放一个写回存储器。


[![Write back：dstE/dstM 的来源、写数据、时钟使能与冲突优先级](seq-writeback.svg)](seq-writeback.svg)

点击图可打开矢量电路大图，放大后文字、分支点与连线仍清晰。

```hcl
int dstE = [
    icode == IRRMOVQ && Cnd : rB;
    icode in { IIRMOVQ, IOPQ } : rB;
    icode in { IPUSHQ, IPOPQ, ICALL, IRET } : RRSP;
    1 : RNONE;
];
int dstM = [
    icode in { IMRMOVQ, IPOPQ } : rA;
    1 : RNONE;
];
```

- **数据与地址分开看**：E 端口的数据固定来自 `valE`，地址由 `dstE` 选择；M 端口的数据固定来自 `valM`，地址由 `dstM` 选择。`dstE/dstM` 不是数据值。
- **条件传送的控制路径**：Fetch 的 `ifun` 与旧 CC 先产生 `Cnd`；`icode` 与 `Cnd` 再决定 `dstE` 是 `rB` 还是 `RNONE`。条件假时 ALU 可以照常算出 `valE`，但 E 端口不写。
- **两个端口属于同一个寄存器堆**：它们在同一提交时钟沿生效。若目的编号相同，以 M 端口为准；因此 `popq %rsp` 最终得到内存中的弹出值。

## PC update：状态与下一 PC 的优先选择

- **在总图中定位**：顶部横向“新 PC”接收三路候选地址：来自取指的 `valP/valC`，来自数据内存的 `valM`；`icode` 与 Cnd 决定选择。最右侧最外圈长线把结果送回底部 PC。
- **别把回路当作当前指令重取一次**：新 PC 是当前指令产生的候选后继，在提交后成为下一周期的取指地址；数据回路与时钟状态边界共同构成连续执行。
- **左上 stat 是另一条链**：`imem_error/dmem_error/instr_valid/icode` 产生状态，表明正常、地址错、非法指令或停止。Stat 与 Cnd 不相同，也不能用新 PC 的数值替代停止控制。

[![PC update：valC/valM/valP 的选择控制、PC 反馈及状态路径](seq-pc-update.svg)](seq-pc-update.svg)

点击图可打开矢量电路大图，放大后文字、分支点与连线仍清晰。


```hcl
int Stat = [
    imem_error || dmem_error : SADR;
    !instr_valid : SINS;
    icode == IHALT : SHLT;
    1 : SAOK;
];
int new_pc = [
    icode == ICALL : valC;
    icode == IJXX && Cnd : valC;
    icode == IRET : valM;
    1 : valP;
];
```

- 状态 case 按第一条真条件取值：地址错优先于非法指令，非法指令优先于 halt，均无异常时为 AOK。
- call 总选择 valC；条件跳转只有条件真才选择 valC；ret 选择 valM；普通指令和未跳转的 JXX 选择 valP。
- 条件不满足的 cmov 仍取 valP，并且不修改目的寄存器和 CC。

## 对照总图，完整追踪四种典型情况

### 算术：addq %rax,%rbx

- **给定旧状态**：`R[%rax]=5`、`R[%rbx]=7`。先在底部取指识别 `OPq`、加法 `ifun` 和两个寄存器字段。
- **走到寄存器文件**：`srcA=%rax`、`srcB=%rbx`，A/B 输出 `valA=5`、`valB=7`。
- **走到 ALU**：ALU A 选 5，ALU B 选 7，ALU fun. 选加法，得到 `valE=12`；同时形成候选 CC。
- **沿右侧写回**：E 数据口收到 12，`dstE=%rbx`；M 端口不写，数据内存读写均不使能。正常提交后 `%rbx=12`，CC 更新，顶部新 PC 选择 `valP`。

### 加载：mrmovq 8(%rbx),%rax

- **给定旧状态**：`R[%rbx]=0x100`，`M8[0x108]=42`。取指把位移 8 放入 `valC`，寄存器文件 B 口读出 `valB=0x100`。
- **走到 ALU 和地址框**：ALU A 选 `valC=8`，B 选 `valB`，产生 `valE=0x108`；内存“地址”框选 valE，内存控制置读使能。
- **走到数据出口**：数据内存给 `valM=42`，它沿右侧送 M 写数据口；`dstM=%rax`，所以提交后 `%rax=42`。E 口不写，不能把算出的地址 0x108 写进 `%rax`。
- **走到顶部**：这条不是 ret，虽然 valM 也连向新 PC 选择器，PC 仍选 `valP`。接了线不代表每条指令都选择这条输入。

### 调用与返回：call 和 ret 的路线不同

- **call 的三条支路**：`valC` 从取指沿长线送顶部，成为函数入口；`valP` 送内存“数据”框，作为返回地址保存；旧 `R[%rsp]` 从 B 口经 ALU 加 −8，得到新栈顶 `valE`，同时用作写内存地址和 E 口写回的新 `%rsp`。
- **ret 的三条支路**：A/B 口都读旧 `R[%rsp]`；A 的旧值经内存地址框读取返回地址 `valM`；B 经 ALU 加 8 得到恢复后的栈指针 `valE`。最后 valM 向上决定新 PC，valE 经右侧回 E 口更新 `%rsp`。
- **由图解释先后**：压栈写新栈顶，弹栈读旧栈顶；它们由不同输入选择实现，不是执行阶段把 `%rsp` 先写了一次，再让访存重新读一次寄存器。

### 条件传送与条件跳转：共用 Cnd，控制对象不同

- `cmovXX` 的数据仍可经 ALU 算出，但 Cnd 为假时 `dstE=RNONE`，切断有效写回；顶部 PC 正常选 `valP`。
- `jXX` 不需要写程序寄存器；Cnd 为真时顶部选 `valC`，否则选 `valP`。它使用左侧已保存 CC，不把自身为其他用途形成的 ALU 结果写成新 CC。
- [回到 SEQ 总图](#seq-hardware)，分别用手指出“数据怎么走”和“哪个选择器控制是否生效”，再看前面的六阶段表，就能把表中每一格落实到线路。

## 一周期内什么变化，时钟沿上什么变化

- **对照总图找状态边界**：底部 PC、中下寄存器文件、左侧 CC 和数据内存会保存状态；中间选择器、ALU 及顶部新 PC 先产生候选值。长回线把候选值送到状态输入，不会让状态在逻辑计算尚未结束时随意反复改变。


- 周期开始时，PC、寄存器堆、CC、数据内存提供旧状态。
- 取指、读寄存器、ALU、条件判断、内存读与各选择器在周期内传播，候选写回值和新 PC 逐渐稳定。
- 正常指令在约定的上升沿更新状态；新状态出现后，组合网络开始为下一条指令传播。不能因为图上画了“Write back”，就额外给它安排一拍。
- 对 `rmmovq`，更新的是数据内存而不是程序寄存器；对 OPq，寄存器与 CC 更新；对 jXX，主要更新 PC。

### 课件 pp.47–50 的执行轨迹

|周期|当前 PC|指令|周期结束后的主要结果|
|---|---|---|---|
|1|0x000|`irmovq $0x100,%rbx`|rbx=0x100，PC=0x00a|
|2|0x00a|`irmovq $0x200,%rdx`|rdx=0x200，PC=0x014|
|3|0x014|`addq %rdx,%rbx`|rbx=0x300；ZF=SF=OF=0；PC=0x016|
|4|0x016|`je dest`|ZF=0，不跳，PC=0x01f|
|5|0x01f|`rmmovq %rbx,0(%rdx)`|M8[0x200]=0x300，PC=0x029|

- 第 3 周期的计算先使用旧 rbx=0x100；它变成 0x300 后，下一条指令才看到新结果。
- je 必须读取 addq 设置的 ZF。它自身不能把“用于形成地址的 ALU 结果”写成新的标志。

### 用“沿前”和“沿后”理解顺序执行

- 周期开始，PC 和寄存器文件保存上一周期完成后的状态。由这个 PC 取出的指令控制本周期的数据通路。
- 沿前，取指、译码、ALU、访存等电路逐步形成稳定结果；下一 PC 选择器也形成候选 PC，但当前 PC 尚未因此不断跳来跳去。
- 到达更新边界后，状态元件接收规定的新值。之后新 PC 引发下一条指令的计算，因此每条指令看到前一条已经完成的状态。
- 最长路径必须在时钟期限前稳定，所以一条简单 `nop` 也受同一时钟周期约束；它不会因为实际只需很少逻辑就自动缩短这一周期。


## 作业 4.51：扩展 iaddq 的完整改动清单

- **在总图上标改动位置**：从取指的常数/长度控制，到 `srcB/dstE`，再到 ALU A/B 与 CC 写使能，逐个修改。图中 ALU 已有加法通路，新增指令通常重用硬件，重点是把各控制选择接正确。


设扩展采用 `icode=C, ifun=0`、`FrB` 与 8 字节立即数字段，`iaddq V,rB` 语义为 `R[rB] ← R[rB]+V`，并更新 CC。这是作业扩展，基础 Y86 指令表未包含它。

- **取指**：将该扩展的指令常量名记为 `IIADDQ`；将它加入 instr_valid、need_regids、need_valC，长度为 10。
- **译码**：srcA=RNONE、srcB=rB；不能为立即数去读一个寄存器。
- **执行**：aluA=valC、aluB=valB、alufun=ALUADD；把 `IIADDQ` 加入 set_cc 的条件。
- **写回**：dstE=rB、dstM=RNONE。
- **访存**：不加入 mem_read 或 mem_write；不因它有常数字段就误当作数据内存访问。
- **PC**：普通顺序路径选择 valP，不需增加分支项。
- **测试**：正数、负立即数、零结果、有符号溢出以及 `rB=%rsp` 都应核对；每种测试分别看结果、标志和 PC。

## 性能边界与课件勘误

- **在总图上看关键路径**：对 load，数据沿 `PC → 指令内存 → 寄存器读 → ALU 地址 → 数据内存 → M 写口` 传播；SEQ 周期必须容纳这样的长路径。PIPE 则把它切在流水线寄存器边界之间，具体见下一章总图。


- **时钟周期下界**：必须覆盖本设计最慢的组合路径及建立/时钟开销。典型长路径涉及取指、寄存器读、ALU、数据内存读与写回选择，不能只按一次加法延迟定频率。
- SEQ 的优点是每条指令使用统一阶段，控制逻辑容易由操作表推导；缺点是所有指令都等待最坏路径，各单元在一个长周期内只有部分时间有用。
- 后续流水线可改善吞吐率，但本章不把流水线、缓存或程序优化的旧资料自动并入当前课程范围。
- 第 16 页的 popq 编码末半字节应按 ISA 为 F；第 33 页的立即数传送未用寄存器位也应为 F，A0 那一行应是 pushq。第 39 页残留 `OPl/rmmovl` 字样按本课 64 位模型读为 `OPq/rmmovq`。

总图来源：用户于 2026-10-26 提供的 SEQ 硬件结构照片，原图保留；局部 SVG 是本手册绘制的展开图。

来源：本地第 10 讲课件 pp.1–51、第 10 讲小班研讨单；HCL 常量名与六阶段约定以教材第 4 章的 SEQ 模型为准。
