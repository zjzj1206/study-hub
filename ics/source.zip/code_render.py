"""Static syntax highlighting for C, AT&T/Y86 assembly and course HCL."""
from html import escape
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import get_lexer_by_name
from pygments.lexer import RegexLexer
from pygments.token import Comment, Keyword, Name, Number, Operator, Punctuation, String, Text
from pygments.util import ClassNotFound


class HCLLexer(RegexLexer):
    name = 'Hardware Control Language'
    aliases = ['hcl']
    tokens = {'root': [
        (r'\s+', Text),
        (r'\#[^\n]*|//[^\n]*', Comment.Single),
        (r'/\*[\s\S]*?\*/', Comment.Multiline),
        (r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', String),
        (r'\b(bool|int|word)\b', Keyword.Type),
        (r'\b(in|true|false)\b', Keyword),
        (r'\b0[xX][0-9a-fA-F]+\b|\b\d+\b', Number),
        (r'\b[A-Z][A-Z0-9_]*\b', Name.Constant),
        (r'\b[A-Za-z_][A-Za-z0-9_]*\b', Name),
        (r'&&|\|\||==|!=|<=|>=|[!<>=+*/%&|^~-]', Operator),
        (r'[\[\]{}():;,]', Punctuation),
        (r'.', Text),
    ]}


FORMATTER = HtmlFormatter(nowrap=True, classprefix='tok-')


def highlight_code(code, language, attrs=''):
    """Return only escaped token spans; Markdown owns the pre/code elements."""
    language = language.strip().lower()
    if language in {'hcl'}:
        lexer = HCLLexer(ensurenl=False, stripnl=False)
    else:
        alias = {'asm': 'gas', 'assembly': 'gas', 'y86': 'gas', 'y86-64': 'gas'}.get(language, language)
        if alias in {'', 'text', 'plain', 'plaintext'}:
            return escape(code)
        try:
            lexer = get_lexer_by_name(alias, ensurenl=False, stripnl=False)
        except ClassNotFound:
            return escape(code)
    return highlight(code, lexer, FORMATTER)
