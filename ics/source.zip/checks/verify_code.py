"""Verify highlighting preserves literal code and includes all required lexers."""
from pathlib import Path
from html.parser import HTMLParser
import sys,zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from code_render import highlight_code
from markdown_it import MarkdownIt
root=Path(__file__).resolve().parents[1]
class Codes(HTMLParser):
 def __init__(self):super().__init__();self.in_pre=False;self.blocks=[];self.current='';self.classes=[]
 def handle_starttag(self,tag,attrs):
  if tag=='pre':self.in_pre=True;self.current=''
  if self.in_pre and tag=='span':self.classes.append(dict(attrs).get('class',''))
 def handle_endtag(self,tag):
  if tag=='pre':self.blocks.append(self.current);self.in_pre=False
 def handle_data(self,text):
  if self.in_pre:self.current+=text
count=0;classes=set();md=MarkdownIt('commonmark')
for p in (root/'content').glob('*.md'):
 expected=[t.content for t in md.parse(p.read_text()) if t.type in {'fence','code_block'}]
 actual=Codes();actual.feed((root/'dist'/(p.stem+'.html')).read_text())
 assert actual.blocks==expected,(p.name,'highlighting changed code text')
 classes.update(actual.classes);count+=len(actual.blocks)
assert {'tok-kt','tok-nf','tok-nv','tok-no'}<=classes,classes
for language,code in [('c','int *p; if (x < 2 && y > 0) x++;\n'),('asm','addq $8,%rax # $x$ & < >\n'),('hcl','bool ok = a && b;\nint x = [ ok : V; 1 : 0; ];\n'),('unknown-language','<tag>& $x$ **raw**\n')]:
 rendered=highlight_code(code,language);parser=Codes();parser.feed('<pre><code>'+rendered+'</code></pre>')
 assert parser.blocks==[code],(language,parser.blocks)
 assert 'katex' not in rendered
page=(root/'dist/10-sequential.html').read_text()
assert '<code>PC ← valC</code>' in page and '<code>PC ← valM</code>' in page
with zipfile.ZipFile(root/'dist/source.zip') as z:
 assert 'code_render.py' in z.namelist()
 assert 'Pygments==2.20.0' in z.read('requirements.txt').decode()
print(f'PASS: {count} code blocks preserve source text; C, assembly and HCL highlighting; PC destinations and portable source bundle')
