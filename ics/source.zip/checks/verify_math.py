"""Regression checks for math parsing, code boundaries and self-hosted assets."""
from pathlib import Path
import sys, re, subprocess
from html.parser import HTMLParser
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from math_render import make_markdown
root=Path(__file__).resolve().parents[1]
fixture=r"""**ISA（指令集体系结构）** 规定机器行为。

**精度 $2^{-23}$** 与代码 `int **p`。

行内 $x_i^2+\frac{1}{2}$。

$$
\begin{cases}x,&x\ge0\\-x,&x<0\end{cases}
$$

|公式|代码|
|---|---|
|$2^{-149}$|`movq $8,%rax`|

转义 \$5 和 `int **p; $x$`。

```asm
movq $8,%rax
```
"""
md=make_markdown([fixture]);out=md.render(fixture)
assert out.count('class="katex"')==4
assert '<strong>ISA（指令集体系结构）</strong>' in out
assert '<strong>精度 <span' in out
assert '<code>int **p</code>' in out
assert '<code>movq $8,%rax</code>' in out
assert '<code>int **p; $x$</code>' in out
assert '转义 $5' in out
assert '<annotation encoding="application/x-tex">' in out
try:
 make_markdown([r'$\notARealCommand{x}$'])
except subprocess.CalledProcessError:pass
else:raise AssertionError('Invalid LaTeX must fail the build')
class Check(HTMLParser):
 def __init__(self):
  super().__init__();self.code=0;self.annotations=0;self.stack=[];self.issues=[]
 def handle_starttag(self,t,a):
  attrs=dict(a)
  if t=='code':self.code+=1
  if t=='annotation':self.annotations+=1
  if attrs.get('class')=='katex':assert not self.code
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
   self.stack.append((t,attrs))
 def handle_endtag(self,t):
  if t=='code':self.code-=1
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==t:
    self.stack=self.stack[:i];break
 def handle_data(self,data):
  if any(tag in {'code','pre','script','style','annotation'} or 'katex' in attrs.get('class','')
         for tag,attrs in self.stack):return
  if re.search(r'\*\*[^*\n]+\*\*|\$[^$\n]+\$',data):
   self.issues.append(data[:180])
count=0
for p in (root/'dist').glob('*.html'):
 text=p.read_text();check=Check();check.feed(text)
 assert 'katex-error' not in text
 assert not check.issues,(p.name,check.issues)
 if p.name!='all.html':count+=check.annotations
assert count>=80,count
assert '<strong>ISA（指令集体系结构）</strong>' in (root/'dist/09-isa-logic.html').read_text()
whole=(root/'dist/all.html').read_text()
assert whole.count('<annotation ')==count
css=(root/'dist/katex/katex.min.css').read_text()
for url in re.findall(r'url\(([^)]+)\)',css):assert (root/'dist/katex'/url).is_file(),url
print(f'PASS: {count} formulas, inline/block/table math, preserved code, strict LaTeX, rendered emphasis/no leaked delimiters, accessible MathML and all local fonts')
