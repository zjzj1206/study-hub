"""Diagrams for lectures 11–12; reuse the site's connected SVG primitives."""
from pathlib import Path
from seq_diagrams import Circuit


def save(c, name):
    c.save()
    assets=Path(__file__).parent/'assets'
    (assets/f'seq-{c.slug}.svg').rename(assets/name)


def build():
    c=Circuit('pipe-overview','PIPE / 五级之间保存字段，后级反馈到前级',850)
    ys=[640,510,380,250,120]
    for i,(stage,y) in enumerate(zip(['F 取指','D 译码 / 前递选择','E 执行','M 访存','W 写回'],ys)):
        c.box(340,y,330,65,stage)
        if i<4:
            regy=y-53
            c.box(365,regy,280,30,['D','E','M','W'][i],state=True)
            c.wire([(505,y),(505,regy+30)])
            c.wire([(505,regy),(505,ys[i+1]+65)])
    c.box(65,640,170,65,'PC 选择')
    c.wire([(235,672),(340,672)])
    c.box(275,720,200,30,'F.predPC',state=True)
    c.wire([(400,705),(400,720)])
    c.wire([(275,735),(150,735),(150,705)])
    c.text(500,745,'f_predPC → F 寄存器',size=16)
    c.wire([(340,280),(45,280),(45,655),(65,655)]);c.text(50,255,'M_Cnd / M_valA',size=16)
    c.wire([(340,150),(20,150),(20,690),(65,690)]);c.text(28,130,'W_valM（ret）',size=16)
    for i,(x,y,label) in enumerate([(770,410,'e_valE'),(835,280,'m_valM / M_valE'),(945,150,'W_valM / W_valE')]):
        dest_y=525+i*15
        c.wire([(670,y),(x,y),(x,dest_y),(670,dest_y)])
        c.text(690,y-14,label,size=16)
    c.text(690,579,'前递返回 D 的值选择器',size=16)
    c.text(690,605,'多个匹配：优先最近的写入',size=16)
    c.foot(['矩形之间的小条框是流水线寄存器；一条指令每周期向上推进一级。',
            '取指中的恢复优先于预测；反馈路径不是让指令本身倒流。寄存器写回端口在 D 的寄存器堆中。'])
    save(c,'pipe-overview.svg')

    c=Circuit('dram','DRAM / 行列复用与芯片位片并行',850)
    c.box(40,180,180,150,'内存控制器')
    c.box(330,160,330,250,'DRAM 阵列','4 行 × 4 列 supercell')
    for yy in [220,265,310]:c.wire([(350,yy),(640,yy)],arrow=False)
    for xx in [410,495,580]:c.wire([(xx,190),(xx,380)],arrow=False)
    c.wire([(220,215),(330,215)]);c.text(230,190,'2 位地址',size=16)
    c.dot(275,215);c.wire([(275,215),(275,120),(950,120),(950,490),(910,490)])
    c.text(785,110,'列地址（CAS 时采样）',size=16)
    c.wire([(220,290),(285,290),(285,370),(330,370)],True);c.text(235,340,'RAS / CAS',size=15)
    c.box(330,460,330,60,'行缓冲（整行）');c.wire([(495,410),(495,460)])
    c.box(730,460,180,60,'列选择');c.wire([(660,490),(730,490)])
    c.wire([(285,370),(285,435),(820,435),(820,460)],True);c.dot(285,370,True)
    c.wire([(820,520),(820,555),(130,555),(130,330)]);c.text(460,546,'8 位数据返回控制器',size=17)
    c.text(40,625,'模块：8 颗 x8 芯片，共享行 / 列地址，同时各输出 8 位。',size=18)
    for i in range(8):
        x=40+i*117;c.box(x,650,100,48,f'芯片 {i}')
        c.wire([(x+50,698),(x+50,735)],arrow=False);c.dot(x+50,735)
    c.wire([(90,735),(909,735)],arrow=False)
    c.wire([(500,735),(500,775)]);c.text(520,774,'64-bit 字 → 内存控制器',size=17)
    c.foot(['单芯片：RAS 选行并装入行缓冲；CAS 选该行的一列，输出 supercell。图是逻辑组织示意。'])
    save(c,'memory-dram.svg')

    c=Circuit('hierarchy','存储层次 / 越向上越快、越小、每字节越贵',860)
    labels=['L0  程序寄存器','L1  Cache（SRAM）','L2  Cache（SRAM）','L3  Cache（SRAM）','L4  主存（DRAM）','L5  本地 SSD / HDD','L6  远程存储']
    for i,label in enumerate(labels):
        w=230+i*65;x=500-w/2;y=120+i*90
        c.box(x,y,w,55,label)
        if i<6:
            c.wire([(470,y+90),(470,y+55)]);c.wire([(530,y+55),(530,y+90)])
    c.text(80,335,'向上：取入所需块',size=17);c.text(755,425,'向下：写回 / 下传',size=17)
    c.foot(['相邻层的传输单位依层次而异：字、缓存块、页、文件块等。箭头表示数据传输方向。',
            '课件层级编号 L4=DRAM 主存，并非所有机器都配备名为 L4 Cache 的硬件。'])
    save(c,'memory-hierarchy.svg')

if __name__=='__main__':build()
