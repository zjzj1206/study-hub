#!/usr/bin/env python3
"""Build a portable static study blog. Sources remain editable Markdown."""
from pathlib import Path
from math_render import make_markdown
import html,re,shutil,json,zipfile,hashlib
from seq_diagrams import build as build_seq_diagrams
build_seq_diagrams()
from course_diagrams import build as build_course_diagrams
build_course_diagrams()
from advanced_diagrams import build as build_advanced_diagrams
build_advanced_diagrams()
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'dist'
SCRIPT_VERSION=hashlib.sha256((ROOT/'assets/app.js').read_bytes()).hexdigest()[:12]
STYLE_VERSION=hashlib.sha256((ROOT/'assets/style.css').read_bytes()).hexdigest()[:12]
# Rebuild only generated output so removed chapters cannot survive a build.
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()
pages=[]
appendices = ['11-quiz01', '12-past-papers', '13-seminars', '14-coverage', '15-quiz02']
def page_order(path):
 return (1, appendices.index(path.stem)) if path.stem in appendices else (0, path.stem)
for path in sorted((ROOT/'content').glob('*.md'), key=page_order):
 text=path.read_text(); title=text.splitlines()[0].removeprefix('# ')
 pages.append({'id':path.stem,'title':title,'text':text,'file':path.stem+'.html'})

md=make_markdown([p["text"] for p in pages])
# Stable figure anchors also work in the combined book; original photos stay full size.
HARDWARE_FIGURES = {
 'hardware-seq.jpg': ('seq-hardware', 1104, 1276),
 'hardware-pipe.jpg': ('pipe-hardware', 1155, 1592),
}

def render(text):
 body=md.render(text);toc=[];counter=0
 for filename,(anchor,width,height) in HARDWARE_FIGURES.items():
  body=re.sub(r'<img (?=[^>]*src="'+re.escape(filename)+r'")',
      f'<img id="{anchor}" class="hardware-photo" width="{width}" height="{height}" loading="lazy" decoding="async" ', body)
 def heading(m):
  nonlocal counter
  counter+=1;tag,content=m.group(1),m.group(2);anchor='section-'+str(counter)
  toc.append((anchor,re.sub('<[^>]+>','',content)))
  return f'<h{tag} id="{anchor}">{content}<a class="anchor" href="#{anchor}" aria-label="链接到本节">#</a></h{tag}>'
 body=re.sub(r'(<a)( href="[^"]+">)(<img\b[^>]+/?>)(</a>)', r'\1 class="figure-link"\2\3\4', body)
 body=re.sub(r'<h([23])>(.*?)</h\1>',heading,body)
 body=body.replace('<table>','<div class="table-scroll"><table>').replace('</table>','</table></div>')
 # Only the quiz appendix uses answer disclosures, including in combined reading.
 marker='<h1>附录 E · 第二次测验分章习题</h1>'
 if marker in body:
  before,quiz=body.split(marker,1)
  quiz=re.sub(r'(<p><strong>答案</strong>.*?)(?=<h[123]\b|<hr\b|\Z)',
      lambda m: '<details class="quiz-answer"><summary><span class="answer-show">显示答案</span><span class="answer-hide">隐藏答案</span></summary><div class="answer-body">'+m[1]+'</div></details>\n',quiz,flags=re.S)
  body=before+marker+quiz
 return body,toc

def shell(title,body,active='',toc=(),prevnext=''):
 nav=''.join(f'<a {"aria-current=page" if p["id"]==active else ""} href="{p["file"]}">{html.escape(p["title"])}</a>' for p in pages)
 quiz_page=active=='15-quiz02'
 contents=''.join(f'<a href="#{a}">{t}</a>' for a,t in toc)
 if quiz_page:
  sections=re.findall(r'<h2 id="([^"]+)">(.*?)<a class="anchor"',body)
  question_count=len(re.findall(r'<h3\b',body))
  contents=f'<a class="quiz-chapter-link" href="#main" data-chapter="all" aria-current="true">全部章节 · {question_count} 题</a>'+''.join(
      f'<a class="quiz-chapter-link" href="#{a}" data-chapter="{a}">{t}</a>' for a,t in sections)
  body=re.sub(r'(<h2 id="([^"]+)".*?)(?=<h2 |\Z)',lambda m: '<section class="quiz-chapter" data-chapter="'+m[2]+'">'+m[1]+'</section>',body,flags=re.S)
 return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)} · ZJZJ / ICS</title><meta name="description" content="北京大学 ICS 复习手册：课程知识、公式推导、边界情况、小班拓展与往年题导航。"><link rel="stylesheet" href="katex/katex.min.css"><link rel="stylesheet" href="style.css?v={STYLE_VERSION}"><link rel="icon" href="favicon.svg" type="image/svg+xml"></head><body class="{'quiz-page' if quiz_page else ''}"><a class="skip" href="#main">跳到正文</a><header><a class="brand" href="index.html">ZJZJ<span> / ICS NOTES</span></a><div class="header-right"><a href="https://blog.zjzj.work/">学习空间</a><a href="all.html">整本阅读</a><button type="button" onclick="window.print()">打印</button><button id="menu" aria-expanded="false" aria-controls="chapters">目录</button></div></header><div class="layout"><nav id="chapters" aria-label="章节目录"><div class="nav-label">2026 · 复习手册</div>{nav}<div class="nav-foot">依据本地课件与公开题库<br>更新于 2026.11.10</div></nav><main id="main"><div class="eyebrow">COMPUTER SYSTEMS · PEKING UNIVERSITY</div>{body}{prevnext}<footer>理解表示，追踪执行。<span><a href="14-coverage.html">资料来源与覆盖范围</a></span></footer></main><aside aria-label="本页目录"><div class="nav-label">{'选择习题章节' if quiz_page else '本页内容'}</div>{contents}<a href="#main">回到顶部 ↑</a></aside></div><script src="app.js?v={SCRIPT_VERSION}"></script></body></html>'''
for i,p in enumerate(pages):
 body,toc=render(p['text'])
 pn='<div class="pager">'+(f'<a href="{pages[i-1]["file"]}">上一章<br>{html.escape(pages[i-1]["title"])}</a>' if i else '<span></span>')+(f'<a href="{pages[i+1]["file"]}">下一章<br>{html.escape(pages[i+1]["title"])}</a>' if i+1<len(pages) else '')+'</div>'
 (OUT/p['file']).write_text(shell(p['title'],body,p['id'],toc,pn))
count=sum(len(re.findall(r'[\u4e00-\u9fff]',p['text'])) for p in pages)
cards=''.join(f'<a class="chapter-card" href="{p["file"]}"><span class="chapter-number">{p["title"].split(" · ")[0] if " · " in p["title"] else "00"}</span><div><h2>{html.escape(p["title"].split(" · ")[-1])}</h2><p>{"课程主线" if p["id"] not in appendices and p["id"] != "00-guide" else "阅读与查漏"}</p></div><span aria-hidden="true">↗</span></a>' for p in pages)
home=f'''<section class="intro"><div class="edition">AUTUMN 2026 <span>学习笔记 / 01</span></div><h1>计算机系统导论<br><em>课程复习手册</em></h1><p class="lead">从一个比特，到一段程序的执行。按章节梳理概念、推导、易错边界与真题方法。</p><div class="stats"><span><b>{len(pages)}</b> 个章节</span><span><b>{count//1000}k+</b> 中文字</span><span><b>16 + 14</b> 课件与小班资料</span></div></section><section class="scope-note"><strong>先对齐考试范围</strong><p>第 1～16 讲课件已齐：新增链接、ELF、符号解析与重定位、库及插桩，以及异常、进程、fork、wait 和 execve；第二次测验新增两讲填空练习。第一次测验仍按第 1～8 讲复盘。</p><a href="00-guide.html">阅读范围说明</a> · <a href="15-quiz02.html">第二次测验分章习题（第 9～16 讲）</a></section><div class="section-heading"><h2>章节目录</h2><span>按顺序读，也可以直接查阅</span></div><section class="chapter-grid">{cards}</section>'''
(OUT/'index.html').write_text(shell('计算机系统导论复习手册',home))
combined='\n\n---\n\n'.join(p['text'] for p in pages)
body,toc=render(combined)
(OUT/'all.html').write_text(shell('整本复习手册',body,toc=toc))
(OUT/'404.html').write_text(shell('页面不存在','<h1>这一页没有找到</h1><p>请从章节目录继续阅读。</p><a href="index.html">回到 ICS 首页</a>'))
for path in (ROOT/'assets').iterdir():shutil.copy2(path,OUT/path.name)
katex=ROOT/'node_modules/katex'
(OUT/'katex').mkdir()
shutil.copy2(katex/'dist/katex.min.css',OUT/'katex/katex.min.css')
shutil.copy2(katex/'LICENSE',OUT/'katex/LICENSE')
shutil.copytree(katex/'dist/fonts',OUT/'katex/fonts')
(OUT/'.nojekyll').touch()
(ROOT/'复习资料汇总.md').write_text(combined)
print(json.dumps({'pages':len(pages),'chinese_characters':count,'output':str(OUT)},ensure_ascii=False))

shutil.copy2(ROOT/'README.md',OUT/'README.md')
with zipfile.ZipFile(OUT/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in [ROOT/'build.py',ROOT/'math_render.py',ROOT/'code_render.py',ROOT/'seq_diagrams.py',ROOT/'course_diagrams.py',ROOT/'advanced_diagrams.py',ROOT/'render-math.mjs',ROOT/'package.json',ROOT/'package-lock.json',ROOT/'README.md',ROOT/'requirements.txt',ROOT/'复习资料汇总.md',*(ROOT/'content').glob('*.md'),*(ROOT/'assets').glob('*'),*(ROOT/'checks').glob('*.py')]:
  z.write(path,path.relative_to(ROOT))
