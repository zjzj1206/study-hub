"""Standalone connected SVG figures for cache organization and optimization."""
from seq_diagrams import Circuit
from course_diagrams import save


def build():
    c=Circuit('cache-lookup','Cache 读访问 / 索引选组、标记比较、偏移选字节',900)
    for x,w,label in [(100,300,'tag：T（t 位）'),(400,200,'index：j（s 位）'),(600,200,'offset：o（b 位）')]:c.box(x,130,w,60,label)
    c.box(410,270,180,55,'组选择：j',control=True);c.wire([(500,190),(500,270)])
    for x,label in [(80,'路 0'),(560,'路 1')]:
        c.box(x,390,360,100,label,'valid / tag / B 字节数据')
    c.wire([(455,325),(455,355),(260,355),(260,390)],True)
    c.wire([(545,325),(545,355),(740,355),(740,390)],True)
    for x,label in [(180,'hit0'),(660,'hit1')]:
        c.box(x,560,160,70,'v 且 tag=T',control=True)
        c.wire([(x+20,490),(x+20,560)])
        c.text(x+80,655,label,anchor='middle')
    c.wire([(250,190),(250,225),(30,225),(30,595),(180,595)])
    c.wire([(250,225),(940,225),(940,595),(820,595)]);c.dot(250,225)
    c.box(450,710,200,60,'命中路 / 字节选择')
    c.wire([(340,595),(395,595),(395,680),(480,680),(480,710)],True)
    c.wire([(660,595),(610,595),(610,680),(550,680),(550,710)],True)
    c.wire([(350,490),(350,740),(450,740)]);c.text(355,700,'data0',size=15)
    c.wire([(850,490),(850,740),(650,740)]);c.text(855,700,'data1',size=15)
    c.wire([(700,190),(700,250),(975,250),(975,800),(620,800),(620,770)]);c.text(780,790,'块内偏移 o',size=15)
    c.wire([(500,770),(500,820)]);c.text(500,850,'命中：返回数据；两路均未命中：请求下一级装块',anchor='middle',size=18)
    c.foot(['图示 E=2；更多路重复比较逻辑。地址没有单独的“路号”位域。'])
    save(c,'cache-lookup.svg')

    c=Circuit('cache-blocking','矩阵分块 / 同时保留 A、B、C 的三个子块',730)
    for x,name,tile in [(65,'A', (1,2)),(365,'B',(2,1)),(665,'C',(1,1))]:
        c.text(x+110,140,name,anchor='middle',size=25)
        c.box(x,190,220,220)
        for k in range(1,4):
            c.wire([(x+k*55,190),(x+k*55,410)],arrow=False)
            c.wire([(x,190+k*55),(x+220,190+k*55)],arrow=False)
        row,col=tile
        c.p.append(f'<rect x="{x+col*55+2}" y="{190+row*55+2}" width="51" height="51" fill="#b7e1db"/>')
        c.text(x+110,460,'q × q 子块',anchor='middle')
    c.text(324,300,'×',anchor='middle',size=28);c.text(625,300,'→',anchor='middle',size=28)
    c.box(230,520,540,70,'C[ii,jj] += A[ii,kk] × B[kk,jj]')
    c.wire([(175,410),(175,555),(230,555)])
    c.wire([(475,410),(475,520)])
    c.wire([(770,555),(920,555),(920,300),(885,300)])
    c.foot(['对固定 C 子块，沿 kk 逐段累加；每个 A/B 子块装入后在内层重复使用。',
            'double 元素：三个子块约需 24q² byte；实际选 q 还要留容量和映射余量。'])
    save(c,'cache-blocking.svg')

    c=Circuit('optimization-cpu','现代超标量 / 独立操作可并行，架构效果按序确认',830)
    c.box(300,125,400,80,'取指 / 分支预测 / 译码')
    c.box(300,270,400,75,'依赖跟踪 / 调度')
    c.wire([(500,205),(500,270)])
    for x,label in [(45,'整数 / 分支'),(280,'浮点 / SIMD'),(515,'Load'),(750,'Store')]:
        c.box(x,430,200,75,label)
        center=x+100;c.wire([(500,345),(500,380),(center,380),(center,430)])
        c.wire([(center,505),(center,565),(500,565),(500,610)])
    c.box(300,610,400,85,'结果缓冲 / 按程序顺序退休')
    c.wire([(500,695),(500,745)]);c.text(500,775,'确认后的程序可见寄存器与内存效果',anchor='middle')
    c.text(30,325,'可用操作',size=16);c.text(35,590,'不同单元延迟与吞吐可不同',size=16)
    c.foot(['示意图，不对应一条指令一个固定执行周期；错误路径候选结果须取消而不能提交。'])
    save(c,'optimization-cpu.svg')

    c=Circuit('optimization-dependencies','规约依赖图 / 展开与增加独立链是两件事',850)
    for x,title in [(160,'单链 / 2×1'),(500,'2×1a 重结合'),(820,'2×2 双链')]:c.text(x,135,title,anchor='middle',size=21)
    for y,label in [(240,'x OP d0'),(370,'x OP d1'),(500,'x OP d2'),(630,'x OP d3')]:
        c.box(70,y,180,55,label)
        if y>240:c.wire([(160,y-75),(160,y)])
    c.text(160,720,'每元素都增加主链长度',anchor='middle',size=16)
    for y,pair in [(240,'d0 OP d1'),(500,'d2 OP d3')]:c.box(405,y,190,55,pair)
    for y,label in [(370,'x OP pair0'),(630,'x OP pair1')]:c.box(405,y,190,55,label)
    c.wire([(500,295),(500,370)]);c.wire([(500,425),(375,425),(375,660),(405,660)])
    c.wire([(500,555),(500,630)])
    c.text(500,720,'每一对只接一次主链',anchor='middle',size=16)
    for x,data in [(695,['x0 OP d0','x0 OP d2']),(855,['x1 OP d1','x1 OP d3'])]:
        for y,label in zip([240,440],data):c.box(x,y,130,65,label)
        c.wire([(x+65,305),(x+65,440)])
    c.box(735,630,200,55,'x0 OP x1')
    c.wire([(760,505),(760,630)]);c.wire([(920,505),(920,630)])
    c.text(835,720,'两条独立链，最后合并',anchor='middle',size=16)
    c.foot(['OP 的延迟为 D 时：单链约 D CPE；两条链 / 每对一次主链在资源足够时约 D/2。',
            '图显示依赖，不是全部指令的执行时间表；浮点重结合可能改变结果。'])
    save(c,'optimization-dependencies.svg')

if __name__=='__main__':build()
